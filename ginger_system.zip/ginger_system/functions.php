<?php

function check_login($con)
{
    if(isset($_SESSION['user_id']))
    {
        $id = $_SESSION['user_id'];
        $query = "select * from users where user_id = '$id' limit 1";

        $result = mysqli_query($con, $query);
        if($result && mysqli_num_rows($result) > 0)
        {
            $user_data = mysqli_fetch_assoc($result);
            return $user_data;
        }
    }

    //redirect to login
    // Works from the root folder and from customer/ or admin/
    header("Location: " . (file_exists("login.php") ? "login.php" : "../login.php"));
    die;

}

function random_num($length)
{
    $text = "";
    if($length < 5)
    {
        $length = 5;
    }

    $len = rand(4, $length);

    for ($i=0; $i < $len; $i++) { 
        # code
        $text .= rand(0,9);
    }

    return $text;
}




// Only let a specific role (Admin / Adopter) into a page
function require_role($con, $role)
{
    $user_data = check_login($con);

    if ($user_data['user_type'] !== $role)
    {
        // Wrong role: send them to the right dashboard
        if ($user_data['user_type'] == "Admin")
        {
            header("Location: ../admin/admin_dashboard.php");
        }
        else
        {
            header("Location: ../customer/dashboard.php");
        }
        die;
    }

    return $user_data;
}


// Emoji + colour class for a pet, based on species
function pet_look($species)
{
    if ($species == "Cat")  return ["cat", "🐱"];
    if ($species == "Dog")  return ["dog", "🐶"];
    return ["puppy", "🐾"];
}

?>