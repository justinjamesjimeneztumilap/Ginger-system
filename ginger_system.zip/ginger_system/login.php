<?php
session_start();

include("connection.php");
include("functions.php");

// Already logged in? Send them straight to their dashboard.
if (isset($_SESSION['user_id'], $_SESSION['user_type']))
{
    header("Location: " . ($_SESSION['user_type'] == "Admin" ? "admin/admin_dashboard.php" : "customer/dashboard.php"));
    die;
}

$error = "";
$user_name = "";

if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    $user_name = trim($_POST['user_name'] ?? "");
    $password  = $_POST['password'] ?? "";

    if ($user_name !== "" && $password !== "")
    {
        // Prepared statement: safe from SQL injection
        $stmt = mysqli_prepare($con, "SELECT user_id, password, user_type FROM users WHERE user_name = ? OR email = ? LIMIT 1");
        mysqli_stmt_bind_param($stmt, "ss", $user_name, $user_name);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $user_data = $result ? mysqli_fetch_assoc($result) : null;

        if ($user_data && password_verify($password, $user_data['password']))
        {
            session_regenerate_id(true);

            $_SESSION['user_id']   = $user_data['user_id'];
            $_SESSION['user_type'] = $user_data['user_type'];

            if ($user_data['user_type'] == "Admin")
            {
                header("Location: admin/admin_dashboard.php");
            }
            else
            {
                header("Location: customer/dashboard.php");
            }

            die;
        }

        $error = "Wrong username or password. Please try again.";
    }
    else
    {
        $error = "Please enter your username (or email) and password.";
    }
}

// Inline SVG icons (they take the color of the text around them)
if (!function_exists("login_icon"))
{
    function login_icon($name, $size = 20)
    {
        $shapes = [
            "paw"  => '<circle cx="5.5" cy="10.5" r="1.8"/><circle cx="9.5" cy="6" r="1.8"/><circle cx="14.5" cy="6" r="1.8"/><circle cx="18.5" cy="10.5" r="1.8"/><path d="M12 12c-2.8 0-5 2.4-5 4.6 0 1.5 1.2 2.4 2.6 2.4 1 0 1.6-.4 2.4-.4s1.4.4 2.4.4c1.4 0 2.6-.9 2.6-2.4C17 14.4 14.8 12 12 12z"/>',
            "leaf" => '<path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.5 19 2c1 2 2 4.2 2 8 0 5.5-4.8 10-10 10z"/><path d="M2 21c0-3 1.9-5.4 5.1-6C9.5 14.5 12 13 13 12"/>',
        ];

        return '<svg class="svg-icon" viewBox="0 0 24 24" width="' . $size . '" height="' . $size . '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $shapes[$name] . '</svg>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PetAdopt | Login</title>

    <!-- Nunito (login.css uses it, so it has to be loaded here too) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="style/login.css">

    <style>
        /* ==========================================================
           SVG icons + balance tweaks (loads after login.css)
           ========================================================== */

        .svg-icon { display: block; flex-shrink: 0; }

        /* header: logo icon and text on one line, same height as the Back button */
        header .logo { display: inline-flex; align-items: center; gap: 10px; }
        header .logo .svg-icon { width: 26px; height: 26px; color: var(--green); }
        .home-link { display: inline-flex; align-items: center; min-height: 40px; }

        /* card icon: centered, sharp */
        .card-icon { color: var(--green); }
        .card-icon .svg-icon { width: 30px; height: 30px; }

        /* same height for both inputs and the button */
        input  { height: 50px; padding: 0 16px; }
        button { height: 52px; padding: 0 20px; display: flex; align-items: center; justify-content: center; }

        /* a little more room between the heading block and the form */
        .description { margin-bottom: 24px; }
        label:first-of-type { margin-top: 0; }

        /* background decorations (login.css already sets their opacity and rotation) */
        .decoration { display: grid; place-items: center; }
        .paw-one .svg-icon  { width: 40px; height: 40px; }
        .leaf-one .svg-icon { width: 48px; height: 48px; color: var(--green); }

        @media (max-width: 600px) {
            input { height: 48px; }
            button { height: 50px; }
        }
    </style>
</head>

<body>

    <header>
        <a href="index.php" class="logo">
            <?php echo login_icon("paw", 26); ?> <span>Pet<span>Adopt</span></span>
        </a>

        <a href="index.php" class="home-link">
            ← Back to Home
        </a>
    </header>

    <main>

        <section class="login-card">

            <div class="card-icon"><?php echo login_icon("paw", 30); ?></div>

            <p class="small-title">WELCOME BACK</p>

            <h1>Find your way<br>back to <span>PetAdopt.</span></h1>

            <p class="description">
                Log in to browse pets and continue your adoption journey.
            </p>

            <?php if (isset($_GET['reset'])): ?>
                <p class="success-message" role="status">Password updated. You can log in now.</p>
            <?php endif; ?>

            <?php if ($error !== ""): ?>
                <p class="error-message" role="alert"><?php echo htmlspecialchars($error); ?></p>
            <?php endif; ?>

            <form method="post">

                <label for="user_name">Username or email</label>
                <input
                    type="text"
                    id="user_name"
                    name="user_name"
                    placeholder="Enter your username or email"
                    value="<?php echo htmlspecialchars($user_name); ?>"
                    required
                >

                <label for="password">Password</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Enter your password"
                    required
                >

                <a href="forgot_password.php" class="forgot-link">Forgot password?</a>

                <button type="submit">
                    Login <span>→</span>
                </button>

                <p class="account-text">
                    Don't have an account?
                    <a href="signup.php">Create one</a>
                </p>

            </form>

        </section>

        <div class="decoration paw-one" aria-hidden="true"><?php echo login_icon("paw", 40); ?></div>
        <div class="decoration leaf-one" aria-hidden="true"><?php echo login_icon("leaf", 48); ?></div>

    </main>

</body>
</html>