<?php
session_start();

include("../connection.php");
include("../functions.php");
include("../icons.php");

$user_data = require_role($con, "Adopter");
$uid       = $user_data['user_id'];
$user_name = htmlspecialchars($user_data['user_name']);

$species_list = ["Dog" => "Dogs", "Cat" => "Cats", "Other" => "Other pets"];

// Search and filter
$q       = trim($_GET['q'] ?? "");
$species = $_GET['species'] ?? "";

$sql    = "SELECT id, name, species, breed, age, gender, photo FROM pets WHERE status = 'Available'";
$types  = "";
$params = [];

if ($q !== "")
{
    $sql     .= " AND (name LIKE ? OR breed LIKE ?)";
    $like     = "%" . $q . "%";
    $types   .= "ss";
    $params[] = $like;
    $params[] = $like;
}

if (isset($species_list[$species]))
{
    $sql     .= " AND species = ?";
    $types   .= "s";
    $params[] = $species;
}

$sql .= " ORDER BY created_at DESC, id DESC";

$stmt = mysqli_prepare($con, $sql);
if ($params) { mysqli_stmt_bind_param($stmt, $types, ...$params); }
mysqli_stmt_execute($stmt);
$pets = mysqli_stmt_get_result($stmt);

$page_kicker = "BROWSE PETS";
$page_title  = "Meet your new best friend";
$page_text   = "Every pet here is ready for a loving home.";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>PetAdopt | Browse Pets</title>

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="../style/browse_pets.css">
    <style>
        /* Hide the email + role pill at the top right */
        .topbar .profile,
        .topbar .user-info,
        .topbar .user-pill,
        .topbar .user-menu,
        .topbar .account {
            display: none !important;
        }
    </style>
    <style>
        /* Stop long breed / age text from running into the next column */
        .profile-meta-split {
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }

        .profile-meta-split .meta-item {
            min-width: 0;
        }

        .profile-meta-split .meta-item strong {
            display: block;
            white-space: normal;
            overflow-wrap: anywhere;
            line-height: 1.3;
        }

        /* Same card height, buttons lined up at the bottom */
        @media (min-width: 601px) {
            .pet-profile-list { align-items: stretch; }

            .pet-profile-card {
                display: flex;
                flex-direction: column;
                height: 100%;
            }

            .pet-profile-card .pet-profile-details {
                flex: 1;
                display: flex;
                flex-direction: column;
            }

            .pet-profile-card .profile-meta-split { flex: 1; }

            .pet-profile-card .profile-action { margin-top: auto; }
        }
    </style>
    <style>
        /* Pet name inside the button: keep it on one line */
        .btn-profile {
            max-width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
    </style>
    <style>
        /* Search bar, species dropdown and button: same height, same curve */
        .filters {
            display: flex;
            flex-wrap: wrap;
            align-items: stretch;
            gap: 12px;
        }

        .filters .search-input-wrap {
            position: relative;
            flex: 1 1 280px;
            display: flex;
            align-items: center;
        }

        .filters .search-icon {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            display: flex;
            color: var(--muted, #6B7369);
            pointer-events: none;
        }

        .filters input[type="text"],
        .filters select,
        .filters .btn {
            box-sizing: border-box;
            height: 48px !important;
            border-radius: 999px !important;
            font-family: inherit;
            font-size: .88rem;
            margin: 0;
        }

        .filters input[type="text"] {
            width: 100%;
            padding: 0 20px 0 46px;
            border: 1px solid #DDE4DA;
            background: var(--white, #FFFFFF);
            color: var(--text, #2F3A33);
        }

        .filters select {
            flex: 0 0 auto;
            min-width: 170px;
            padding: 0 46px 0 20px;
            border: 1px solid #DDE4DA;
            background-color: var(--white, #FFFFFF);
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='%234F7C59' stroke-width='3' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 18px center;
            color: var(--text, #2F3A33);
            cursor: pointer;
            -webkit-appearance: none;
            appearance: none;
        }

        .filters .btn {
            padding: 0 30px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .filters input[type="text"]:focus,
        .filters select:focus {
            outline: 3px solid var(--orange, #F4A261);
            outline-offset: 2px;
        }

        @media (max-width: 600px) {
            .filters select { flex: 1 1 140px; }
            .filters .btn   { flex: 1 1 100px; }
        }
    </style>
    <style>
        /* Remove the extra peach pill behind the search input (double outline) */
        .filters .search-input-wrap {
            padding: 0 !important;
            background: transparent !important;
            border: 0 !important;
            border-radius: 0 !important;
            box-shadow: none !important;
        }
    </style>
    <style>
        /* Even rows inside the details box so Breed / Age line up across all cards */
        .profile-meta-split {
            align-content: start;
        }

        .profile-meta-split .meta-item strong {
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;
            overflow: hidden;
            line-height: 1.3;
        }

        /* Breed (1st) and Age (3rd) always reserve two lines */
        .profile-meta-split .meta-item:nth-child(1) strong,
        .profile-meta-split .meta-item:nth-child(3) strong {
            min-height: 2.6em;
        }
    </style>
    <style>
        /* Balanced details box:
           Breed (full width)
           Gender | Species
           Age (full width)                                  */
        .profile-meta-split {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 10px 12px;
            align-content: start;
        }

        .profile-meta-split .meta-item:nth-child(1) { grid-column: 1 / -1; grid-row: 1; }
        .profile-meta-split .meta-item:nth-child(2) { grid-column: 1;      grid-row: 2; }
        .profile-meta-split .meta-item:nth-child(4) { grid-column: 2;      grid-row: 2; }
        .profile-meta-split .meta-item:nth-child(3) { grid-column: 1 / -1; grid-row: 3; }

        /* Breed gets up to two lines, everything else stays on one line */
        .profile-meta-split .meta-item strong {
            -webkit-line-clamp: 1;
            min-height: 0;
        }

        .profile-meta-split .meta-item:nth-child(1) strong {
            -webkit-line-clamp: 2;
            min-height: 2.6em;
        }
    </style>
    <style>
        /* No orange ring on the search bar / dropdown; just a soft green border when active */
        .filters input[type="text"]:focus,
        .filters select:focus {
            outline: none !important;
            border-color: var(--green, #4F7C59) !important;
            box-shadow: 0 0 0 3px rgba(79, 124, 89, .12);
        }
    </style>
    <style>
        /* Roomier pill search bar, dropdown and button (more padding for the full curve) */
        .filters {
            gap: 14px;
            padding: 14px 16px;
        }

        .filters input[type="text"],
        .filters select,
        .filters .btn {
            height: 52px !important;
            font-size: .92rem;
        }

        .filters .search-icon {
            left: 24px;
        }

        .filters .search-icon svg {
            width: 18px;
            height: 18px;
        }

        .filters input[type="text"] {
            padding: 0 28px 0 56px;
        }

        .filters select {
            min-width: 200px;
            padding: 0 56px 0 28px;
            background-position: right 24px center;
        }

        .filters .btn {
            padding: 0 38px;
            font-weight: 800;
        }

        @media (max-width: 600px) {
            .filters { padding: 12px; }

            .filters input[type="text"] { padding: 0 22px 0 50px; }
            .filters .search-icon        { left: 20px; }
            .filters select              { padding: 0 48px 0 22px; background-position: right 20px center; }
            .filters .btn                { padding: 0 26px; }
        }
    </style>
</head>

<body>

<div class="dashboard">

    <?php $active = "browse"; include("sidebar.php"); ?>

    <main class="main-content">

        <?php include("topbar.php"); ?>

        <!-- SEARCH & FILTER -->
        <form method="get" class="filters">

            <div class="search-input-wrap">
                <span class="search-icon"><?php echo icon("search", 16); ?></span>
                <input type="text" name="q" placeholder="Search by pet name or breed..." value="<?php echo htmlspecialchars($q); ?>">
            </div>

            <select name="species" aria-label="Species">
                <option value="">All species</option>
                <?php foreach ($species_list as $value => $label): ?>
                    <option value="<?php echo $value; ?>" <?php echo $species === $value ? "selected" : ""; ?>><?php echo $label; ?></option>
                <?php endforeach; ?>
            </select>

            <button type="submit" class="btn btn-primary">Search</button>

        </form>


        <!-- PET PROFILE CARDS -->
        <section class="pets-section">

            <div class="pet-profile-list">

                <?php if ($pets && mysqli_num_rows($pets) > 0): ?>
                    <?php while ($p = mysqli_fetch_assoc($pets)): ?>
                        <?php list($cls, $emoji) = pet_look($p['species']); ?>

                        <article class="pet-profile-card">

                            <div class="pet-avatar-container <?php echo $cls; ?>">
                                <?php if (!empty($p['photo'])): ?>
                                    <img class="pet-photo-img" src="../uploads/pets/<?php echo htmlspecialchars($p['photo']); ?>" alt="<?php echo htmlspecialchars($p['name']); ?>" loading="lazy">
                                <?php else: ?>
                                    <span class="pet-avatar"><?php echo pet_icon($cls); ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="pet-profile-details">

                                <div class="profile-header">
                                    <h3><?php echo htmlspecialchars($p['species']); ?></h3>
                                    <span class="status-badge available-badge">&bull; Available</span>
                                </div>

                                <div class="profile-meta-split">
                                    <div class="meta-item">
                                        <small>Breed</small>
                                        <strong title="<?php echo htmlspecialchars($p['breed']); ?>"><?php echo htmlspecialchars($p['breed']); ?></strong>
                                    </div>
                                    <div class="meta-item">
                                        <small>Gender</small>
                                        <strong><?php echo htmlspecialchars($p['gender']); ?></strong>
                                    </div>
                                    <div class="meta-item">
                                        <small>Age</small>
                                        <strong><?php echo htmlspecialchars($p['age']); ?></strong>
                                    </div>
                                    <div class="meta-item">
                                        <small>Species</small>
                                        <strong><?php echo htmlspecialchars($p['species']); ?></strong>
                                    </div>
                                </div>

                                <div class="profile-action">
                                    <a href="pet_details.php?id=<?php echo (int)$p['id']; ?>" class="btn-profile" title="View <?php echo htmlspecialchars($p['name']); ?>"><?php echo htmlspecialchars($p['name']); ?> &rarr;</a>
                                </div>

                            </div>

                        </article>

                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <div class="empty-icon"><?php echo icon("paw", 48, "color:var(--green,#4F7C59)"); ?></div>
                        <h3>No pets found</h3>
                        <p>Try a different name, breed or species.</p>
                    </div>
                <?php endif; ?>

            </div>

        </section>

    </main>

</div>

</body>
</html>