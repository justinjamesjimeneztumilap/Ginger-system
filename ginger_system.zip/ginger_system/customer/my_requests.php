<?php
session_start();

include("../connection.php");
include("../functions.php");
include("../icons.php");

$user_data = require_role($con, "Adopter");
$uid       = $user_data['user_id'];
$user_name = htmlspecialchars($user_data['user_name']);

// Cancel a pending request
if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['cancel_id']))
{
    $request_id = (int)$_POST['cancel_id'];

    mysqli_begin_transaction($con);

    $stmt = mysqli_prepare($con, "SELECT pet_id FROM adoption_requests WHERE id = ? AND user_id = ? AND status = 'Pending' LIMIT 1");
    mysqli_stmt_bind_param($stmt, "is", $request_id, $uid);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if ($row)
    {
        $stmt = mysqli_prepare($con, "DELETE FROM adoption_requests WHERE id = ? AND user_id = ? AND status = 'Pending'");
        mysqli_stmt_bind_param($stmt, "is", $request_id, $uid);
        mysqli_stmt_execute($stmt);

        // Put the pet back on the shelf
        $stmt = mysqli_prepare($con, "UPDATE pets SET status = 'Available' WHERE id = ? AND status = 'Pending'");
        mysqli_stmt_bind_param($stmt, "i", $row['pet_id']);
        mysqli_stmt_execute($stmt);

        mysqli_commit($con);
        header("Location: my_requests.php?cancelled=1");
        die;
    }

    mysqli_rollback($con);
    header("Location: my_requests.php");
    die;
}

$stmt = mysqli_prepare($con, "SELECT r.id, r.message, r.status, r.created_at, r.updated_at,
                                     p.id AS pet_id, p.name, p.species, p.breed, p.age, p.photo
                              FROM adoption_requests r
                              JOIN pets p ON p.id = r.pet_id
                              WHERE r.user_id = ?
                              ORDER BY r.created_at DESC, r.id DESC");
mysqli_stmt_bind_param($stmt, "s", $uid);
mysqli_stmt_execute($stmt);
$requests = mysqli_stmt_get_result($stmt);

// Group the requests by status
$groups = ["Approved" => [], "Pending" => [], "Rejected" => []];
$total  = 0;

while ($r = mysqli_fetch_assoc($requests))
{
    if (isset($groups[$r['status']]))
    {
        $groups[$r['status']][] = $r;
        $total++;
    }
}

// The adopter has now seen the decisions, so clear their dashboard notifications
if (!empty($groups["Approved"]) || !empty($groups["Rejected"]))
{
    try
    {
        $stmt = mysqli_prepare($con, "UPDATE adoption_requests SET adopter_seen = 1
                                      WHERE user_id = ? AND status IN ('Approved','Rejected') AND adopter_seen = 0");
        mysqli_stmt_bind_param($stmt, "s", $uid);
        mysqli_stmt_execute($stmt);
    }
    catch (Throwable $e)
    {
        // adopter_seen column missing: ignore so the page still loads
    }
}

$status_text = [
    "Pending"  => "Waiting for approval",
    "Approved" => "Approved. Welcome home!",
    "Rejected" => "Not approved this time",
];

// Section titles, in display order
$sections = [
    "Approved" => [
        "id"     => "approved",
        "icon"   => "check",
        "kicker" => "APPROVED",
        "title"  => "Welcome home!",
        "text"   => "These requests were approved. Your new family members are waiting for you."
    ],
    "Pending" => [
        "id"     => "pending",
        "icon"   => "clock",
        "kicker" => "PENDING",
        "title"  => "Waiting for approval",
        "text"   => "We'll let you know as soon as these are reviewed."
    ],
    "Rejected" => [
        "id"     => "rejected",
        "icon"   => "mail",
        "kicker" => "NOT APPROVED",
        "title"  => "Not approved this time",
        "text"   => "Don't give up. Other pets are still waiting for a home."
    ],
];

// Draw one request card
function render_request_card($r, $status_text)
{
    list($cls, $emoji) = pet_look($r['species']);
    ?>
    <article class="request-card">

        <div class="request-photo emoji <?php echo $cls; ?>">
            <?php if (!empty($r['photo'])): ?>
                <img src="../uploads/pets/<?php echo htmlspecialchars($r['photo']); ?>" alt="<?php echo htmlspecialchars($r['name']); ?>" loading="lazy">
            <?php else: ?>
                <?php echo pet_icon($cls); ?>
            <?php endif; ?>
        </div>

        <div class="request-info">

            <h3>
                <a href="pet_details.php?id=<?php echo (int)$r['pet_id']; ?>"><?php echo htmlspecialchars($r['name']); ?></a>
            </h3>

            <p class="req-meta"><?php echo htmlspecialchars($r['breed']); ?> &bull; <?php echo htmlspecialchars($r['age']); ?></p>
            <small class="sent-date">Sent on <?php echo date("F j, Y", strtotime($r['created_at'])); ?></small>

            <?php if ($r['status'] == "Approved" && !empty($r['updated_at'])): ?>
                <small class="approved-date"><?php echo icon("check", 12, "vertical-align:-2px;margin-right:4px"); ?>Approved on <?php echo date("F j, Y", strtotime($r['updated_at'])); ?></small>
            <?php endif; ?>

        </div>

        <?php if (!empty($r['message'])): ?>
            <div class="request-note">
                <span class="note-label">Your message</span>
                <p class="request-message"><?php echo htmlspecialchars($r['message']); ?></p>
            </div>
        <?php endif; ?>

        <div class="request-status">

            <span class="badge badge-<?php echo strtolower($r['status']); ?>"><?php echo htmlspecialchars($r['status']); ?></span>
            <small class="status-subtext"><?php echo $status_text[$r['status']] ?? ""; ?></small>

            <?php if ($r['status'] == "Pending"): ?>
                <form method="post" onsubmit="return confirm('Cancel this request?');">
                    <input type="hidden" name="cancel_id" value="<?php echo (int)$r['id']; ?>">
                    <button type="submit" class="btn btn-soft">Cancel request</button>
                </form>
            <?php elseif ($r['status'] == "Approved"): ?>
                <a href="pet_tracker.php?id=<?php echo (int)$r['pet_id']; ?>" class="btn btn-primary">View my pet</a>
            <?php endif; ?>

        </div>

    </article>
    <?php
}

$page_kicker = "MY REQUESTS";
$page_title  = "Your adoption requests";
$page_text   = "Keep track of every pet you have asked to adopt.";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>PetAdopt | My Requests</title>

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,400;0,500;0,600;0,700;0,800;1,600&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="../style/my_requests.css">

    <style>
    /* =========================================================
       Request sections (Approved / Pending / Not approved)
       Same palette, radius and shadows as the PetAdopt
       dashboard. Fallback colors are the dashboard's own.
       ========================================================= */

    html { scroll-behavior: smooth; }

    /* ---------- Jump pills ---------- */
    .req-jump {
        margin-bottom: 28px;
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
    }

    .req-jump a {
        padding: 8px 16px;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        background: var(--white, #FFFFFF);
        border: 1px solid var(--border, #E8E6DC);
        border-radius: 999px;
        box-shadow: 0 2px 8px rgba(47, 79, 55, 0.05);
        color: var(--muted, #6B7369);
        font-size: .78rem;
        font-weight: 800;
        text-decoration: none;
        transition: transform .25s cubic-bezier(.4, 0, .2, 1), box-shadow .25s cubic-bezier(.4, 0, .2, 1);
    }

    .req-jump a:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 24px rgba(47, 79, 55, 0.08);
    }

    .req-jump a:focus-visible {
        outline: 3px solid var(--orange, #F4A261);
        outline-offset: 2px;
    }

    .req-jump .jump-approved {
        background: var(--sage-soft, #EEF4EA);
        border-color: var(--sage, #DCE9D8);
        color: var(--dark-green, #2F4F37);
    }

    .req-jump .jump-pending {
        background: #FFF6EB;
        border-color: #F0D3B8;
        color: #A5482A;
    }

    .jump-count {
        min-width: 20px;
        padding: 1px 7px;
        background: rgba(47, 79, 55, .1);
        border-radius: 999px;
        font-size: .68rem;
        text-align: center;
    }

    /* ---------- Sections ---------- */
    .req-section {
        margin-bottom: 36px;
        scroll-margin-top: 24px;
    }

    .req-heading {
        margin-bottom: 16px;
    }

    .req-heading span {
        color: var(--green, #4F7C59);
        font-size: .68rem;
        font-weight: 800;
        letter-spacing: 1.5px;
    }

    .req-heading h2 {
        margin-top: 2px;
        color: var(--dark-green, #2F4F37);
        font-size: 1.2rem;
        font-weight: 800;
        letter-spacing: -0.2px;
    }

    .req-heading p {
        color: var(--muted, #6B7369);
        font-size: .8rem;
    }

    /* Approved gets the highlighted, celebratory look */
    .req-section-approved {
        padding: 22px;
        background: linear-gradient(135deg, #F4F9F1 0%, #EEF4EA 100%);
        border: 1px solid var(--sage, #DCE9D8);
        border-radius: 32px;
        box-shadow: 0 2px 8px rgba(47, 79, 55, 0.05);
    }

    .req-section-approved:target {
        animation: approved-pop 1.4s ease;
    }

    @keyframes approved-pop {
        0%   { box-shadow: 0 0 0 0 rgba(79, 124, 89, .45); }
        100% { box-shadow: 0 0 0 20px rgba(79, 124, 89, 0); }
    }

    .approved-date {
        display: block;
        margin-top: 2px;
        color: var(--green, #4F7C59);
        font-size: .75rem;
        font-weight: 800;
    }

    @media (prefers-reduced-motion: reduce) {
        html { scroll-behavior: auto; }
        .req-section-approved:target { animation: none; }
    }

    @media (max-width: 600px) {
        .req-section-approved { padding: 16px; border-radius: 22px; }
    }
    </style>
    <style>
        /* Hide the email + role pill at the top right */
        .topbar .profile,
        .topbar .user-info,
        .topbar .user-pill,
        .topbar .user-menu,
        .topbar .account {
            display: none !important;
        }
    </style>
    <style>
        /* "Your message" box: no dark edge on the left, even curve and padding all around */
        .request-note,
        .request-message {
            border-left: 0 !important;
            box-shadow: none;
        }

        .request-note::before,
        .request-note::after,
        .request-message::before,
        .request-message::after {
            display: none !important;
            content: none !important;
        }

        .request-note .request-message {
            margin: 0;
            padding: 12px 18px;
            border: 0 !important;
            border-radius: 16px;
            background: var(--cream, #FFF6EE);
            color: var(--text, #2F3A33);
            font-size: .85rem;
            line-height: 1.5;
            overflow-wrap: anywhere;
        }

        .request-note .note-label {
            display: block;
            margin-bottom: 6px;
        }
    </style>
    <style>
        /* Photo card: same look as the dashboard pet cards */
        .request-card {
            background: var(--white, #FFFFFF);
            border: 1px solid var(--border, #E8E6DC);
            border-radius: 24px;
            box-shadow: 0 2px 8px rgba(47, 79, 55, 0.05);
            transition: transform .25s cubic-bezier(.4, 0, .2, 1), box-shadow .25s cubic-bezier(.4, 0, .2, 1);
        }

        .request-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 28px rgba(47, 79, 55, 0.10);
        }

        .request-photo {
            flex: 0 0 120px;
            width: 120px;
            height: 120px;
            align-self: center;
            display: grid;
            place-items: center;
            overflow: hidden;
            border-radius: 20px;
            background: var(--sage-soft, #EEF4EA);
        }

        .request-photo.cat   { background: var(--peach, #FBE9DB); }
        .request-photo.puppy { background: var(--light-brown, #F3E6D8); }

        .request-photo img {
            width: 88px;
            height: 88px;
            border-radius: 50%;
            object-fit: cover;
            object-position: center 30%;
            border: 3px solid #fff;
            box-shadow: 0 6px 16px rgba(47, 79, 55, .18);
        }

        .request-info h3 a {
            color: var(--dark-green, #2F4F37);
        }

        @media (prefers-reduced-motion: reduce) {
            .request-card { transition: none; }
            .request-card:hover { transform: none; }
        }
    </style>
    <style>
        /* ===== 7 requests per page, next / previous arrows ===== */
        .request-card[hidden] { display: none !important; }

        .req-pager {
            margin-top: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 16px;
        }

        .req-pager button {
            width: 44px;
            height: 44px;
            display: grid;
            place-items: center;
            padding: 0;
            background: var(--white, #FFFFFF);
            border: 1px solid var(--border, #E8E6DC);
            border-radius: 50%;
            box-shadow: 0 6px 18px rgba(47, 79, 55, .12);
            color: var(--green, #4F7C59);
            cursor: pointer;
            transition: background .25s ease, color .25s ease, opacity .25s ease;
        }

        .req-pager button svg { width: 20px; height: 20px; display: block; }

        .req-pager button:hover:not(:disabled) {
            background: var(--green, #4F7C59);
            color: #fff;
        }

        .req-pager button:focus-visible { outline: 3px solid rgba(79, 124, 89, .35); outline-offset: 2px; }

        .req-pager button:disabled { opacity: .35; cursor: default; }

        .req-pager .req-page-label {
            min-width: 64px;
            color: var(--muted, #6B7369);
            font-size: .82rem;
            font-weight: 800;
            text-align: center;
        }

        @media (prefers-reduced-motion: reduce) {
            .req-pager button { transition: none; }
        }
    </style>
</head>

<body>

<div class="dashboard">

    <?php $active = "requests"; include("sidebar.php"); ?>

    <main class="main-content">

        <?php include("topbar.php"); ?>

        <?php if (isset($_GET['sent'])): ?>
            <p class="alert alert-success" role="status">Request sent! We'll let you know once it is reviewed.</p>
        <?php elseif (isset($_GET['cancelled'])): ?>
            <p class="alert alert-success" role="status">Request cancelled.</p>
        <?php endif; ?>

        <?php if ($total > 0): ?>

            <!-- Jump to a section -->
            <nav class="req-jump" aria-label="Jump to a section">
                <?php foreach ($sections as $status => $sec): ?>
                    <?php if (!empty($groups[$status])): ?>
                        <a href="#<?php echo $sec['id']; ?>" class="jump-<?php echo $sec['id']; ?>">
                            <?php echo icon($sec['icon'], 14); ?> <?php echo ucfirst(strtolower($sec['kicker'])); ?>
                            <span class="jump-count"><?php echo count($groups[$status]); ?></span>
                        </a>
                    <?php endif; ?>
                <?php endforeach; ?>
            </nav>

            <?php foreach ($sections as $status => $sec): ?>
                <?php if (!empty($groups[$status])): ?>

                    <section class="req-section req-section-<?php echo $sec['id']; ?>" id="<?php echo $sec['id']; ?>">

                        <div class="req-heading">
                            <span><?php echo icon($sec['icon'], 13, "vertical-align:-2px;margin-right:6px"); ?><?php echo $sec['kicker']; ?></span>
                            <h2><?php echo $sec['title']; ?></h2>
                            <p><?php echo $sec['text']; ?></p>
                        </div>

                        <div class="request-list">
                            <?php foreach ($groups[$status] as $r): ?>
                                <?php render_request_card($r, $status_text); ?>
                            <?php endforeach; ?>
                        </div>

                    </section>

                <?php endif; ?>
            <?php endforeach; ?>

        <?php else: ?>

            <section class="request-list">
                <div class="empty-state">
                    <div class="empty-icon"><?php echo icon("mail", 48, "color:var(--green,#4F7C59)"); ?></div>
                    <h3>No requests yet</h3>
                    <p>Find a pet you love and send your first adoption request.</p>
                    <a href="browse_pets.php" class="btn btn-primary" style="margin-top: 16px;">Browse Pets</a>
                </div>
            </section>

        <?php endif; ?>

    </main>

</div>

<script>
(function () {
    var PER = 7;
    var chevronLeft  = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 5l-7 7 7 7"/></svg>';
    var chevronRight = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 5l7 7-7 7"/></svg>';

    document.querySelectorAll(".request-list").forEach(function (list) {

        var cards = Array.prototype.filter.call(list.children, function (el) {
            return el.classList.contains("request-card");
        });

        if (cards.length <= PER) { return; }

        var pages = Math.ceil(cards.length / PER);
        var page  = 1;

        var nav   = document.createElement("nav");
        nav.className = "req-pager";
        nav.setAttribute("aria-label", "More requests");

        var prev  = document.createElement("button");
        prev.type = "button";
        prev.setAttribute("aria-label", "Previous page");
        prev.innerHTML = chevronLeft;

        var label = document.createElement("span");
        label.className = "req-page-label";
        label.setAttribute("aria-live", "polite");

        var next  = document.createElement("button");
        next.type = "button";
        next.setAttribute("aria-label", "Next page");
        next.innerHTML = chevronRight;

        nav.appendChild(prev);
        nav.appendChild(label);
        nav.appendChild(next);
        list.parentNode.insertBefore(nav, list.nextSibling);

        function show(p, bringIntoView) {
            page = Math.min(Math.max(p, 1), pages);

            cards.forEach(function (card, i) {
                card.hidden = Math.floor(i / PER) + 1 !== page;
            });

            label.textContent = page + " / " + pages;
            prev.disabled = page === 1;
            next.disabled = page === pages;

            if (bringIntoView) {
                var section = list.closest(".req-section") || list;
                if (section.getBoundingClientRect().top < 0) {
                    section.scrollIntoView({ behavior: "smooth", block: "start" });
                }
            }
        }

        prev.addEventListener("click", function () { show(page - 1, true); });
        next.addEventListener("click", function () { show(page + 1, true); });

        show(1, false);
    });
})();
</script>

</body>
</html>