<?php
session_start();

include("../connection.php");
include("../functions.php");

$user_data = require_role($con, "Adopter");
$uid       = $user_data['user_id'];

$success = "";
$error   = "";

if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    $action = $_POST['action'] ?? "";

    // Update email
    if ($action == "email")
    {
        $email = trim($_POST['email'] ?? "");

        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 100)
        {
            $error = "Please enter a valid email address.";
        }
        else
        {
            $stmt = mysqli_prepare($con, "SELECT id FROM users WHERE email = ? AND user_id <> ? LIMIT 1");
            mysqli_stmt_bind_param($stmt, "ss", $email, $uid);
            mysqli_stmt_execute($stmt);

            if (mysqli_fetch_assoc(mysqli_stmt_get_result($stmt)))
            {
                $error = "That email is already used by another account.";
            }
            else
            {
                $stmt = mysqli_prepare($con, "UPDATE users SET email = ? WHERE user_id = ?");
                mysqli_stmt_bind_param($stmt, "ss", $email, $uid);
                mysqli_stmt_execute($stmt);
                $success = "Email updated.";
            }
        }
    }

    // Change password
    if ($action == "password")
    {
        $current = $_POST['current_password'] ?? "";
        $new     = $_POST['new_password'] ?? "";
        $confirm = $_POST['confirm_password'] ?? "";

        if (!password_verify($current, $user_data['password']))
        {
            $error = "Your current password is incorrect.";
        }
        elseif (strlen($new) < 6)
        {
            $error = "Your new password must be at least 6 characters.";
        }
        elseif ($new !== $confirm)
        {
            $error = "The new passwords don't match.";
        }
        else
        {
            $hash = password_hash($new, PASSWORD_DEFAULT);

            $stmt = mysqli_prepare($con, "UPDATE users SET password = ? WHERE user_id = ?");
            mysqli_stmt_bind_param($stmt, "ss", $hash, $uid);
            mysqli_stmt_execute($stmt);
            $success = "Password changed.";
        }
    }

    // Reload the latest account data
    $user_data = check_login($con);
}

$user_name    = htmlspecialchars($user_data['user_name']);
$user_email   = htmlspecialchars($user_data['email']);
$user_initial = strtoupper(mb_substr($user_data['user_name'], 0, 1));
$member_since = date("F j, Y", strtotime($user_data['date']));

$page_kicker = "PROFILE";
$page_title  = "Your account";
$page_text   = "Manage your email and password.";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>PetAdopt | Profile</title>

    <!-- Google Fonts (same Nunito font as the dashboard and the other pages) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="../style/adopter_dashboard.css">

    <style>
    /* =========================================================
       Profile page - uses the same variables, fonts, radius,
       shadows and buttons as adopter_dashboard.css
       ========================================================= */

    /* ---------- Alerts ---------- */
    .pf-alert {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 20px;
        padding: 11px 16px;
        border: 1px solid transparent;
        border-radius: var(--radius-md);
        font-size: .82rem;
        font-weight: 700;
        box-shadow: var(--shadow-sm);
    }

    .pf-alert.alert-success {
        background: var(--sage-soft);
        border-color: var(--sage);
        color: var(--dark-green);
    }

    .pf-alert.alert-error {
        background: #FDECE2;
        border-color: #F3CDB6;
        color: #A5482A;
    }

    .pf-alert-icon {
        width: 22px;
        height: 22px;
        flex-shrink: 0;
        display: grid;
        place-items: center;
        border-radius: 50%;
        color: var(--white);
        font-size: .8rem;
        font-weight: 800;
    }

    .alert-success .pf-alert-icon { background: var(--green); }
    .alert-error .pf-alert-icon   { background: var(--orange-dark); }

    /* ---------- Account summary (same look as the tracker card) ---------- */
    .pf-hero {
        margin-bottom: 24px;
        padding: 22px 26px;
        display: flex;
        align-items: center;
        gap: 20px;
        background: linear-gradient(135deg, #FFF6EB 0%, #FBE0CA 100%);
        border: 1px solid #F0D3B8;
        border-radius: var(--radius-lg);
        box-shadow: var(--shadow-sm);
    }

    .pf-avatar {
        width: 60px;
        height: 60px;
        flex-shrink: 0;
        display: grid;
        place-items: center;
        background: var(--grad-green);
        border: 3px solid var(--white);
        border-radius: 50%;
        box-shadow: var(--shadow-md);
        color: var(--white);
        font-size: 1.5rem;
        font-weight: 800;
    }

    .pf-hero-info {
        flex: 1;
        min-width: 0;
    }

    .pf-hero-info > span {
        color: var(--green);
        font-size: .65rem;
        font-weight: 800;
        letter-spacing: 1.5px;
    }

    .pf-hero-info h2 {
        margin: 2px 0 0;
        color: var(--dark-green);
        font-size: 1.25rem;
        font-weight: 800;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .pf-hero-info p {
        color: var(--muted);
        font-size: .8rem;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .pf-stats {
        display: flex;
        gap: 14px;
    }

    .pf-stats div {
        padding: 8px 14px;
        background: rgba(255, 255, 255, 0.75);
        backdrop-filter: blur(4px);
        border: 1px solid rgba(255, 255, 255, 0.9);
        border-radius: var(--radius-sm);
    }

    .pf-stats small {
        display: block;
        color: var(--muted);
        font-size: .62rem;
        font-weight: 700;
        text-transform: uppercase;
    }

    .pf-stats strong {
        display: block;
        margin-top: 1px;
        color: var(--dark-green);
        font-size: .78rem;
        font-weight: 800;
    }

    /* ---------- Cards ---------- */
    .pf-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 20px;
        align-items: start;
    }

    .pf-card {
        position: relative;
        padding: 24px;
        background: var(--white);
        border: 1px solid var(--border);
        border-radius: var(--radius-lg);
        box-shadow: var(--shadow-sm);
        overflow: hidden;
        transition: transform var(--ease), box-shadow var(--ease);
    }

    .pf-card::before {
        content: "";
        position: absolute;
        top: 0; left: 0; right: 0;
        height: 4px;
    }

    .pf-card.green-top::before  { background: var(--green); }
    .pf-card.orange-top::before { background: var(--orange); }

    .pf-card:hover {
        transform: translateY(-3px);
        box-shadow: var(--shadow-md);
    }

    .pf-card-head {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 20px;
    }

    .pf-card-icon {
        width: 42px;
        height: 42px;
        flex-shrink: 0;
        display: grid;
        place-items: center;
        border-radius: 13px;
        font-size: 1.1rem;
    }

    .green-top .pf-card-icon  { background: var(--sage); }
    .orange-top .pf-card-icon { background: var(--peach); }

    .pf-card-head h2 {
        color: var(--dark-green);
        font-size: 1.05rem;
        font-weight: 800;
        letter-spacing: -0.2px;
    }

    .pf-card-head p {
        color: var(--muted);
        font-size: .76rem;
        line-height: 1.4;
    }

    /* ---------- Forms ---------- */
    .pf-form {
        display: flex;
        flex-direction: column;
        gap: 14px;
    }

    .pf-field {
        display: flex;
        flex-direction: column;
        gap: 6px;
    }

    .pf-field label {
        color: var(--dark-green);
        font-size: .76rem;
        font-weight: 800;
    }

    .pf-field input {
        width: 100%;
        padding: 9px 14px;
        background: var(--cream);
        border: 1.5px solid var(--border);
        border-radius: var(--radius-sm);
        color: var(--text);
        font-family: inherit;
        font-size: .82rem;
        font-weight: 600;
        transition: border-color var(--ease), box-shadow var(--ease), background var(--ease);
    }

    .pf-field input:hover {
        border-color: var(--sage);
    }

    .pf-field input:focus {
        outline: none;
        background: var(--white);
        border-color: var(--green);
        box-shadow: 0 0 0 4px rgba(79, 124, 89, .15);
    }

    .pf-password {
        position: relative;
    }

    .pf-password input {
        padding-right: 64px;
    }

    .pf-toggle {
        position: absolute;
        top: 50%;
        right: 8px;
        transform: translateY(-50%);
        padding: 5px 12px;
        background: transparent;
        border: none;
        border-radius: var(--radius-pill);
        color: var(--green);
        font-family: inherit;
        font-size: .68rem;
        font-weight: 800;
        cursor: pointer;
        transition: background var(--ease), color var(--ease);
    }

    .pf-toggle:hover {
        background: var(--sage);
        color: var(--dark-green);
    }

    .pf-toggle:focus-visible {
        outline: 3px solid var(--orange);
        outline-offset: 2px;
    }

    /* username box - same look as .pet-details */
    .pf-readonly {
        padding: 8px 14px;
        background: var(--cream);
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
    }

    .pf-readonly small {
        display: block;
        color: var(--muted);
        font-size: .6rem;
        font-weight: 700;
        letter-spacing: .5px;
        text-transform: uppercase;
    }

    .pf-readonly strong {
        display: block;
        color: var(--dark-green);
        font-size: .82rem;
        font-weight: 800;
    }

    /* ---------- Password strength ---------- */
    .pf-strength {
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .pf-strength-bar {
        flex: 1;
        height: 6px;
        background: var(--border);
        border-radius: var(--radius-pill);
        overflow: hidden;
    }

    .pf-strength-bar span {
        display: block;
        width: 0;
        height: 100%;
        border-radius: var(--radius-pill);
        transition: width var(--ease), background var(--ease);
    }

    .pf-strength-bar span.level-0 { background: #D9694A; width: 10% !important; }
    .pf-strength-bar span.level-1 { background: #D9694A; }
    .pf-strength-bar span.level-2 { background: var(--orange); }
    .pf-strength-bar span.level-3 { background: #7FA987; }
    .pf-strength-bar span.level-4 { background: var(--green); }

    .pf-strength small {
        min-width: 90px;
        color: var(--muted);
        font-size: .68rem;
        font-weight: 700;
        text-align: right;
    }

    .pf-hint {
        min-height: 1em;
        color: var(--muted);
        font-size: .7rem;
        font-weight: 700;
    }

    .pf-hint.ok  { color: var(--green); }
    .pf-hint.bad { color: #A5482A; }

    /* ---------- Button (uses the shared .btn pill) ---------- */
    .pf-btn {
        align-self: flex-start;
        padding: 10px 24px;
        font-size: .8rem;
    }

    .pf-btn:focus-visible {
        outline: 3px solid var(--orange);
        outline-offset: 2px;
    }

    /* ---------- Responsive (same breakpoints as the dashboard) ---------- */
    @media (max-width: 1100px) {
        .pf-hero { flex-wrap: wrap; }
        .pf-stats { width: 100%; }
    }

    @media (max-width: 850px) {
        .pf-grid { grid-template-columns: 1fr; }
    }

    @media (max-width: 600px) {
        .pf-hero {
            flex-direction: column;
            align-items: flex-start;
            padding: 20px;
        }

        .pf-stats {
            flex-direction: column;
            gap: 10px;
        }

        .pf-card { padding: 20px 16px; }

        .pf-btn {
            width: 100%;
            align-self: stretch;
            text-align: center;
        }
    }
    </style>
    <style>
        /* Hide the email + role pill at the top right */
        .topbar .profile,
        .topbar .user-info,
        .topbar .user-pill,
        .topbar .user-menu,
        .topbar .account {
            display: none !important;
        }
    </style>
    <style>
        /* Icons are SVG now: sized and colored to fit their circles */
        .pf-card-icon svg   { width: 22px; height: 22px; display: block; }
        .green-top .pf-card-icon  { color: var(--green); }
        .orange-top .pf-card-icon { color: var(--orange-dark, #E08B45); }
        .pf-alert-icon svg  { width: 13px; height: 13px; display: block; }

        /* Both cards the same height, buttons at the bottom */
        .pf-grid { align-items: stretch; }
        .pf-card { display: flex; flex-direction: column; }
        .pf-card .pf-form { flex: 1; }
        .pf-card .pf-btn  { margin-top: auto; }

        /* Same height for every field and the username box */
        .pf-field input {
            box-sizing: border-box;
            height: 44px;
            padding: 0 14px;
        }

        .pf-password input { padding-right: 70px; }

        .pf-readonly {
            box-sizing: border-box;
            min-height: 44px;
            padding: 6px 14px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        /* Same size pill buttons */
        .pf-btn {
            height: 44px;
            padding: 0 28px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        /* Role + Member since sit side by side inside the email card */
        .pf-readonly-row {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 14px;
        }

        .pf-readonly strong {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        /* Same vertical rhythm in both cards: rows spread evenly, button at the bottom */
        .pf-form {
            gap: 16px;
            justify-content: space-between;
        }

        .pf-hint { min-height: 0; }
        .pf-hint:empty { display: none; }

        .pf-field { gap: 8px; }

        /* Left card rows match the height of the password fields (label + 44px box) */
        .pf-readonly { min-height: 52px; }
        .pf-readonly-row .pf-readonly { min-height: 52px; }

        /* Every control uses the same Nunito font as the rest of the site */
        .pf-card input,
        .pf-card button,
        .pf-card label,
        .pf-card small,
        .pf-card strong,
        .pf-card h2,
        .pf-card p,
        .pf-hero h2,
        .pf-hero p,
        .pf-hero span {
            font-family: var(--font);
        }

        /* Strength bar + helper text: same weight and size as the dashboard's small text */
        .pf-strength small,
        .pf-hint {
            font-size: .72rem;
            font-weight: 700;
            color: var(--muted);
        }

        .pf-strength-bar { height: 6px; background: var(--border); }
        .pf-hint.ok  { color: var(--green); }
        .pf-hint.bad { color: #A5482A; }

        /* Keep the cards level (no lift on hover) so the two columns stay aligned */
        .pf-card:hover { transform: none; }

        /* Hero: slimmer, same height as the other cards' header area */
        .pf-hero { padding: 20px 26px; }

        @media (max-width: 600px) {
            .pf-readonly-row { grid-template-columns: 1fr; }
        }
    </style>
</head>

<body>

<div class="dashboard">

    <?php $active = "profile"; include("sidebar.php"); ?>

    <main class="main-content">

        <?php include("topbar.php"); ?>

        <?php if ($success !== ""): ?>
            <p class="alert alert-success pf-alert" role="status">
                <span class="pf-alert-icon" aria-hidden="true"><svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12l5 5 9-10"/></svg></span>
                <?php echo htmlspecialchars($success); ?>
            </p>
        <?php endif; ?>

        <?php if ($error !== ""): ?>
            <p class="alert alert-error pf-alert" role="alert">
                <span class="pf-alert-icon" aria-hidden="true"><svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 7v6"/><path d="M12 17h.01"/></svg></span>
                <?php echo htmlspecialchars($error); ?>
            </p>
        <?php endif; ?>

        <!-- Account summary -->
        <section class="pf-hero">

            <div class="pf-avatar" aria-hidden="true"><?php echo htmlspecialchars($user_initial); ?></div>

            <div class="pf-hero-info">
                <span>ADOPTER ACCOUNT</span>
                <h2><?php echo $user_name; ?></h2>
                <p><?php echo $user_email; ?></p>
            </div>

        </section>

        <section class="pf-grid">

            <!-- Email -->
            <article class="pf-card green-top">

                <header class="pf-card-head">
                    <span class="pf-card-icon" aria-hidden="true"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M3 8l9 6 9-6"/></svg></span>
                    <div>
                        <h2>Email address</h2>
                        <p>Used to contact you about your adoption requests.</p>
                    </div>
                </header>

                <form method="post" class="pf-form">

                    <input type="hidden" name="action" value="email">

                    <div class="pf-field">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" maxlength="100"
                               value="<?php echo $user_email; ?>" autocomplete="email" required>
                    </div>

                    <div class="pf-readonly">
                        <small>Username</small>
                        <strong><?php echo $user_name; ?></strong>
                    </div>

                    <div class="pf-readonly-row">
                        <div class="pf-readonly">
                            <small>Role</small>
                            <strong>Adopter</strong>
                        </div>
                        <div class="pf-readonly">
                            <small>Member since</small>
                            <strong><?php echo $member_since; ?></strong>
                        </div>
                    </div>

                    <button type="submit" class="btn pf-btn">Save email</button>

                </form>

            </article>

            <!-- Password -->
            <article class="pf-card orange-top">

                <header class="pf-card-head">
                    <span class="pf-card-icon" aria-hidden="true"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="3"/><path d="M8 11V8a4 4 0 018 0v3"/></svg></span>
                    <div>
                        <h2>Change password</h2>
                        <p>Use at least 6 characters. Longer is safer.</p>
                    </div>
                </header>

                <form method="post" class="pf-form" id="passwordForm">

                    <input type="hidden" name="action" value="password">

                    <div class="pf-field">
                        <label for="current_password">Current password</label>
                        <div class="pf-password">
                            <input type="password" id="current_password" name="current_password"
                                   autocomplete="current-password" required>
                            <button type="button" class="pf-toggle" data-target="current_password"
                                    aria-label="Show password">Show</button>
                        </div>
                    </div>

                    <div class="pf-field">
                        <label for="new_password">New password</label>
                        <div class="pf-password">
                            <input type="password" id="new_password" name="new_password"
                                   minlength="6" autocomplete="new-password" required>
                            <button type="button" class="pf-toggle" data-target="new_password"
                                    aria-label="Show password">Show</button>
                        </div>
                    </div>

                    <div class="pf-field">
                        <label for="confirm_password">Confirm new password</label>
                        <div class="pf-password">
                            <input type="password" id="confirm_password" name="confirm_password"
                                   minlength="6" autocomplete="new-password" required>
                            <button type="button" class="pf-toggle" data-target="confirm_password"
                                    aria-label="Show password">Show</button>
                        </div>
                        <small class="pf-hint" id="matchText" aria-live="polite"></small>
                    </div>

                    <button type="submit" class="btn pf-btn">Change password</button>

                </form>

            </article>

        </section>

    </main>

</div>

<script>
(function () {
    // Show / hide password
    document.querySelectorAll(".pf-toggle").forEach(function (btn) {
        btn.addEventListener("click", function () {
            var input = document.getElementById(btn.dataset.target);
            var show  = input.type === "password";
            input.type = show ? "text" : "password";
            btn.textContent = show ? "Hide" : "Show";
            btn.setAttribute("aria-label", show ? "Hide password" : "Show password");
        });
    });

    // Match feedback
    var pw      = document.getElementById("new_password");
    var confirm = document.getElementById("confirm_password");
    var match   = document.getElementById("matchText");

    function updateMatch() {
        if (confirm.value === "") { match.textContent = ""; match.className = "pf-hint"; return; }
        var ok = confirm.value === pw.value;
        match.textContent = ok ? "Passwords match" : "Passwords don't match yet";
        match.className = "pf-hint " + (ok ? "ok" : "bad");
    }

    pw.addEventListener("input", updateMatch);
    confirm.addEventListener("input", updateMatch);
})();
</script>

</body>
</html>