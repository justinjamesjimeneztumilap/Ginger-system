<?php
// Shared sidebar. Set $active before including (dashboard, browse, requests, pets, profile)
$active = $active ?? "";

// Inline SVG icons (they take the color of the link they sit in)
$svg = function ($paths) {
    return '<svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $paths . '</svg>';
};

$icons = [
    "dashboard" => $svg('<rect x="3" y="3" width="7" height="9" rx="2"/><rect x="14" y="3" width="7" height="5" rx="2"/><rect x="14" y="12" width="7" height="9" rx="2"/><rect x="3" y="16" width="7" height="5" rx="2"/>'),
    "browse"    => $svg('<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>'),
    "requests"  => $svg('<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>'),
    "pets"      => $svg('<circle cx="6" cy="10" r="2"/><circle cx="10" cy="5.5" r="2"/><circle cx="14" cy="5.5" r="2"/><circle cx="18" cy="10" r="2"/><path d="M12 11c-3 0-5.5 3-5.5 5.5 0 2 1.6 3 3.2 3 1 0 1.5-.4 2.3-.4s1.3.4 2.3.4c1.6 0 3.2-1 3.2-3C17.5 14 15 11 12 11z"/>'),
    "profile"   => $svg('<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/>'),
    "logout"    => $svg('<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/>'),
];

$links = [
    "dashboard" => ["dashboard.php",   $icons["dashboard"], "Dashboard"],
    "browse"    => ["browse_pets.php", $icons["browse"],    "Browse Pets"],
    "requests"  => ["my_requests.php", $icons["requests"],  "My Requests"],
    "pets"      => ["my_pets.php",     $icons["pets"],      "My Pets"],
    "profile"   => ["profile.php",     $icons["profile"],   "Profile"],
];
?>
<!-- Link the dedicated sidebar stylesheet -->
<link rel="stylesheet" href="../style/sidebar.css">

<style>
    /* Even icon + label alignment for every sidebar item */
    .sidebar .logo,
    .sidebar nav a,
    .sidebar .logout {
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .sidebar .nav-icon {
        width: 20px;
        height: 20px;
        flex-shrink: 0;
        display: block;
    }

    .sidebar .logo .nav-icon {
        width: 26px;
        height: 26px;
    }

    .sidebar nav a span,
    .sidebar .logout span {
        line-height: 1;
    }
</style>

<aside class="sidebar">

    <a href="dashboard.php" class="logo">
        <?php echo $icons["pets"]; ?>
        <b>Pet<span>Adopt</span></b>
    </a>

    <nav>
        <?php foreach ($links as $key => $link): ?>
            <a href="<?php echo $link[0]; ?>"<?php echo ($key === $active) ? ' class="active"' : ''; ?>>
                <?php echo $link[1]; ?>
                <span><?php echo $link[2]; ?></span>
            </a>
        <?php endforeach; ?>
    </nav>

    <a href="../logout.php" class="logout" id="logoutLink">
        <?php echo $icons["logout"]; ?>
        <span>Logout</span>
    </a>

</aside>

<!-- Logout confirmation -->
<div class="logout-overlay" id="logoutModal" hidden>
    <div class="logout-dialog" role="dialog" aria-modal="true" aria-labelledby="logoutTitle" aria-describedby="logoutText">

        <div class="logout-dialog-icon"><?php echo $icons["logout"]; ?></div>

        <h2 id="logoutTitle">Log out of PetAdopt?</h2>
        <p id="logoutText">Are you sure you want to log out? You will need to sign in again to send requests or see your pets.</p>

        <div class="logout-dialog-actions">
            <button type="button" class="logout-btn logout-cancel" id="logoutCancel">Stay logged in</button>
            <a href="../logout.php" class="logout-btn logout-confirm">Yes, log out</a>
        </div>

    </div>
</div>

<style>
    .logout-overlay {
        position: fixed;
        inset: 0;
        z-index: 1000;
        display: grid;
        place-items: center;
        padding: 20px;
        background: rgba(47, 79, 55, .35);
        backdrop-filter: blur(3px);
        animation: logout-fade .2s ease;
    }

    .logout-overlay[hidden] { display: none; }

    .logout-dialog {
        width: 100%;
        max-width: 400px;
        padding: 30px 28px 26px;
        text-align: center;
        background: var(--white, #FFFFFF);
        border: 1px solid var(--border, #E8E6DC);
        border-radius: 28px;
        box-shadow: 0 24px 60px rgba(47, 79, 55, .22);
        animation: logout-pop .25s cubic-bezier(.4, 0, .2, 1);
        font-family: var(--font, "Nunito", system-ui, sans-serif);
    }

    .logout-dialog-icon {
        width: 56px;
        height: 56px;
        margin: 0 auto 16px;
        display: grid;
        place-items: center;
        background: var(--peach, #FBE0CA);
        border-radius: 18px;
        color: var(--orange-dark, #E08B45);
    }

    .logout-dialog-icon svg { width: 26px; height: 26px; display: block; }

    .logout-dialog h2 {
        margin: 0 0 6px;
        color: var(--dark-green, #2F4F37);
        font-size: 1.25rem;
        font-weight: 800;
        letter-spacing: -.2px;
    }

    .logout-dialog p {
        margin: 0 0 24px;
        color: var(--muted, #6B7369);
        font-size: .85rem;
        font-weight: 600;
        line-height: 1.5;
    }

    .logout-dialog-actions {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 12px;
    }

    .logout-btn {
        height: 44px;
        box-sizing: border-box;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 0 16px;
        border: 1px solid transparent;
        border-radius: 999px;
        font-family: inherit;
        font-size: .82rem;
        font-weight: 800;
        text-decoration: none;
        cursor: pointer;
        transition: background .25s ease, color .25s ease, transform .25s ease, box-shadow .25s ease;
    }

    .logout-cancel {
        background: var(--sage-soft, #EEF4EA);
        color: var(--dark-green, #2F4F37);
    }

    .logout-cancel:hover { background: var(--sage, #DCE9D8); }

    .logout-confirm {
        background: var(--grad-green, linear-gradient(135deg, #5E8F69, #4F7C59 55%, #3F6A49));
        color: #fff;
        box-shadow: 0 6px 18px rgba(79, 124, 89, .25);
    }

    .logout-confirm:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 22px rgba(79, 124, 89, .35);
    }

    .logout-btn:focus-visible {
        outline: 3px solid var(--orange, #F4A261);
        outline-offset: 2px;
    }

    @keyframes logout-fade { from { opacity: 0; } to { opacity: 1; } }
    @keyframes logout-pop  { from { opacity: 0; transform: translateY(10px) scale(.97); } to { opacity: 1; transform: none; } }

    @media (max-width: 420px) {
        .logout-dialog-actions { grid-template-columns: 1fr; }
    }

    @media (prefers-reduced-motion: reduce) {
        .logout-overlay, .logout-dialog { animation: none; }
        .logout-btn { transition: none; }
    }
</style>

<script>
(function () {
    var link    = document.getElementById("logoutLink");
    var modal   = document.getElementById("logoutModal");
    var cancel  = document.getElementById("logoutCancel");
    var confirm = modal ? modal.querySelector(".logout-confirm") : null;

    if (!link || !modal) { return; }

    function open() {
        modal.hidden = false;
        document.body.style.overflow = "hidden";
        cancel.focus();
    }

    function close() {
        modal.hidden = true;
        document.body.style.overflow = "";
        link.focus();
    }

    link.addEventListener("click", function (e) { e.preventDefault(); open(); });
    cancel.addEventListener("click", close);

    // Click on the dark background closes it too
    modal.addEventListener("click", function (e) { if (e.target === modal) { close(); } });

    document.addEventListener("keydown", function (e) {
        if (modal.hidden) { return; }
        if (e.key === "Escape") { close(); }

        // Keep the Tab key inside the dialog
        if (e.key === "Tab") {
            var first = cancel, last = confirm;
            if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
            else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
        }
    });
})();
</script>