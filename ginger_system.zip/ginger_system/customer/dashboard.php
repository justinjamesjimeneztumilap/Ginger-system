<?php
session_start();

include("../connection.php");
include("../functions.php");
include("../icons.php");

// Only logged-in adopters can see this page
$user_data = require_role($con, "Adopter");
$uid       =$user_data['user_id'];
$user_name = htmlspecialchars($user_data['user_name']);

// Small helper: run a COUNT query with optional user id
function count_rows($con, $sql,$uid = null)
{
    $stmt = mysqli_prepare($con,$sql);
    if ($uid !== null) { mysqli_stmt_bind_param($stmt, "s", $uid); }
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_row(mysqli_stmt_get_result($stmt));
    return (int)$row[0];
}

$available_pets = count_rows($con, "SELECT COUNT(*) FROM pets WHERE status = 'Available'");
$my_requests    = count_rows($con, "SELECT COUNT(*) FROM adoption_requests WHERE user_id = ?", $uid);
$my_adopted     = count_rows($con, "SELECT COUNT(*) FROM adoption_requests WHERE user_id = ? AND status = 'Approved'", $uid);

// newest available pets (shown 7 per page, up to 3 pages)
$pets = mysqli_query($con, "SELECT id, name, species, breed, age, photo FROM pets WHERE status = 'Available' ORDER BY created_at DESC, id DESC LIMIT 21");

// latest adoption requests (any status, shown 7 per page, up to 3 pages)
$stmt = mysqli_prepare($con, "SELECT r.status, r.updated_at, p.name, p.species, p.breed, p.age, p.photo
                              FROM adoption_requests r JOIN pets p ON p.id = r.pet_id
                              WHERE r.user_id = ?
                              ORDER BY r.updated_at DESC LIMIT 21");
mysqli_stmt_bind_param($stmt, "s", $uid);
mysqli_stmt_execute($stmt);
$recent_requests = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);

// Journey progress
$step_submit   =$my_requests > 0;
$step_approved =$my_adopted > 0;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>PetAdopt | Dashboard</title>

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="../style/adopter_dashboard.css">

    <style>
        /* Summary card icons (SVG) take the color of their card */
        .summary-icon svg { display: block; }
        .green-card .summary-icon  { color: #4F7C59; }
        .orange-card .summary-icon { color: #E08B45; }
        .brown-card .summary-icon  { color: #A67C52; }
    </style>
    <style>
        /* Hide the email + role pill at the top right */
        .topbar .profile,
        .topbar .user-info,
        .topbar .user-pill,
        .topbar .user-menu,
        .topbar .account {
            display: none !important;
        }
    </style>
    <style>
        /* Keep every pet card the same height so the buttons line up */
        .pet-list { align-items: stretch; }

        .pet-card {
            display: flex;
            flex-direction: column;
            height: 100%;
        }

        .pet-card .pet-info {
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        /* Reserve two lines for "breed - age" so long text can't push things down */
        .pet-card .pet-info h3 + p {
            min-height: 2.8em;
            line-height: 1.4;
        }

        /* Pin the button to the bottom of the card */
        .pet-card .pet-info > a:last-child {
            margin-top: auto;
        }
    </style>
    <style>
        /* Nudge the "View Pet" text up by 1px */
        .pet-card .pet-info > a:last-child {
            position: relative;
            top: -1px;
        }
    </style>
    <style>
        /* Pet name inside the link: keep it on one line */
        .pet-card .pet-info > a:last-child {
            max-width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
    </style>
    <style>
        /* Balanced details box (same look as the Browse Pets cards) */
        .pet-card .pet-info p.meta-box {
            margin: 10px 0 14px;
            padding: 12px 14px;
            display: flex;
            flex-direction: column;
            gap: 10px;
            min-height: 0;
            text-align: left;
            background: var(--cream, #FFF6EE);
            border: 1px solid var(--border, #F0E4D6);
            border-radius: 16px;
        }

        .pet-card .meta-row {
            display: block;
            min-width: 0;
        }

        .pet-card .meta-row small {
            display: block;
            margin-bottom: 2px;
            color: var(--muted, #6B7369);
            font-size: .6rem;
            font-weight: 800;
            letter-spacing: .8px;
            text-transform: uppercase;
        }

        .pet-card .meta-row strong {
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 1;
            overflow: hidden;
            overflow-wrap: anywhere;
            color: var(--dark-green, #2F4F37);
            font-size: .8rem;
            font-weight: 800;
            line-height: 1.3;
        }

        /* Breed reserves two lines so every card stays the same height */
        .pet-card .meta-row:first-child strong {
            -webkit-line-clamp: 2;
            min-height: 2.6em;
        }
    </style>
    <style>
        /* ===== Carousel: swipe / arrow through the pet and request cards ===== */
        .pets-section .pet-list {
            display: flex !important;
            grid-template-columns: none !important;
            gap: 18px !important;
            overflow-x: auto;
            scroll-snap-type: x mandatory;
            scroll-padding-left: 4px;
            scroll-behavior: smooth;
            scrollbar-width: none;
            -ms-overflow-style: none;
            /* room so hover lift and shadows are not clipped */
            padding: 8px 4px 20px;
            margin: -8px -4px -20px;
        }

        .pets-section .pet-list::-webkit-scrollbar { display: none; }

        /* 4 cards visible on desktop */
        .pets-section .pet-list > .pet-card {
            flex: 0 0 calc((100% - 108px) / 7);
            min-width: 0;
            max-width: none;
            height: auto;
            scroll-snap-align: start;
        }

        .pets-section .pet-list > p { flex: 1 0 100%; }

        @media (max-width: 1200px) {
            .pets-section .pet-list > .pet-card { flex-basis: calc((100% - 54px) / 4); }
        }

        @media (max-width: 850px) {
            .pets-section .pet-list > .pet-card { flex-basis: calc((100% - 18px) / 2); }
        }

        @media (max-width: 520px) {
            .pets-section .pet-list > .pet-card { flex-basis: 100%; }
        }

        .carousel { position: relative; }

        .carousel-btn {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            z-index: 5;
            width: 44px;
            height: 44px;
            display: grid;
            place-items: center;
            padding: 0;
            background: var(--white, #FFFFFF);
            border: 1px solid var(--border, #E8E6DC);
            border-radius: 50%;
            box-shadow: 0 6px 18px rgba(47, 79, 55, .15);
            color: var(--green, #4F7C59);
            cursor: pointer;
            transition: background .25s ease, color .25s ease, opacity .25s ease, transform .25s ease;
        }

        .carousel-btn svg { width: 20px; height: 20px; display: block; }

        .carousel-btn.prev { left: -16px; }
        .carousel-btn.next { right: -16px; }

        .carousel-btn:hover:not(:disabled) {
            background: var(--green, #4F7C59);
            color: #fff;
            transform: translateY(-50%) scale(1.06);
        }

        .carousel-btn:focus-visible {
            outline: 3px solid rgba(79, 124, 89, .35);
            outline-offset: 2px;
        }

        .carousel-btn:disabled,
        .carousel-btn[hidden] {
            opacity: 0;
            pointer-events: none;
        }

        @media (max-width: 600px) {
            .carousel-btn { width: 38px; height: 38px; }
            .carousel-btn.prev { left: -8px; }
            .carousel-btn.next { right: -8px; }
        }

        @media (prefers-reduced-motion: reduce) {
            .pets-section .pet-list { scroll-behavior: auto; }
            .carousel-btn { transition: none; }
        }
    </style>
    <style>
        /* Details box always fills the full card width */
        .pet-card .pet-info p.meta-box {
            align-self: stretch;
            width: 100%;
            box-sizing: border-box;
        }
    </style>
</head>

<body>

<div class="dashboard">

    <!-- SIDEBAR -->
    <?php $active = "dashboard"; include("sidebar.php"); ?>


    <!-- MAIN CONTENT -->
    <main class="main-content">

        <!-- TOP BAR -->
        <header class="topbar">

            <div>
                <p class="small-title">PETADOPT DASHBOARD</p>
                <h1>Welcome back, <?php echo $user_name; ?>!</h1>
                <p class="welcome-text">
                    Find your new best friend today.
                </p>
            </div>

            <div class="profile">
                <div class="profile-icon"><?php echo icon("paw", 20, "color:#4F7C59"); ?></div>

                <div>
                    <strong><?php echo $user_name; ?></strong>
                    <small>Adopter</small>
                </div>
            </div>

        </header>


        <!-- SUMMARY CARDS -->
        <section class="summary">

            <article class="summary-card green-card">
                <div class="summary-icon"><?php echo icon("paw", 26); ?></div>

                <div>
                    <p>Available Pets</p>
                    <h2><?php echo $available_pets; ?></h2>
                </div>
            </article>


            <article class="summary-card orange-card">
                <div class="summary-icon"><?php echo icon("mail", 26); ?></div>

                <div>
                    <p>My Requests</p>
                    <h2><?php echo $my_requests; ?></h2>
                </div>
            </article>


            <article class="summary-card brown-card">
                <div class="summary-icon"><?php echo icon("home", 26); ?></div>

                <div>
                    <p>My Adopted Pets</p>
                    <h2><?php echo $my_adopted; ?></h2>
                </div>
            </article>

        </section>


        <!-- AVAILABLE PETS -->
        <section class="pets-section">

            <div class="section-heading">
                <div>
                    <span><?php echo icon("paw", 14, "vertical-align:-2px;margin-right:6px"); ?>MEET THE PETS</span>
                    <h2>Pets waiting for a home</h2>
                </div>

                <a href="browse_pets.php">See all →</a>
            </div>


            <div class="pet-list">

                <?php if ($pets && mysqli_num_rows($pets) > 0): ?>
                    <?php while ($pet = mysqli_fetch_assoc($pets)): ?>
                        <?php list($cls, $emoji) = pet_look($pet['species']); ?>

                        <article class="pet-card">

                            <div class="pet-photo emoji <?php echo $cls; ?>">
                                <?php if (!empty($pet['photo'])): ?>
                                    <img class="pet-photo-img" src="../uploads/pets/<?php echo htmlspecialchars($pet['photo']); ?>" alt="<?php echo htmlspecialchars($pet['name']); ?>" loading="lazy">
                                <?php else: ?>
                                    <?php echo pet_icon($cls); ?>
                                <?php endif; ?>
                            </div>

                            <div class="pet-info">

                                <span class="available">
                                    ● Available
                                </span>

                                <h3><?php echo htmlspecialchars($pet['species']); ?></h3>

                                <p class="meta-box">
                                    <span class="meta-row">
                                        <small>Breed</small>
                                        <strong title="<?php echo htmlspecialchars($pet['breed']); ?>"><?php echo htmlspecialchars($pet['breed']); ?></strong>
                                    </span>
                                    <span class="meta-row">
                                        <small>Age</small>
                                        <strong><?php echo htmlspecialchars($pet['age']); ?></strong>
                                    </span>
                                </p>

                                <a href="pet_details.php?id=<?php echo (int)$pet['id']; ?>" title="View <?php echo htmlspecialchars($pet['name']); ?>">
                                    <?php echo htmlspecialchars($pet['name']); ?>
                                </a>

                            </div>

                        </article>

                    <?php endwhile; ?>
                <?php else: ?>
                    <p class="welcome-text">No pets are available right now. Please check back soon.</p>
                <?php endif; ?>

            </div>

        </section>


        <!-- ADOPTION JOURNEY -->
        <section class="journey">

            <div class="journey-heading">
                <span><?php echo icon("leaf", 14, "vertical-align:-2px;margin-right:6px"); ?>YOUR ADOPTION JOURNEY</span>

                <h2>Every step brings you closer.</h2>
            </div>

            <div class="steps">

                <div class="step completed">
                    <div><?php echo icon("tick", 18); ?></div>
                    <p>Browse Pets</p>
                </div>

                <span class="line <?php echo $step_submit ? 'completed' : ''; ?>"></span>

                <div class="step <?php echo $step_submit ? 'completed' : ''; ?>">
                    <div><?php echo $step_submit ? icon("tick", 18) : "2"; ?></div>
                    <p>Submit Request</p>
                </div>

                <span class="line <?php echo ($step_submit &&$step_approved) ? 'completed' : ''; ?>"></span>

                <div class="step <?php echo $step_approved ? 'completed' : ''; ?>">
                    <div><?php echo $step_approved ? icon("tick", 18) : "3"; ?></div>
                    <p>Approval</p>
                </div>

                <span class="line <?php echo $step_approved ? 'completed' : ''; ?>"></span>

                <div class="step <?php echo $step_approved ? 'completed' : ''; ?>">
                    <div><?php echo $step_approved ? icon("tick", 18) : "4"; ?></div>
                    <p>Welcome Home</p>
                </div>

            </div>

        </section>


        <!-- PET TRACKER -->
        <section class="pets-section">

            <div class="section-heading">
                <div>
               
                    <h2>Latest request updates</h2>
                </div>

                <a href="my_requests.php">See all →</a>
            </div>

            <div class="pet-list">

                <?php if (!empty($recent_requests)): ?>
                    <?php foreach ($recent_requests as $req): ?>
                        <?php list($cls, $emoji) = pet_look($req['species']); ?>

                        <article class="pet-card">

                            <div class="pet-photo emoji <?php echo $cls; ?>">
                                <?php if (!empty($req['photo'])): ?>
                                    <img class="pet-photo-img" src="../uploads/pets/<?php echo htmlspecialchars($req['photo']); ?>" alt="<?php echo htmlspecialchars($req['name']); ?>" loading="lazy">
                                <?php else: ?>
                                    <?php echo pet_icon($cls); ?>
                                <?php endif; ?>
                            </div>

                            <div class="pet-info">

                                <span class="available status-<?php echo strtolower(htmlspecialchars($req['status'])); ?>">
                                    ● <?php echo htmlspecialchars($req['status']); ?>
                                </span>

                                <h3><?php echo htmlspecialchars($req['name']); ?></h3>

                                <p class="meta-box">
                                    <span class="meta-row">
                                        <small>Breed</small>
                                        <strong title="<?php echo htmlspecialchars($req['breed']); ?>"><?php echo htmlspecialchars($req['breed']); ?></strong>
                                    </span>
                                    <span class="meta-row">
                                        <small>Age</small>
                                        <strong><?php echo htmlspecialchars($req['age']); ?></strong>
                                    </span>
                                    <span class="meta-row">
                                        <small>Updated</small>
                                        <strong><?php echo date("M j, Y", strtotime($req['updated_at'])); ?></strong>
                                    </span>
                                </p>

                                <a href="my_requests.php">
                                    View Request →
                                </a>

                            </div>

                        </article>

                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="welcome-text">You haven't sent any requests yet. <a href="browse_pets.php">Browse pets →</a></p>
                <?php endif; ?>

            </div>

        </section>

    </main>

</div>

<script>
(function () {
    var GAP = 18;
    var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    var chevronLeft  = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 5l-7 7 7 7"/></svg>';
    var chevronRight = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 5l7 7-7 7"/></svg>';

    function makeButton(kind, label, icon) {
        var b = document.createElement("button");
        b.type = "button";
        b.className = "carousel-btn " + kind;
        b.setAttribute("aria-label", label);
        b.innerHTML = icon;
        return b;
    }

    document.querySelectorAll(".pets-section .pet-list").forEach(function (list) {

        var wrap = document.createElement("div");
        wrap.className = "carousel";
        list.parentNode.insertBefore(wrap, list);
        wrap.appendChild(list);

        if (!list.querySelector(".pet-card")) { return; }

        var prev = makeButton("prev", "Previous", chevronLeft);
        var next = makeButton("next", "Next", chevronRight);
        wrap.appendChild(prev);
        wrap.appendChild(next);

        function step() {
            var card = list.querySelector(".pet-card");
            return card ? card.getBoundingClientRect().width + GAP : 300;
        }

        function perPage() {
            return Math.max(1, Math.round(list.clientWidth / step()));
        }

        function update() {
            var canScroll = list.scrollWidth > list.clientWidth + 2;
            prev.hidden = next.hidden = !canScroll;
            prev.disabled = list.scrollLeft <= 2;
            next.disabled = list.scrollLeft + list.clientWidth >= list.scrollWidth - 2;
        }

        function go(dir) {
            list.scrollBy({ left: dir * step() * perPage(), behavior: reduce ? "auto" : "smooth" });
        }

        prev.addEventListener("click", function () { go(-1); });
        next.addEventListener("click", function () { go(1); });
        list.addEventListener("scroll", update, { passive: true });
        window.addEventListener("resize", update);
        update();
    });
})();
</script>

</body>
</html>