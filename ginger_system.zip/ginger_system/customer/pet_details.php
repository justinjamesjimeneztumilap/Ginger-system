<?php
session_start();

include("../connection.php");
include("../functions.php");
include("../icons.php");

$user_data = require_role($con, "Adopter");
$uid       = $user_data['user_id'];
$user_name = htmlspecialchars($user_data['user_name']);

$pet_id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);

function load_pet($con, $pet_id)
{
    $stmt = mysqli_prepare($con, "SELECT * FROM pets WHERE id = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, "i", $pet_id);
    mysqli_stmt_execute($stmt);
    return mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
}

$pet = load_pet($con, $pet_id);

if (!$pet)
{
    header("Location: browse_pets.php");
    die;
}

$error = "";

// Send an adoption request
if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    $message = trim($_POST['message'] ?? "");

    if (strlen($message) > 500)
    {
        $error = "Your message is too long. Please keep it under 500 characters.";
    }
    else
    {
        mysqli_begin_transaction($con);

        // Only one request can hold a pet at a time
        $stmt = mysqli_prepare($con, "UPDATE pets SET status = 'Pending' WHERE id = ? AND status = 'Available'");
        mysqli_stmt_bind_param($stmt, "i", $pet_id);
        mysqli_stmt_execute($stmt);

        if (mysqli_stmt_affected_rows($stmt) === 1)
        {
            $stmt = mysqli_prepare($con, "INSERT INTO adoption_requests (user_id, pet_id, message) VALUES (?, ?, ?)");
            mysqli_stmt_bind_param($stmt, "sis", $uid, $pet_id, $message);

            if (mysqli_stmt_execute($stmt))
            {
                mysqli_commit($con);
                header("Location: my_requests.php?sent=1");
                die;
            }
        }

        mysqli_rollback($con);
        $error = "Sorry, this pet is no longer available for requests.";
        $pet = load_pet($con, $pet_id);
    }
}

// Does this adopter already have a request for this pet?
$stmt = mysqli_prepare($con, "SELECT status FROM adoption_requests WHERE user_id = ? AND pet_id = ? ORDER BY id DESC LIMIT 1");
mysqli_stmt_bind_param($stmt, "si", $uid, $pet_id);
mysqli_stmt_execute($stmt);
$my_request = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

list($cls, $emoji) = pet_look($pet['species']);

$page_kicker = "PET DETAILS";
$page_title  = htmlspecialchars($pet['name']);
$page_text   = htmlspecialchars($pet['breed']) . " &bull; " . htmlspecialchars($pet['age']);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>PetAdopt | <?php echo htmlspecialchars($pet['name']); ?></title>

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="../style/pet_details.css">

    <style>
        /* Real pet photo in the profile card */
        .avatar-backdrop .pet-photo-img {
            position: relative;
            z-index: 2;
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            object-position: center 30%;
            border: 3px solid #fff;
            box-shadow: 0 6px 16px rgba(47, 79, 55, .18);
        }
    </style>
    <style>
        /* Hide the email + role pill at the top right */
        .topbar .profile,
        .topbar .user-info,
        .topbar .user-pill,
        .topbar .user-menu,
        .topbar .account {
            display: none !important;
        }
    </style>
</head>

<body>

<div class="dashboard">

    <?php $active = "browse"; include("sidebar.php"); ?>

    <main class="main-content">

        <?php include("topbar.php"); ?>

        <a href="browse_pets.php" class="back-link">&larr; Back to all pets</a>

        <?php if ($error !== ""): ?>
            <p class="alert alert-error" role="alert"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <section class="detail-container">

            <div class="detail-avatar-card">
                <div class="avatar-backdrop <?php echo $cls; ?>">
                    <?php if (!empty($pet['photo'])): ?>
                        <img class="pet-photo-img" src="../uploads/pets/<?php echo htmlspecialchars($pet['photo']); ?>" alt="<?php echo htmlspecialchars($pet['name']); ?>">
                    <?php else: ?>
                        <span class="avatar-emoji"><?php echo pet_icon($cls, 56); ?></span>
                    <?php endif; ?>
                </div>
                <span class="status-badge badge-<?php echo strtolower($pet['status']); ?>">
                    ● <?php echo htmlspecialchars($pet['status']); ?>
                </span>
            </div>

            <div class="detail-content-card">

                <div class="profile-header">
                    <h2><?php echo htmlspecialchars($pet['name']); ?></h2>
                </div>

                <div class="tracker-details">
                    <div class="detail-item">
                        <small>Breed</small>
                        <strong><?php echo htmlspecialchars($pet['breed']); ?></strong>
                    </div>
                    <div class="detail-item">
                        <small>Age</small>
                        <strong><?php echo htmlspecialchars($pet['age']); ?></strong>
                    </div>
                    <div class="detail-item">
                        <small>Gender</small>
                        <strong><?php echo htmlspecialchars($pet['gender']); ?></strong>
                    </div>
                    <div class="detail-item">
                        <small>Health</small>
                        <strong><?php echo htmlspecialchars($pet['health_status']); ?></strong>
                    </div>
                </div>

                <?php if (!empty($pet['description'])): ?>
                    <div class="description-box">
                        <small class="box-label">About <?php echo htmlspecialchars($pet['name']); ?></small>
                        <p><?php echo nl2br(htmlspecialchars($pet['description'])); ?></p>
                    </div>
                <?php endif; ?>

                <?php if ($pet['status'] == "Available"): ?>

                    <form method="post" class="form-card">

                        <input type="hidden" name="id" value="<?php echo (int)$pet['id']; ?>">

                        <label for="message">Why would you like to adopt <?php echo htmlspecialchars($pet['name']); ?>? (optional)</label>
                        <textarea id="message" name="message" rows="3" maxlength="500" placeholder="Tell us a little about your home and family..."></textarea>

                        <button type="submit" class="btn btn-primary">Send adoption request <?php echo icon("heart", 16, "vertical-align:-3px;margin-left:4px"); ?></button>

                    </form>

                <?php elseif ($my_request): ?>

                    <p class="alert alert-info">
                        You already sent a request for <?php echo htmlspecialchars($pet['name']); ?>.
                        Status: <strong><?php echo htmlspecialchars($my_request['status']); ?></strong>.
                        <a href="my_requests.php">View My Requests</a>
                    </p>

                <?php else: ?>

                    <p class="alert alert-info">
                        <?php echo htmlspecialchars($pet['name']); ?> isn't open for requests right now.
                        <a href="browse_pets.php">Browse other pets</a>
                    </p>

                <?php endif; ?>

            </div>

        </section>

    </main>

</div>

</body>
</html>