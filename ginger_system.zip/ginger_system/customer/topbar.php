<?php
// Shared topbar. Requires $page_title, $page_text, and user session data.
$page_title = $page_title ?? "Dashboard";
$page_text  = $page_text ?? "";
$user_name  = $user_name ?? "Adopter";
?>
<header class="topbar">
    <div class="topbar-left">
        <h1><?php echo $page_title; ?></h1>
        <?php if (!empty($page_text)): ?>
            <p class="welcome-text"><?php echo $page_text; ?></p>
        <?php endif; ?>
    </div>
    
    <div class="profile" style="display: flex; align-items: center; gap: 12px; padding: 6px 16px 6px 8px; background: var(--white); border: 1px solid var(--border); border-radius: var(--radius-pill); box-shadow: var(--shadow-xs);">
        <div style="width: 38px; height: 38px; display: grid; place-items: center; background: var(--sage); border-radius: 50%; font-size: 1rem;">👤</div>
        <div>
            <strong style="display: block; color: var(--dark-green); font-size: .85rem; font-weight: 800;"><?php echo $user_name; ?></strong>
            <small style="display: block; color: var(--muted); font-size: .72rem;">Adopter</small>
        </div>
    </div>
</header>