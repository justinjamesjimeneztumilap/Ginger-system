<?php
session_start();

include("../connection.php");
include("../functions.php");
include("../icons.php");

$user_data = require_role($con, "Adopter");
$uid       = $user_data['user_id'];
$user_name = htmlspecialchars($user_data['user_name']);

// Pets whose adoption request was approved
$stmt = mysqli_prepare($con, "SELECT p.id, p.name, p.species, p.breed, p.age, p.health_status, p.photo, r.updated_at
                              FROM adoption_requests r
                              JOIN pets p ON p.id = r.pet_id
                              WHERE r.user_id = ? AND r.status = 'Approved'
                              ORDER BY r.updated_at DESC, r.id DESC");
mysqli_stmt_bind_param($stmt, "s", $uid);
mysqli_stmt_execute($stmt);
$pets = mysqli_stmt_get_result($stmt);

$page_kicker = "MY PETS";
$page_title  = "Your adopted pets";
$page_text   = "Meet the pets you have welcomed home.";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>PetAdopt | My Pets</title>

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="../style/my_pets1.css">
    <style>
        /* Hide the email + role pill at the top right */
        .topbar .profile,
        .topbar .user-info,
        .topbar .user-pill,
        .topbar .user-menu,
        .topbar .account {
            display: none !important;
        }
    </style>
    <style>
        /* Same balanced card as the dashboard */
        .pet-list { align-items: stretch; }

        .pet-card {
            display: flex;
            flex-direction: column;
            height: 100%;
        }

        .pet-card .pet-info {
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        .pet-card .pet-info p.meta-box {
            margin: 10px 0 14px;
            padding: 12px 14px;
            display: flex;
            flex-direction: column;
            gap: 10px;
            text-align: left;
            background: var(--cream, #FFF6EE);
            border: 1px solid var(--border, #F0E4D6);
            border-radius: 16px;
        }

        .pet-card .meta-row { display: block; min-width: 0; }

        .pet-card .meta-row small {
            display: block;
            margin-bottom: 2px;
            color: var(--muted, #6B7369);
            font-size: .6rem;
            font-weight: 800;
            letter-spacing: .8px;
            text-transform: uppercase;
        }

        .pet-card .meta-row strong {
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 1;
            overflow: hidden;
            overflow-wrap: anywhere;
            color: var(--dark-green, #2F4F37);
            font-size: .8rem;
            font-weight: 800;
            line-height: 1.3;
        }

        /* Breed reserves two lines so every card stays the same height */
        .pet-card .meta-row:first-child strong {
            -webkit-line-clamp: 2;
            min-height: 2.6em;
        }

        /* Pin the tracker link to the bottom */
        .pet-card .pet-info > a.view-link { margin-top: auto; }
    </style>
    <style>
        /* ===== 7 pets per page, next / previous arrows ===== */
        .pets-section .pet-list {
            display: flex !important;
            grid-template-columns: none !important;
            gap: 18px !important;
            overflow-x: auto;
            scroll-snap-type: x mandatory;
            scroll-padding-left: 4px;
            scroll-behavior: smooth;
            scrollbar-width: none;
            -ms-overflow-style: none;
            padding: 8px 4px 20px;
            margin: -8px -4px -20px;
        }

        .pets-section .pet-list::-webkit-scrollbar { display: none; }

        .pets-section .pet-list > .pet-card {
            flex: 0 0 calc((100% - 108px) / 7);
            min-width: 0;
            max-width: none;
            height: auto;
            scroll-snap-align: start;
        }

        .pets-section .pet-list > p,
        .pets-section .pet-list > .empty-state { flex: 1 0 100%; }

        @media (max-width: 1200px) {
            .pets-section .pet-list > .pet-card { flex-basis: calc((100% - 54px) / 4); }
        }

        @media (max-width: 850px) {
            .pets-section .pet-list > .pet-card { flex-basis: calc((100% - 18px) / 2); }
        }

        @media (max-width: 520px) {
            .pets-section .pet-list > .pet-card { flex-basis: 100%; }
        }

        .pet-card .pet-info p.meta-box {
            align-self: stretch;
            width: 100%;
            box-sizing: border-box;
        }

        .carousel { position: relative; }

        .carousel-btn {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            z-index: 5;
            width: 44px;
            height: 44px;
            display: grid;
            place-items: center;
            padding: 0;
            background: var(--white, #FFFFFF);
            border: 1px solid var(--border, #E8E6DC);
            border-radius: 50%;
            box-shadow: 0 6px 18px rgba(47, 79, 55, .15);
            color: var(--green, #4F7C59);
            cursor: pointer;
            transition: background .25s ease, color .25s ease, opacity .25s ease, transform .25s ease;
        }

        .carousel-btn svg { width: 20px; height: 20px; display: block; }
        .carousel-btn.prev { left: -16px; }
        .carousel-btn.next { right: -16px; }

        .carousel-btn:hover:not(:disabled) {
            background: var(--green, #4F7C59);
            color: #fff;
            transform: translateY(-50%) scale(1.06);
        }

        .carousel-btn:focus-visible { outline: 3px solid rgba(79, 124, 89, .35); outline-offset: 2px; }

        .carousel-btn:disabled,
        .carousel-btn[hidden] { opacity: 0; pointer-events: none; }

        @media (max-width: 600px) {
            .carousel-btn { width: 38px; height: 38px; }
            .carousel-btn.prev { left: -8px; }
            .carousel-btn.next { right: -8px; }
        }

        @media (prefers-reduced-motion: reduce) {
            .pets-section .pet-list { scroll-behavior: auto; }
            .carousel-btn { transition: none; }
        }
    </style>
</head>

<body>

<div class="dashboard">

    <?php $active = "pets"; include("sidebar.php"); ?>

    <main class="main-content">

        <?php include("topbar.php"); ?>

        <section class="pets-section">

            <div class="pet-list">

                <?php if ($pets && mysqli_num_rows($pets) > 0): ?>
                    <?php while ($p = mysqli_fetch_assoc($pets)): ?>
                        <?php list($cls, $emoji) = pet_look($p['species']); ?>

                        <article class="pet-card">

                            <div class="pet-photo emoji <?php echo $cls; ?>">
                                <?php if (!empty($p['photo'])): ?>
                                    <img class="pet-photo-img" src="../uploads/pets/<?php echo htmlspecialchars($p['photo']); ?>" alt="<?php echo htmlspecialchars($p['name']); ?>" loading="lazy">
                                <?php else: ?>
                                    <?php echo pet_icon($cls); ?>
                                <?php endif; ?>
                            </div>

                            <div class="pet-info">

                                <span class="health-badge">
                                    <span class="pulse-dot"></span>
                                    <?php echo htmlspecialchars($p['health_status']); ?>
                                </span>

                                <h3><?php echo htmlspecialchars($p['name']); ?></h3>

                                <p class="meta-box">
                                    <span class="meta-row">
                                        <small>Breed</small>
                                        <strong title="<?php echo htmlspecialchars($p['breed']); ?>"><?php echo htmlspecialchars($p['breed']); ?></strong>
                                    </span>
                                    <span class="meta-row">
                                        <small>Age</small>
                                        <strong><?php echo htmlspecialchars($p['age']); ?></strong>
                                    </span>
                                    <span class="meta-row">
                                        <small>Adopted on</small>
                                        <strong><?php echo date("F j, Y", strtotime($p['updated_at'])); ?></strong>
                                    </span>
                                </p>

                                <a href="pet_tracker.php?id=<?php echo (int)$p['id']; ?>" class="view-link">
                                    View Pet Tracker <span class="arrow">&rarr;</span>
                                </a>

                            </div>

                        </article>

                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <div class="empty-icon"><?php echo icon("home", 48, "color:var(--green,#4F7C59)"); ?></div>
                        <h3>No adopted pets yet</h3>
                        <p>Once a request is approved, your pet will show up here.</p>
                        <a href="browse_pets.php" class="btn btn-primary" style="margin-top: 16px;">Browse Pets</a>
                    </div>
                <?php endif; ?>

            </div>

        </section>

    </main>

</div>

<script>
(function () {
    var GAP = 18;
    var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    var chevronLeft  = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 5l-7 7 7 7"/></svg>';
    var chevronRight = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 5l7 7-7 7"/></svg>';

    function makeButton(kind, label, icon) {
        var b = document.createElement("button");
        b.type = "button";
        b.className = "carousel-btn " + kind;
        b.setAttribute("aria-label", label);
        b.innerHTML = icon;
        return b;
    }

    document.querySelectorAll(".pets-section .pet-list").forEach(function (list) {

        var wrap = document.createElement("div");
        wrap.className = "carousel";
        list.parentNode.insertBefore(wrap, list);
        wrap.appendChild(list);

        if (!list.querySelector(".pet-card")) { return; }

        var prev = makeButton("prev", "Previous", chevronLeft);
        var next = makeButton("next", "Next", chevronRight);
        wrap.appendChild(prev);
        wrap.appendChild(next);

        function step() {
            var card = list.querySelector(".pet-card");
            return card ? card.getBoundingClientRect().width + GAP : 300;
        }

        function perPage() {
            return Math.max(1, Math.round(list.clientWidth / step()));
        }

        function update() {
            var canScroll = list.scrollWidth > list.clientWidth + 2;
            prev.hidden = next.hidden = !canScroll;
            prev.disabled = list.scrollLeft <= 2;
            next.disabled = list.scrollLeft + list.clientWidth >= list.scrollWidth - 2;
        }

        function go(dir) {
            list.scrollBy({ left: dir * step() * perPage(), behavior: reduce ? "auto" : "smooth" });
        }

        prev.addEventListener("click", function () { go(-1); });
        next.addEventListener("click", function () { go(1); });
        list.addEventListener("scroll", update, { passive: true });
        window.addEventListener("resize", update);
        update();
    });
})();
</script>

</body>
</html>