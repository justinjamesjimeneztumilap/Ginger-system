<?php
//THIS LANDING PAGE OKEH 

// Inline SVG icons (they take the color of the text around them)
function svg_icon($name, $size = 20, $class = "")
{
    $shapes = [
        "paw"    => '<circle cx="5.5" cy="10.5" r="1.8"/><circle cx="9.5" cy="6" r="1.8"/><circle cx="14.5" cy="6" r="1.8"/><circle cx="18.5" cy="10.5" r="1.8"/><path d="M12 12c-2.8 0-5 2.4-5 4.6 0 1.5 1.2 2.4 2.6 2.4 1 0 1.6-.4 2.4-.4s1.4.4 2.4.4c1.4 0 2.6-.9 2.6-2.4C17 14.4 14.8 12 12 12z"/>',
        "leaf"   => '<path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.5 19 2c1 2 2 4.2 2 8 0 5.5-4.8 10-10 10z"/><path d="M2 21c0-3 1.9-5.4 5.1-6C9.5 14.5 12 13 13 12"/>',
        "leaf2"  => '<path d="M6 21c0-9 5-15 15-16 0 10-6 15-15 16z"/><path d="M6 21c3-5 6-8 10-11"/>',
        "sprout" => '<path d="M12 21v-9"/><path d="M12 12c0-4 3-6.5 8-6.5 0 4.5-3 6.5-8 6.5z"/><path d="M12 14.5c0-3-2.2-5-6.5-5 0 3.5 2.2 5 6.5 5z"/>',
        "heart"  => '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1.1L12 21l7.8-7.5 1-1.1a5.5 5.5 0 0 0 0-7.8z"/>',
        "search" => '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
        "mail"   => '<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="M3.5 7.5 12 13.5l8.5-6"/>',
        "home"   => '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',
        "dog"    => '<path d="M7 7.5h10v7a5 5 0 0 1-10 0z"/><path d="M7 8C4 8 3 11 3.5 14c.3 1.6 1.6 2 2.5 1.2"/><path d="M17 8c3 0 4 3 3.5 6-.3 1.6-1.6 2-2.5 1.2"/><path d="M9.5 12v.5"/><path d="M14.5 12v.5"/><path d="M11 15.5h2l-1 1z"/>',
        "cat"    => '<path d="M5 4l3.2 3.2a8 8 0 0 1 7.6 0L19 4v8.5a7 7 0 0 1-14 0z"/><path d="M9.5 12.5v.5"/><path d="M14.5 12.5v.5"/><path d="M11 15.5h2l-1 1z"/><path d="M3 14.5l4-.8"/><path d="M21 14.5l-4-.8"/>',
        "puppy"  => '<path d="M8 7h8v8a4 4 0 0 1-8 0z"/><path d="M8 7L5 4.5C3.5 5.5 3 8 3.5 10l3 .5"/><path d="M16 7l3-2.5c1.5 1 2 3.5 1.5 5.5l-3 .5"/><path d="M10 11.5v.5"/><path d="M14 11.5v.5"/><path d="M11 14.5h2l-1 1z"/><path d="M12 15.5v1.5"/>',
    ];

    return '<svg class="svg-icon ' . $class . '" viewBox="0 0 24 24" width="' . $size . '" height="' . $size . '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $shapes[$name] . '</svg>';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Meet adorable pets waiting for their forever family and start your adoption journey with PetAdopt.">
    <title>PetAdopt | Welcome!</title>

    <!-- font (falls back to Arial if offline) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="style/landingpage.css">

    <style>
        /* ==========================================================
           SVG icons + balance tweaks (loads after landingpage.css)
           ========================================================== */

        .svg-icon { display: block; flex-shrink: 0; }

        /* small icon that sits in front of a pill label */
        .svg-icon.inline-icon {
            display: inline-block;
            width: 14px;
            height: 14px;
            margin-right: 6px;
            vertical-align: -2px;
        }

        /* ----- navbar: logo, links and button share one height ----- */
        .logo-mark .svg-icon { width: 22px; height: 22px; color: var(--green); }

        .nav-links a { display: inline-flex; align-items: center; min-height: 36px; padding: 0 18px; }

        .nav-button {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            min-height: 44px;
            padding: 0 24px;
        }

        .nav-button .svg-icon { width: 15px; height: 15px; }

        /* ----- buttons: icon + text centered, same size ----- */
        .button .svg-icon { width: 16px; height: 16px; }

        /* ----- hero: pill label already has its own pulsing dot ----- */
        .hero h1 { margin: 22px 0 22px; }

        /* hero decorations */
        .leaf .svg-icon { color: var(--green); }
        .leaf-one .svg-icon { width: 46px; height: 46px; }
        .leaf-two .svg-icon { width: 34px; height: 34px; color: #7FA987; }
        .paw .svg-icon { width: 34px; height: 34px; }

        /* "Say hello" card */
        .hello-card > span .svg-icon { width: 20px; height: 20px; }

        /* ----- how it works: three equal cards ----- */
        .steps article { display: flex; flex-direction: column; }
        .icon .svg-icon { width: 28px; height: 28px; }
        .icon.green  { color: var(--green); }
        .icon.orange { color: var(--orange-dark); }
        .icon.brown  { color: var(--brown); }

        /* ----- pet cards: equal height, button row pinned to the bottom ----- */
        .pet-list { align-items: stretch; }
        .pet-card { display: flex; flex-direction: column; }
        .pet-info { flex: 1; display: flex; flex-direction: column; align-items: flex-start; }
        .pet-info a { margin-top: auto; padding-top: 18px; }

        .pet-photo .svg-icon { width: 84px; height: 84px; }
        .pet-photo.dog   { color: var(--green); }
        .pet-photo.cat   { color: var(--brown); }
        .pet-photo.puppy { color: var(--orange-dark); }

        /* ----- footer ----- */
        footer strong { display: inline-flex; align-items: center; gap: 8px; font-size: 1.05rem; }
        footer strong .svg-icon { width: 20px; height: 20px; }
        footer div p { margin-top: 4px; }
    </style>
</head>

<body>

    <header>
        <nav class="navbar" aria-label="Main navigation">
            <a href="index.php" class="logo">
                <span class="logo-mark"><?php echo svg_icon("paw", 22); ?></span> <span>Pet<span>Adopt</span></span>
            </a>

            <!-- mobile menu button (only visible on phones) -->
            <button type="button" class="nav-burger" id="nav-burger"
                    aria-label="Open menu" aria-expanded="false" aria-controls="nav-links">
                <span></span>
                <span></span>
                <span></span>
            </button>

            <div class="nav-links" id="nav-links">
                <a href="index.php" class="active">Home</a>
                <a href="#pets">Browse Pets</a>
                <a href="#how-it-works">How It Works</a>
                <a href="login.php">Login</a>
            </div>

            <a href="signup.php" class="nav-button">Join Us <?php echo svg_icon("heart", 15); ?></a>
        </nav>
    </header>


    <main>

        <!-- HERO -->
        <section class="hero">

            <div class="hero-content">

                <div class="hero-text">

                    <span class="small-title">A HOME FOR EVERY PAW</span>

                    <h1>
                        Find a little
                        <span>love to bring</span>
                        home.
                    </h1>

                    <p>
                        Meet adorable pets waiting for their forever family.
                        Your new best friend might be closer than you think.
                    </p>

                    <div class="buttons">
                        <a href="login.php" class="button">Find a Pet <?php echo svg_icon("heart", 16); ?></a>
                        <a href="#how-it-works" class="learn">How it works →</a>
                    </div>

                </div>


                <div class="hero-art">

                    <div class="leaf leaf-one" aria-hidden="true"><?php echo svg_icon("leaf", 46); ?></div>
                    <div class="leaf leaf-two" aria-hidden="true"><?php echo svg_icon("leaf2", 34); ?></div>

                    <div class="pet-circle">
                        <img src="img/gingers.png" alt="ginger">
                    </div>

                    <div class="hello-card">
                        <span><?php echo svg_icon("heart", 20); ?></span>
                        <div>
                            <strong>Say hello!</strong>
                            <small>Your new friend is waiting.</small>
                        </div>
                    </div>

                    <div class="paw paw-one" aria-hidden="true"><?php echo svg_icon("paw", 34); ?></div>
                    <div class="paw paw-two" aria-hidden="true"><?php echo svg_icon("paw", 34); ?></div>

                </div>

            </div>

        </section>


        <!-- HOW IT WORKS -->
        <section class="how" id="how-it-works">

            <div class="heading">
                <span><?php echo svg_icon("heart", 14, "inline-icon"); ?>EASY & HEARTFELT</span>
                <h2>How adoption works</h2>
                <p>Three simple steps to meet your new companion.</p>
            </div>

            <div class="steps">

                <article>
                    <div class="icon green"><?php echo svg_icon("search", 28); ?></div>
                    <b>01 · Browse</b>
                    <p>Look through pets waiting for a loving home.</p>
                </article>

                <article>
                    <div class="icon orange"><?php echo svg_icon("mail", 28); ?></div>
                    <b>02 · Apply</b>
                    <p>Send an adoption request for your chosen pet.</p>
                </article>

                <article>
                    <div class="icon brown"><?php echo svg_icon("home", 28); ?></div>
                    <b>03 · Welcome Home</b>
                    <p>Bring your new best friend into their forever home.</p>
                </article>

            </div>

        </section>


        <!-- PETS -->
        <section class="pets" id="pets">

            <div class="heading">
                <span><?php echo svg_icon("paw", 14, "inline-icon"); ?>MEET OUR PETS</span>
                <h2>Waiting for their person</h2>
                <p>Maybe that person could be you.</p>
            </div>

            <div class="pet-list">

                <article class="pet-card">
                    <div class="pet-photo dog"><?php echo svg_icon("dog", 84); ?></div>

                    <div class="pet-info">
                        <span class="available">● Available</span>
                        <h3>Buddy</h3>
                        <p>Golden Retriever · 2 years</p>
                        <a href="login.php">Meet Buddy</a>
                    </div>
                </article>


                <article class="pet-card">
                    <div class="pet-photo cat"><?php echo svg_icon("cat", 84); ?></div>

                    <div class="pet-info">
                        <span class="available">● Available</span>
                        <h3>Luna</h3>
                        <p>Domestic Shorthair · 1 year</p>
                        <a href="login.php">Meet Luna</a>
                    </div>
                </article>


                <article class="pet-card">
                    <div class="pet-photo puppy"><?php echo svg_icon("puppy", 84); ?></div>

                    <div class="pet-info">
                        <span class="available">● Available</span>
                        <h3>Milo</h3>
                        <p>Shih Tzu · 3 years</p>
                        <a href="login.php">Meet Milo</a>
                    </div>
                </article>

            </div>

            <a href="login.php" class="all-pets">See all pets</a>

        </section>


        <!-- CTA -->
        <section class="cta">

            <div>
                <span><?php echo svg_icon("sprout", 14, "inline-icon"); ?>EVERY PET DESERVES A HOME</span>

                <h2>
                    Maybe your new
                    <em>best friend</em>
                    is waiting.
                </h2>

                <a href="signup.php" class="button orange-button">
                    Start Your Journey <?php echo svg_icon("heart", 16); ?>
                </a>
            </div>

        </section>

    </main>


    <footer>
        <div>
            <strong><?php echo svg_icon("paw", 20); ?> PetAdopt</strong>
            <p>Helping pets find their forever homes.</p>
        </div>

        <p>© 2026 PetAdopt</p>
    </footer>


    <!-- mobile menu toggle -->
    <script>
        const header = document.querySelector('header');
        const burger = document.getElementById('nav-burger');

        function setMenu(open) {
            header.classList.toggle('nav-open', open);
            burger.setAttribute('aria-expanded', open);
            burger.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
        }

        burger.addEventListener('click', () => {
            setMenu(!header.classList.contains('nav-open'));
        });

        // close the menu after tapping a link
        document.querySelectorAll('#nav-links a').forEach(link => {
            link.addEventListener('click', () => setMenu(false));
        });
    </script>

</body>

</html>