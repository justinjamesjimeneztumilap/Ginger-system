<?php
session_start();

include("connection.php");
include("functions.php");

if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    $user_name = $_POST['user_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $security_question = $_POST['security_question'];
    $security_answer = $_POST['security_answer'];

    if (!empty($user_name) && !empty($email) && !empty($password) && !empty($security_question) && !empty($security_answer))
    {
        // Check if username already exists
        $query = "SELECT * FROM users WHERE user_name = '$user_name' LIMIT 1";

        $result = mysqli_query($con, $query);

        if (mysqli_num_rows($result) > 0)
        {
            echo "Username already exists!";
        }
        else
        {
            // Check if email already exists
            $query = "SELECT * FROM users
                      WHERE email = '$email'
                      LIMIT 1";

            $result = mysqli_query($con, $query);

            if (mysqli_num_rows($result) > 0)
            {
                echo "Email already exists!";
            }
            else
            {
                // Create a unique user ID
                $user_id = random_num(20);

                // Check if the generated user ID already exists
                $query = "SELECT * FROM users WHERE user_id = '$user_id' LIMIT 1";

                $result = mysqli_query($con, $query);

                while (mysqli_num_rows($result) > 0)
                {
                    $user_id = random_num(20);

                    $query = "SELECT * FROM users WHERE user_id = '$user_id' LIMIT 1";

                    $result = mysqli_query($con, $query);
                }

                // Encrypt password
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                // New accounts are Clients
                $user_type = "Adopter";

                // Insert new Client account
                $query = "INSERT INTO users (user_id, user_name, email, password, security_question, security_answer, user_type) VALUES ('$user_id', '$user_name', '$email', '$hashed_password', '$security_question', '$security_answer', '$user_type')";

                if (mysqli_query($con, $query))
                {
                    header("Location: login.php");
                    die;
                }
                else
                {
                    echo "Error creating account!";
                }
            }
        }
    }
    else
    {
        echo "Please fill in all fields!";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PetAdopt | Get Started</title>
    <link rel="stylesheet" href="style/signup.css">
</head>

<body>

    <header>
        <a href="index.php" class="logo">
            🐾 Pet<span>Adopt</span>
        </a>

        <a href="index.php" class="home-link">
            ← Back to Home
        </a>
    </header>

    <main>

        <section class="signup-card">

            <div class="card-icon">🏡</div>

            <p class="small-title">JOIN PETADOPT</p>

            <h1>Start your<br><span>adoption journey.</span></h1>

            <p class="description">
                Create an account and find a pet waiting for a loving home.
            </p>

            <form method="post">

                <label for="user_name">Username</label>
                <input
                    type="text"
                    id="user_name"
                    name="user_name"
                    placeholder="Choose a username"
                    required
                >

                <label for="email">Email</label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    placeholder="Enter your email"
                    required
                >

                <label for="password">Password</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Create a password"
                    required
                >

                <label for="security_question">Security Question</label>

                <select
                    id="security_question"
                    name="security_question"
                    required
                >
                    <option value="">Select a question</option>

                    <option value="What is your favorite color?">
                        What is your favorite color?
                    </option>

                    <option value="What is your favorite food?">
                        What is your favorite food?
                    </option>

                    <option value="What is your favorite animal?">
                        What is your favorite animal?
                    </option>

                    <option value="What is your childhood nickname?">
                        What is your childhood nickname?
                    </option>
                </select>

                <label for="security_answer">Security Answer</label>

                <input
                    type="text"
                    id="security_answer"
                    name="security_answer"
                    placeholder="Enter your answer"
                    required
                >

                <button type="submit">
                    Create Account <span>→</span>
                </button>

                <p class="account-text">
                    Already have an account?
                    <a href="login.php">Login</a>
                </p>

            </form>

        </section>

        <div class="decoration paw-one">🐾</div>
        <div class="decoration leaf-one">🌿</div>

    </main>

</body>
</html>