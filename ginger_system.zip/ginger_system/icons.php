<?php
// Shared SVG icons (line style). Put this file next to functions.php, then include it:
//   include("../icons.php");
//
// icon("paw")               -> small icon, 20px
// icon("mail", 14, "style") -> custom size and extra inline CSS
// pet_icon($cls)            -> pet picture placeholder (dog / cat / other), $cls comes from pet_look()

function icon($name, $size = 20, $style = "")
{
    static $paths = [
        "paw"     => '<circle cx="5.5" cy="10.5" r="1.8"/><circle cx="9.5" cy="6" r="1.8"/><circle cx="14.5" cy="6" r="1.8"/><circle cx="18.5" cy="10.5" r="1.8"/><path d="M12 12c-2.8 0-5 2.4-5 4.6 0 1.5 1.2 2.4 2.6 2.4 1 0 1.6-.4 2.4-.4s1.4.4 2.4.4c1.4 0 2.6-.9 2.6-2.4C17 14.4 14.8 12 12 12z"/>',
        "mail"    => '<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="M3.5 7.5 12 13.5l8.5-6"/>',
        "home"    => '<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10v9.5h13V10"/><path d="M10 19.5v-5h4v5"/>',
        "users"   => '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><circle cx="17.2" cy="9" r="2.4"/><path d="M17.2 14c2.5 0 4.3 1.9 4.3 4.5"/>',
        "search"  => '<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/>',
        "tick"    => '<path d="M5 12.5l4.5 4.5L19 7.5" stroke-width="2.4"/>',
        "check"   => '<circle cx="12" cy="12" r="9"/><path d="M8 12.5l2.7 2.7L16 9.5"/>',
        "clock"   => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
        "heart"   => '<path d="M12 20s-7.5-4.6-7.5-10.2A4.3 4.3 0 0 1 12 7.2a4.3 4.3 0 0 1 7.5 2.6C19.5 15.4 12 20 12 20z"/>',
        "leaf"    => '<path d="M5 19c0-8 5-13 15-14 0 10-5 15-13 15"/><path d="M5 19c3-4 6-6.5 10-8"/>',
        "grid"    => '<rect x="3" y="3" width="7.5" height="7.5" rx="2"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="2"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="2"/><rect x="13.5" y="13.5" width="7.5" height="7.5" rx="2"/>',
        "logout"  => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/>',
        "dog"     => '<path d="M7.5 7C6 6.2 4 6.8 3.5 9.5c-.3 2 .4 3.7 1.8 4.5"/><path d="M16.5 7c1.5-.8 3.5-.2 4 2.5.3 2-.4 3.7-1.8 4.5"/><path d="M7.5 7C9 6 15 6 16.5 7c.9 3 .8 6.5-1 9.2-1 1.4-2.2 2.3-3.5 2.3s-2.5-.9-3.5-2.3C7 13.5 6.6 10 7.5 7z"/><circle cx="10" cy="11" r=".7" fill="currentColor" stroke="none"/><circle cx="14" cy="11" r=".7" fill="currentColor" stroke="none"/><path d="M10.7 14.4h2.6l-1.3 1.5z"/>',
        "cat"     => '<path d="M5 9.5V4.5l4 2.7"/><path d="M19 9.5V4.5l-4 2.7"/><path d="M5 9.5C5 6.8 8 6 12 6s7 .8 7 3.5c0 5-2.5 9.5-7 9.5s-7-4.5-7-9.5z"/><circle cx="9.5" cy="11" r=".7" fill="currentColor" stroke="none"/><circle cx="14.5" cy="11" r=".7" fill="currentColor" stroke="none"/><path d="M11 13.5h2l-1 1.1z"/><path d="M2.5 13l3 .6M2.5 16l3-1M21.5 13l-3 .6M21.5 16l-3-1"/>',
    ];

    if (!isset($paths[$name])) { return ""; }

    return '<svg class="icon icon-' . $name . '" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"'
         . ' width="' . (int)$size . '" height="' . (int)$size . '" fill="none" stroke="currentColor"'
         . ' stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"'
         . ($style !== "" ? ' style="' . $style . '"' : '') . '>' . $paths[$name] . '</svg>';
}

// Pet picture placeholder, used when a pet has no photo
function pet_icon($cls, $size = 48)
{
    if ($cls === "dog")      { $name = "dog"; $color = "#4F7C59"; }
    elseif ($cls === "cat")  { $name = "cat"; $color = "#A67C52"; }
    else                     { $name = "paw"; $color = "#E08B45"; }

    return icon($name, $size, "color:" . $color);
}