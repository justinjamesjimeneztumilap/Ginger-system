<?php
session_start();

include("../connection.php");
include("../functions.php");

// Only logged-in adopters can see this page
$user_data = require_role($con, "Adopter");
$user_name = htmlspecialchars($user_data['user_name']);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>PetAdopt | Dashboard</title>

    <link rel="stylesheet" href="../style/adopter_dashboard.css">
</head>

<body>

<div class="dashboard">

    <!-- SIDEBAR -->
    <aside class="sidebar">

        <a href="dashboard.php" class="logo">
            🐾 Pet<span>Adopt</span>
        </a>

        <nav>

            <a href="dashboard.php" class="active">
                🏠 <span>Dashboard</span>
            </a>

            <a href="browse_pets.php">
                🐾 <span>Browse Pets</span>
            </a>

            <a href="my_requests.php">
                📋 <span>My Requests</span>
            </a>

            <a href="my_pets.php">
                🏡 <span>My Pets</span>
            </a>

            <a href="profile.php">
                👤 <span>Profile</span>
            </a>

        </nav>

        <a href="../logout.php" class="logout">
            🚪 <span>Logout</span>
        </a>

    </aside>


    <!-- MAIN CONTENT -->
    <main class="main-content">

        <!-- TOP BAR -->
        <header class="topbar">

            <div>
                <p class="small-title">PETADOPT DASHBOARD</p>
                <h1>Welcome back, <?php echo $user_name; ?>! 🌿</h1>
                <p class="welcome-text">
                    Find your new best friend today.
                </p>
            </div>

            <div class="profile">
                <div class="profile-icon">🐾</div>

                <div>
                    <strong><?php echo $user_name; ?></strong>
                    <small>Adopter</small>
                </div>
            </div>

        </header>


        <!-- SUMMARY CARDS -->
        <section class="summary">

            <article class="summary-card green-card">
                <div class="summary-icon">🐾</div>

                <div>
                    <p>Available Pets</p>
                    <h2>12</h2>
                </div>
            </article>


            <article class="summary-card orange-card">
                <div class="summary-icon">💌</div>

                <div>
                    <p>My Requests</p>
                    <h2>2</h2>
                </div>
            </article>


            <article class="summary-card brown-card">
                <div class="summary-icon">🏡</div>

                <div>
                    <p>My Adopted Pets</p>
                    <h2>1</h2>
                </div>
            </article>

        </section>


        <!-- AVAILABLE PETS -->
        <section class="pets-section">

            <div class="section-heading">
                <div>
                    <span>🐾 MEET THE PETS</span>
                    <h2>Pets waiting for a home</h2>
                </div>

                <a href="browse_pets.php">See all →</a>
            </div>


            <div class="pet-list">

                <!-- PET 1 -->
                <article class="pet-card">

                    <div class="pet-photo emoji dog">🐶</div>

                    <div class="pet-info">

                        <span class="available">
                            ● Available
                        </span>

                        <h3>Buddy</h3>

                        <p>
                            Golden Retriever · 2 years
                        </p>

                        <a href="pet_details.php">
                            View Pet →
                        </a>

                    </div>

                </article>


                <!-- PET 2 -->
                <article class="pet-card">

                    <div class="pet-photo emoji cat">🐱</div>

                    <div class="pet-info">

                        <span class="available">
                            ● Available
                        </span>

                        <h3>Luna</h3>

                        <p>
                            Domestic Shorthair · 1 year
                        </p>

                        <a href="pet_details.php">
                            View Pet →
                        </a>

                    </div>

                </article>


                <!-- PET 3 -->
                <article class="pet-card">

                    <div class="pet-photo emoji puppy">🐕</div>

                    <div class="pet-info">

                        <span class="available">
                            ● Available
                        </span>

                        <h3>Milo</h3>

                        <p>
                            Shih Tzu · 3 years
                        </p>

                        <a href="pet_details.php">
                            View Pet →
                        </a>

                    </div>

                </article>

            </div>

        </section>


        <!-- ADOPTION JOURNEY -->
        <section class="journey">

            <div class="journey-heading">
                <span>🌱 YOUR ADOPTION JOURNEY</span>

                <h2>Every step brings you closer.</h2>
            </div>

            <div class="steps">

                <div class="step completed">
                    <div>✓</div>
                    <p>Browse Pets</p>
                </div>

                <span class="line"></span>

                <div class="step completed">
                    <div>✓</div>
                    <p>Submit Request</p>
                </div>

                <span class="line"></span>

                <div class="step">
                    <div>3</div>
                    <p>Approval</p>
                </div>

                <span class="line"></span>

                <div class="step">
                    <div>4</div>
                    <p>Welcome Home</p>
                </div>

            </div>

        </section>


        <!-- PET TRACKER -->
        <section class="tracker">

            <div class="tracker-photo emoji dog">🐶</div>

            <div class="tracker-info">

                <span>🏡 YOUR PET</span>

                <h2>Buddy</h2>

                <p>Golden Retriever · 2 years old</p>

                <div class="tracker-details">

                    <div>
                        <small>Health</small>
                        <strong>Healthy</strong>
                    </div>

                    <div>
                        <small>Adopted</small>
                        <strong>June 12, 2026</strong>
                    </div>

                    <div>
                        <small>Next Check-up</small>
                        <strong>July 12, 2026</strong>
                    </div>

                </div>

                <a href="pet_tracker.php" class="tracker-button">
                    View Pet Tracker →
                </a>

            </div>

        </section>

    </main>

</div>

</body>
</html>