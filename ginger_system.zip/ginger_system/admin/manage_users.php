<?php
session_start();

include("../connection.php");
include("../functions.php");
include("../icons.php");

$user_data = require_role($con, "Admin");
$user_name = htmlspecialchars($user_data['user_name']);

$result = mysqli_query($con, "SELECT u.user_name, u.email, u.user_type, u.date,
                                     (SELECT COUNT(*) FROM adoption_requests r WHERE r.user_id = u.user_id) AS request_count
                              FROM users u
                              ORDER BY u.date DESC");

// Load rows once so we can count them for the summary cards
$users = [];
$total_admins = 0;
$total_adopters = 0;
$total_requests = 0;

if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $users[] = $row;
        if ($row['user_type'] === "Admin") {
            $total_admins++;
        } else {
            $total_adopters++;
        }
        $total_requests += (int)$row['request_count'];
    }
}

$total_users = count($users);

$page_kicker = "USERS";
$page_title  = "Registered accounts";
$page_text   = "Everyone who has an account on PetAdopt.";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>PetAdopt | Users</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@600;700;800&display=swap" rel="stylesheet">

    <!-- Same stylesheets as the admin dashboard so both pages look identical -->
    <link rel="stylesheet" href="../style/adopter_dashboard.css">
    <link rel="stylesheet" href="../style/admin_dashboard.css">
    <link rel="stylesheet" href="../style/admin_base.css">
    <style>
        /* Same page behavior as the admin dashboard */
        html { overflow-y: scroll; }

        /* Hide the name / role pill at the top right (shield + "Admin") */
        .topbar .profile,
        .topbar .user-info,
        .topbar .user-pill,
        .topbar .user-menu,
        .topbar .account,
        .topbar > div:last-child:not(.search):not(.topbar-title) {
            display: none !important;
        }

        /* Summary card icons (SVG) take the color of their card */
        .summary-icon svg { display: block; }
        .green-card .summary-icon  { color: #4F7C59; }
        .orange-card .summary-icon { color: #E08B45; }
        .brown-card .summary-icon  { color: #A67C52; }

        /* ===== Toolbar (search + role tabs) ===== */
        .users-toolbar {
            margin-bottom: 18px;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 14px;
        }

        .user-search {
            flex: 1 1 320px;
            max-width: 460px;
            height: 44px;
            box-sizing: border-box;
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0 18px;
            background: var(--white, #FFFFFF);
            border: 1px solid var(--border, #E8E6DC);
            border-radius: 999px;
            color: var(--muted, #6B7369);
            box-shadow: 0 6px 18px rgba(79, 124, 89, .06);
            transition: border-color .25s ease, box-shadow .25s ease;
        }

        .user-search:focus-within {
            border-color: var(--green, #4F7C59);
            box-shadow: 0 0 0 3px rgba(79, 124, 89, .15);
        }

        .user-search svg { width: 18px; height: 18px; flex-shrink: 0; }

        .user-search input,
        .user-search input:hover,
        .user-search input:focus {
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
            border: none !important;
            border-radius: 0 !important;
            outline: none !important;
            box-shadow: none !important;
            background: transparent !important;
            -webkit-appearance: none;
            appearance: none;
            color: var(--text, #2F3A33);
            font-family: inherit;
            font-size: .85rem;
            font-weight: 600;
        }

        .user-search input::-webkit-search-cancel-button { -webkit-appearance: none; }

        .role-tabs { display: flex; flex-wrap: wrap; gap: 8px; }

        .role-tab {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            height: 44px;
            box-sizing: border-box;
            padding: 0 18px;
            background: var(--white, #FFFFFF);
            border: 1px solid var(--border, #E8E6DC);
            box-shadow: 0 6px 18px rgba(79, 124, 89, .06);
            border-radius: 999px;
            color: var(--muted, #6B7369);
            font-family: inherit;
            font-size: .78rem;
            font-weight: 800;
            cursor: pointer;
            transition: background .25s ease, color .25s ease;
        }

        .role-tab span {
            padding: 2px 8px;
            background: #F1F3EE;
            border-radius: 999px;
            font-size: .68rem;
        }

        .role-tab:hover { background: var(--sage, #E4EDE2); color: var(--green, #4F7C59); }
        .role-tab.active { background: var(--green, #4F7C59); border-color: var(--green, #4F7C59); color: #fff; }
        .role-tab.active span { background: rgba(255, 255, 255, .22); color: #fff; }
        .role-tab:focus-visible { outline: 3px solid rgba(79, 124, 89, .35); outline-offset: 2px; }

        /* ===== Table ===== */
        .users-table { border-radius: 22px; }
        .users-table table { font-size: .82rem; }

        .users-table th {
            padding: 16px 20px;
            background: #FBFCFA;
            font-size: .66rem;
            font-weight: 800;
            letter-spacing: .8px;
            text-transform: uppercase;
        }

        .users-table td { padding: 14px 20px; }
        .users-table tbody tr { transition: background .2s ease; }
        .users-table tbody tr:hover { background: var(--cream, #FFF6EE); }
        .users-table tbody tr[hidden] { display: none; }

        .user-cell {
            display: flex;
            align-items: center;
            gap: 12px;
            color: var(--dark-green, #2F4F37);
            white-space: nowrap;
        }

        .avatar {
            width: 38px;
            height: 38px;
            flex-shrink: 0;
            display: grid;
            place-items: center;
            border-radius: 50%;
            font-size: .85rem;
            font-weight: 800;
        }

        .avatar.adopter { background: var(--sage, #E4EDE2); color: #4F7C59; }
        .avatar.admin   { background: #F4E4D4; color: #A67C52; }

        .email-cell,
        .date-cell { color: var(--muted, #6B7369); }

        .email-cell svg,
        .date-cell svg {
            width: 15px;
            height: 15px;
            margin-right: 6px;
            vertical-align: -3px;
            color: #A3A9A1;
        }

        .role-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            border: 1px solid transparent;
            border-radius: 999px;
            font-size: .72rem;
            font-weight: 800;
        }

        .role-badge svg { width: 14px; height: 14px; }
        .role-badge.is-adopter { background: var(--sage, #E4EDE2); border-color: #D3E2D0; color: #4F7C59; }
        .role-badge.is-admin   { background: #FBE0CA; border-color: #F4C9A3; color: #C9712B; }

        .req-pill {
            min-width: 34px;
            display: inline-block;
            padding: 5px 12px;
            background: var(--sage, #E4EDE2);
            border-radius: 999px;
            color: #4F7C59;
            font-size: .75rem;
            font-weight: 800;
            text-align: center;
        }

        .req-pill.zero { background: #F1F3EE; color: #A3A9A1; }

        .no-match { padding: 40px 20px; text-align: center; }
        .no-match[hidden] { display: none; }

        /* ===== Proportion fix: equal-width role badges + no wrapping ===== */
        .users-table table { width: 100%; min-width: 760px; }
        .users-table th,
        .users-table td { white-space: nowrap; vertical-align: middle; }

        .email-cell svg,
        .date-cell svg { display: inline-block; }

        .role-badge {
            min-width: 108px;
            box-sizing: border-box;
            justify-content: center;
        }

        .users-table th:last-child,
        .users-table td:last-child { text-align: center; }

        .users-table th:nth-child(3),
        .users-table td:nth-child(3) { padding-right: 28px; }

        /* ===== Mobile ===== */
        @media (max-width: 700px) {
            .users-toolbar { flex-direction: column; align-items: stretch; }
            .user-search { max-width: none; flex-basis: auto; }
            .role-tabs { width: 100%; }
            .role-tab { flex: 1; justify-content: center; padding: 0 10px; }
            .users-table th,
            .users-table td { padding: 12px 14px; }
        }

        @media (prefers-reduced-motion: reduce) {
            .user-search,
            .role-tab,
            .users-table tbody tr { transition: none; }
        }
    </style>
</head>

<body>

<div class="dashboard">

    <?php $active = "users"; include("sidebar.php"); ?>

    <main class="main-content">

        <?php include("topbar.php"); ?>

        <section class="summary four">

            <article class="summary-card green-card">
                <div class="summary-icon"><?php echo icon("users", 26); ?></div>
                <div>
                    <p>Total Accounts</p>
                    <h2><?php echo $total_users; ?></h2>
                    <small>Everyone registered</small>
                </div>
            </article>

            <article class="summary-card orange-card">
                <div class="summary-icon"><?php echo icon("paw", 26); ?></div>
                <div>
                    <p>Adopters</p>
                    <h2><?php echo $total_adopters; ?></h2>
                    <small>Looking for a pet</small>
                </div>
            </article>

            <article class="summary-card brown-card">
                <div class="summary-icon"><?php echo icon("home", 26); ?></div>
                <div>
                    <p>Admins</p>
                    <h2><?php echo $total_admins; ?></h2>
                    <small>Shelter staff</small>
                </div>
            </article>

            <article class="summary-card green-card">
                <div class="summary-icon"><?php echo icon("mail", 26); ?></div>
                <div>
                    <p>Total Requests</p>
                    <h2><?php echo $total_requests; ?></h2>
                    <small>Sent by all users</small>
                </div>
            </article>

        </section>


        <section class="users-section">

            <div class="section-heading">
                <div>
                    <span><?php echo icon("users", 14, "vertical-align:-2px;margin-right:6px"); ?>ACCOUNTS</span>
                    <h2>All users</h2>
                </div>
            </div>

            <div class="users-toolbar">

                <label class="user-search">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>
                    <input type="search" id="userSearch" placeholder="Search by name or email" autocomplete="off">
                </label>

                <div class="role-tabs" id="roleTabs">
                    <button type="button" class="role-tab active" data-role="all">All <span><?php echo $total_users; ?></span></button>
                    <button type="button" class="role-tab" data-role="Adopter">Adopters <span><?php echo $total_adopters; ?></span></button>
                    <button type="button" class="role-tab" data-role="Admin">Admins <span><?php echo $total_admins; ?></span></button>
                </div>

            </div>

            <?php if ($total_users > 0): ?>

                <div class="table-wrap users-table">
                    <table>
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Joined</th>
                                <th>Requests</th>
                            </tr>
                        </thead>
                        <tbody id="userRows">
                            <?php foreach ($users as $u): ?>
                                <?php
                                    $is_admin = ($u['user_type'] === "Admin");
                                    $initial  = strtoupper(mb_substr($u['user_name'], 0, 1));
                                    $joined   = strtotime($u['date']);
                                    $reqs     = (int)$u['request_count'];
                                ?>
                                <tr data-role="<?php echo htmlspecialchars($u['user_type']); ?>"
                                    data-search="<?php echo htmlspecialchars(strtolower($u['user_name'] . " " . $u['email'])); ?>">

                                    <td>
                                        <div class="user-cell">
                                            <span class="avatar <?php echo $is_admin ? "admin" : "adopter"; ?>"><?php echo htmlspecialchars($initial); ?></span>
                                            <strong><?php echo htmlspecialchars($u['user_name']); ?></strong>
                                        </div>
                                    </td>

                                    <td class="email-cell">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/></svg>
                                        <?php echo htmlspecialchars($u['email']); ?>
                                    </td>

                                    <td>
                                        <span class="role-badge <?php echo $is_admin ? "is-admin" : "is-adopter"; ?>">
                                            <?php if ($is_admin): ?>
                                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l8 3v6c0 4.5-3.3 8-8 9-4.7-1-8-4.5-8-9V6l8-3z"/><path d="M9 12l2 2 4-4"/></svg>
                                            <?php else: ?>
                                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/></svg>
                                            <?php endif; ?>
                                            <?php echo htmlspecialchars($u['user_type']); ?>
                                        </span>
                                    </td>

                                    <td class="date-cell">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></svg>
                                        <?php echo $joined ? date("M j, Y", $joined) : "—"; ?>
                                    </td>

                                    <td>
                                        <span class="req-pill <?php echo $reqs === 0 ? "zero" : ""; ?>"><?php echo $reqs; ?></span>
                                    </td>

                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                    <div class="empty-state no-match" id="noMatch" hidden>
                        <div><?php echo icon("users", 44, "color:var(--green,#4F7C59)"); ?></div>
                        <h3>No users found</h3>
                        <p>Try a different name, email or role.</p>
                    </div>
                </div>

            <?php else: ?>

                <div class="empty-state">
                    <div><?php echo icon("users", 44, "color:var(--green,#4F7C59)"); ?></div>
                    <h3>No accounts yet</h3>
                    <p>Registered users will show up here.</p>
                </div>

            <?php endif; ?>

        </section>

    </main>

</div>

<script>
(function () {
    var rows    = document.querySelectorAll("#userRows tr");
    var search  = document.getElementById("userSearch");
    var tabs    = document.querySelectorAll("#roleTabs .role-tab");
    var noMatch = document.getElementById("noMatch");
    var role    = "all";

    if (!rows.length) { return; }

    function apply() {
        var q = search.value.trim().toLowerCase();
        var shown = 0;

        rows.forEach(function (row) {
            var okRole = role === "all" || row.getAttribute("data-role") === role;
            var okText = !q || row.getAttribute("data-search").indexOf(q) !== -1;
            var show = okRole && okText;
            row.hidden = !show;
            if (show) { shown++; }
        });

        noMatch.hidden = shown !== 0;
    }

    search.addEventListener("input", apply);

    tabs.forEach(function (tab) {
        tab.addEventListener("click", function () {
            tabs.forEach(function (t) { t.classList.remove("active"); });
            tab.classList.add("active");
            role = tab.getAttribute("data-role");
            apply();
        });
    });
})();
</script>

</body>
</html>