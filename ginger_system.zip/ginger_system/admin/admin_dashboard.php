<?php
session_start();

include("../connection.php");
include("../functions.php");
include("../icons.php");

$user_data = require_role($con, "Admin");
$user_name = htmlspecialchars($user_data['user_name']);

function admin_count($con, $sql)
{
    $result = mysqli_query($con, $sql);
    $row = mysqli_fetch_row($result);
    return (int)$row[0];
}

$total_pets      = admin_count($con, "SELECT COUNT(*) FROM pets");
$available_pets  = admin_count($con, "SELECT COUNT(*) FROM pets WHERE status = 'Available'");
$pending_reqs    = admin_count($con, "SELECT COUNT(*) FROM adoption_requests WHERE status = 'Pending'");
$adopted_pets    = admin_count($con, "SELECT COUNT(*) FROM pets WHERE status = 'Adopted'");
$total_adopters  = admin_count($con, "SELECT COUNT(*) FROM users WHERE user_type = 'Adopter'");

// Latest requests waiting for a decision (shown 7 per page, up to 3 pages)
$pending = mysqli_query($con, "SELECT r.id, r.created_at, u.user_name, p.name AS pet_name, p.species, p.breed, p.age, p.photo
                               FROM adoption_requests r
                               JOIN pets p ON p.id = r.pet_id
                               LEFT JOIN users u ON u.user_id = r.user_id
                               WHERE r.status = 'Pending'
                               ORDER BY r.created_at DESC
                               LIMIT 21");

$page_kicker = "PETADOPT ADMIN";
$page_title  = "Welcome back, " . $user_name . "!";
$page_text   = "Here's what is happening at the shelter today.";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>PetAdopt | Admin Dashboard</title>

    <!-- Same font as the other admin pages -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@600;700;800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="../style/adopter_dashboard.css">
    <link rel="stylesheet" href="../style/admin_dashboard.css">

    <!-- Shared admin layout (loaded last so every admin page has the same sizes) -->
    <link rel="stylesheet" href="../style/admin_base.css">

    <style>
        /* Always reserve the scrollbar space so the page never jumps between admin pages */
        html { overflow-y: scroll; }
    </style>
    <style>
        /* No name / role pill at the top right of admin pages */
        .topbar .profile { display: none; }
    
        .pet-info .status-pending { background: #FBE0CA; border-color: #F4C9A3; color: #E08B45; }
        .pet-info .status-pending::before { background: #E08B45; }
        .pet-info p.by { max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    </style>
    <style>
        /* Real pet photo in the table */
        .cell-photo {
            flex-shrink: 0;
            width: 38px;
            height: 38px;
            border-radius: 50%;
            object-fit: cover;
            object-position: center 30%;
        }
    </style>

    <style>
        /* Summary card icons (SVG) take the color of their card */
        .summary-icon svg { display: block; }
        .green-card .summary-icon  { color: #4F7C59; }
        .orange-card .summary-icon { color: #E08B45; }
        .brown-card .summary-icon  { color: #A67C52; }
    </style>

    <style>
        /* Hide the email + role pill at the top right */
        .topbar .profile,
        .topbar .user-info,
        .topbar .user-pill,
        .topbar .user-menu,
        .topbar .account,
        .topbar > div:last-child:not(.search):not(.topbar-title) {
            display: none !important;
        }
    </style>
    <style>
        /* ===== Same balanced card + 7 per page arrows as the adopter pages ===== */
        .pets-section .pet-list {
            display: flex !important;
            grid-template-columns: none !important;
            gap: 18px !important;
            overflow-x: auto;
            scroll-snap-type: x mandatory;
            scroll-padding-left: 4px;
            scroll-behavior: smooth;
            scrollbar-width: none;
            -ms-overflow-style: none;
            padding: 8px 4px 20px;
            margin: -8px -4px -20px;
        }

        .pets-section .pet-list::-webkit-scrollbar { display: none; }

        .pets-section .pet-list > .pet-card {
            flex: 0 0 calc((100% - 108px) / 7);
            min-width: 0;
            max-width: none;
            height: auto;
            display: flex;
            flex-direction: column;
            scroll-snap-align: start;
        }

        .pet-card .pet-info {
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        .pet-card .pet-info > a:last-child { margin-top: auto; }

        .pets-section .pet-list > p { flex: 1 0 100%; }

        @media (max-width: 1200px) {
            .pets-section .pet-list > .pet-card { flex-basis: calc((100% - 54px) / 4); }
        }

        @media (max-width: 850px) {
            .pets-section .pet-list > .pet-card { flex-basis: calc((100% - 18px) / 2); }
        }

        @media (max-width: 520px) {
            .pets-section .pet-list > .pet-card { flex-basis: 100%; }
        }

        /* Details box */
        .pet-card .pet-info p.meta-box {
            align-self: stretch;
            width: 100%;
            box-sizing: border-box;
            max-width: 100%;
            margin: 10px 0 14px;
            padding: 12px 14px;
            display: flex;
            flex-direction: column;
            gap: 10px;
            text-align: left;
            white-space: normal;
            overflow: visible;
            background: var(--cream, #FFF6EE);
            border: 1px solid var(--border, #F0E4D6);
            border-radius: 16px;
        }

        .pet-card .meta-row { display: block; min-width: 0; }

        .pet-card .meta-row small {
            display: block;
            margin-bottom: 2px;
            color: var(--muted, #6B7369);
            font-size: .6rem;
            font-weight: 800;
            letter-spacing: .8px;
            text-transform: uppercase;
        }

        .pet-card .meta-row strong {
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 1;
            overflow: hidden;
            overflow-wrap: anywhere;
            color: var(--dark-green, #2F4F37);
            font-size: .8rem;
            font-weight: 800;
            line-height: 1.3;
        }

        .pet-card .meta-row:first-child strong {
            -webkit-line-clamp: 2;
            min-height: 2.6em;
        }

        /* Arrows */
        .carousel { position: relative; }

        .carousel-btn {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            z-index: 5;
            width: 44px;
            height: 44px;
            display: grid;
            place-items: center;
            padding: 0;
            background: var(--white, #FFFFFF);
            border: 1px solid var(--border, #E8E6DC);
            border-radius: 50%;
            box-shadow: 0 6px 18px rgba(47, 79, 55, .15);
            color: var(--green, #4F7C59);
            cursor: pointer;
            transition: background .25s ease, color .25s ease, opacity .25s ease, transform .25s ease;
        }

        .carousel-btn svg { width: 20px; height: 20px; display: block; }
        .carousel-btn.prev { left: -16px; }
        .carousel-btn.next { right: -16px; }

        .carousel-btn:hover:not(:disabled) {
            background: var(--green, #4F7C59);
            color: #fff;
            transform: translateY(-50%) scale(1.06);
        }

        .carousel-btn:focus-visible { outline: 3px solid rgba(79, 124, 89, .35); outline-offset: 2px; }

        .carousel-btn:disabled,
        .carousel-btn[hidden] { opacity: 0; pointer-events: none; }

        @media (max-width: 600px) {
            .carousel-btn { width: 38px; height: 38px; }
            .carousel-btn.prev { left: -8px; }
            .carousel-btn.next { right: -8px; }
        }

        @media (prefers-reduced-motion: reduce) {
            .pets-section .pet-list { scroll-behavior: auto; }
            .carousel-btn { transition: none; }
        }
    </style>
</head>

<body>

<div class="dashboard">

    <?php $active = "dashboard"; include("sidebar.php"); ?>

    <main class="main-content">

        <?php include("topbar.php"); ?>

        <section class="summary four">

            <article class="summary-card green-card">
                <div class="summary-icon"><?php echo icon("paw", 26); ?></div>
                <div>
                    <p>Total Pets</p>
                    <h2><?php echo $total_pets; ?></h2>
                    <small><?php echo $available_pets; ?> available</small>
                </div>
            </article>

            <article class="summary-card orange-card">
                <div class="summary-icon"><?php echo icon("mail", 26); ?></div>
                <div>
                    <p>Pending Requests</p>
                    <h2><?php echo $pending_reqs; ?></h2>
                    <small>Waiting for you</small>
                </div>
            </article>

            <article class="summary-card brown-card">
                <div class="summary-icon"><?php echo icon("home", 26); ?></div>
                <div>
                    <p>Adopted Pets</p>
                    <h2><?php echo $adopted_pets; ?></h2>
                    <small>In forever homes</small>
                </div>
            </article>

            <article class="summary-card green-card">
                <div class="summary-icon"><?php echo icon("users", 26); ?></div>
                <div>
                    <p>Adopters</p>
                    <h2><?php echo $total_adopters; ?></h2>
                    <small>Registered accounts</small>
                </div>
            </article>

        </section>


        <section class="pets-section">

            <div class="section-heading">
                <div>
                    <span><?php echo icon("mail", 14, "vertical-align:-2px;margin-right:6px"); ?>NEEDS A DECISION</span>
                    <h2>Latest pending requests</h2>
                </div>

                <a href="manage_requests.php?status=Pending">See all →</a>
            </div>

            <?php if ($pending && mysqli_num_rows($pending) > 0): ?>

                <div class="pet-list">
                    <?php while ($r = mysqli_fetch_assoc($pending)): ?>
                        <?php list($cls, $emoji) = pet_look($r['species']); ?>

                        <article class="pet-card">

                            <div class="pet-photo emoji <?php echo $cls; ?>">
                                <?php if (!empty($r['photo'])): ?>
                                    <img class="pet-photo-img" src="../uploads/pets/<?php echo htmlspecialchars($r['photo']); ?>" alt="<?php echo htmlspecialchars($r['pet_name']); ?>" loading="lazy">
                                <?php else: ?>
                                    <?php echo pet_icon($cls); ?>
                                <?php endif; ?>
                            </div>

                            <div class="pet-info">

                                <span class="available status-pending">&bull; Pending</span>

                                <h3><?php echo htmlspecialchars($r['pet_name']); ?></h3>

                                <p class="meta-box">
                                    <span class="meta-row">
                                        <small>Breed</small>
                                        <strong title="<?php echo htmlspecialchars($r['breed']); ?>"><?php echo htmlspecialchars($r['breed']); ?></strong>
                                    </span>
                                    <span class="meta-row">
                                        <small>Age</small>
                                        <strong><?php echo htmlspecialchars($r['age']); ?></strong>
                                    </span>
                                    <span class="meta-row">
                                        <small>Requested by</small>
                                        <strong title="<?php echo htmlspecialchars($r['user_name'] ?? "Unknown user"); ?>"><?php echo htmlspecialchars($r['user_name'] ?? "Unknown user"); ?></strong>
                                    </span>
                                    <span class="meta-row">
                                        <small>Sent</small>
                                        <strong><?php echo date("M j, Y", strtotime($r['created_at'])); ?></strong>
                                    </span>
                                </p>

                                <a href="manage_requests.php?status=Pending">Review &rarr;</a>

                            </div>

                        </article>

                    <?php endwhile; ?>
                </div>

            <?php else: ?>

                <div class="empty-state">
                    <div><?php echo icon("check", 44, "color:var(--green,#4F7C59)"); ?></div>
                    <h3>All caught up</h3>
                    <p>There are no requests waiting for a decision.</p>
                </div>

            <?php endif; ?>

        </section>

    </main>

</div>

<script>
(function () {
    var GAP = 18;
    var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    var chevronLeft  = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 5l-7 7 7 7"/></svg>';
    var chevronRight = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 5l7 7-7 7"/></svg>';

    function makeButton(kind, label, icon) {
        var b = document.createElement("button");
        b.type = "button";
        b.className = "carousel-btn " + kind;
        b.setAttribute("aria-label", label);
        b.innerHTML = icon;
        return b;
    }

    document.querySelectorAll(".pets-section .pet-list").forEach(function (list) {

        var wrap = document.createElement("div");
        wrap.className = "carousel";
        list.parentNode.insertBefore(wrap, list);
        wrap.appendChild(list);

        if (!list.querySelector(".pet-card")) { return; }

        var prev = makeButton("prev", "Previous", chevronLeft);
        var next = makeButton("next", "Next", chevronRight);
        wrap.appendChild(prev);
        wrap.appendChild(next);

        function step() {
            var card = list.querySelector(".pet-card");
            return card ? card.getBoundingClientRect().width + GAP : 300;
        }

        function perPage() {
            return Math.max(1, Math.round(list.clientWidth / step()));
        }

        function update() {
            var canScroll = list.scrollWidth > list.clientWidth + 2;
            prev.hidden = next.hidden = !canScroll;
            prev.disabled = list.scrollLeft <= 2;
            next.disabled = list.scrollLeft + list.clientWidth >= list.scrollWidth - 2;
        }

        function go(dir) {
            list.scrollBy({ left: dir * step() * perPage(), behavior: reduce ? "auto" : "smooth" });
        }

        prev.addEventListener("click", function () { go(-1); });
        next.addEventListener("click", function () { go(1); });
        list.addEventListener("scroll", update, { passive: true });
        window.addEventListener("resize", update);
        update();
    });
})();
</script>

</body>
</html>