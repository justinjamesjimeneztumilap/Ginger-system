<?php
// Shared admin sidebar. Set $active before including (dashboard, pets, requests, users)
$active = $active ?? "";

// [link, icon (SVG shapes), label]
$links = [
    "dashboard" => ["admin_dashboard.php", '<rect x="3" y="3" width="7.5" height="7.5" rx="2"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="2"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="2"/><rect x="13.5" y="13.5" width="7.5" height="7.5" rx="2"/>', "Dashboard"],
    "pets"      => ["manage_pets.php",     '<circle cx="5.5" cy="10.5" r="1.8"/><circle cx="9.5" cy="6" r="1.8"/><circle cx="14.5" cy="6" r="1.8"/><circle cx="18.5" cy="10.5" r="1.8"/><path d="M12 12c-2.8 0-5 2.4-5 4.6 0 1.5 1.2 2.4 2.6 2.4 1 0 1.6-.4 2.4-.4s1.4.4 2.4.4c1.4 0 2.6-.9 2.6-2.4C17 14.4 14.8 12 12 12z"/>', "Manage Pets"],
    "requests"  => ["manage_requests.php", '<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="M3.5 7.5 12 13.5l8.5-6"/>', "Requests"],
    "users"     => ["manage_users.php",    '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><circle cx="17.2" cy="9" r="2.4"/><path d="M17.2 14c2.5 0 4.3 1.9 4.3 4.5"/>', "Users"],
];

$logout_icon = '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/>';
$logo_icon   = '<circle cx="5.5" cy="10.5" r="1.8"/><circle cx="9.5" cy="6" r="1.8"/><circle cx="14.5" cy="6" r="1.8"/><circle cx="18.5" cy="10.5" r="1.8"/><path d="M12 12c-2.8 0-5 2.4-5 4.6 0 1.5 1.2 2.4 2.6 2.4 1 0 1.6-.4 2.4-.4s1.4.4 2.4.4c1.4 0 2.6-.9 2.6-2.4C17 14.4 14.8 12 12 12z"/>';
?>

<style>
    /* ---------- Admin sidebar: consistent icons, spacing and states ---------- */
    aside.sidebar {
        position: sticky;
        top: 0;
        width: 240px;
        height: 100vh;
        min-height: 100vh;
        padding: 28px 16px 20px;
        display: flex;
        flex-direction: column;
        flex-shrink: 0;
        background: var(--white, #FFFFFF);
        border-right: 1px solid var(--border, #E8E6DC);
        box-shadow: 2px 0 12px rgba(0, 0, 0, .02);
    }

    /* Logo */
    aside.sidebar .logo {
        display: flex;
        align-items: center;
        gap: 12px;
        margin: 0 8px 28px;
        font-size: 1.25rem;
        font-weight: 800;
        letter-spacing: -.3px;
        color: var(--dark-green, #2F4F37);
    }

    aside.sidebar .logo .logo-mark {
        width: 40px;
        height: 40px;
        flex-shrink: 0;
        display: grid;
        place-items: center;
        border-radius: 12px;
        background: var(--grad-green, linear-gradient(135deg, #5E8F69 0%, #4F7C59 55%, #3F6A49 100%));
        color: #fff;
        box-shadow: 0 6px 14px rgba(79, 124, 89, .28);
    }

    aside.sidebar .logo .logo-text span {
        color: var(--brown, #A67C52);
    }

    /* Icons: one size, one stroke, everywhere */
    aside.sidebar svg {
        width: 20px;
        height: 20px;
        flex-shrink: 0;
        fill: none;
        stroke: currentColor;
        stroke-width: 1.8;
        stroke-linecap: round;
        stroke-linejoin: round;
    }

    aside.sidebar .logo svg {
        width: 22px;
        height: 22px;
    }

    /* Menu */
    aside.sidebar .nav-label {
        margin: 0 16px 10px;
        color: var(--muted, #6B7369);
        font-size: .65rem;
        font-weight: 800;
        letter-spacing: 1.5px;
        text-transform: uppercase;
    }

    aside.sidebar nav {
        display: flex;
        flex-direction: column;
        gap: 6px;
    }

    aside.sidebar nav a,
    aside.sidebar .logout {
        display: flex;
        align-items: center;
        gap: 14px;
        padding: 12px 16px;
        border-radius: 999px;
        color: var(--muted, #6B7369);
        font-size: .9rem;
        font-weight: 700;
        line-height: 1.2;
        text-decoration: none;
        transform: none;
        transition: background .25s cubic-bezier(.4, 0, .2, 1), color .25s cubic-bezier(.4, 0, .2, 1), box-shadow .25s cubic-bezier(.4, 0, .2, 1);
    }

    aside.sidebar nav a:hover {
        background: var(--sage-soft, #EEF4EA);
        color: var(--dark-green, #2F4F37);
        transform: none;
    }

    aside.sidebar nav a.active {
        background: var(--grad-green, linear-gradient(135deg, #5E8F69 0%, #4F7C59 55%, #3F6A49 100%));
        color: #fff;
        box-shadow: 0 6px 14px rgba(79, 124, 89, .28);
        transform: none;
    }

    aside.sidebar nav a:focus-visible,
    aside.sidebar .logout:focus-visible {
        outline: 3px solid var(--orange, #F4A261);
        outline-offset: 2px;
    }

    /* Logout, pinned to the bottom */
    aside.sidebar .sidebar-footer {
        margin-top: auto;
        padding-top: 14px;
        border-top: 1px solid var(--border, #E8E6DC);
    }

    aside.sidebar .logout {
        margin-top: 0;
    }

    aside.sidebar .logout:hover {
        background: var(--peach, #FBE0CA);
        color: var(--brown, #A67C52);
    }

    /* Small screens: icons only */
    @media (max-width: 850px) {
        aside.sidebar {
            width: 70px;
            padding: 22px 10px 16px;
        }

        aside.sidebar .logo {
            justify-content: center;
            margin: 0 0 24px;
        }

        aside.sidebar .logo .logo-text,
        aside.sidebar .nav-label,
        aside.sidebar nav a span,
        aside.sidebar .logout span {
            display: none;
        }

        aside.sidebar nav a,
        aside.sidebar .logout {
            justify-content: center;
            padding: 12px;
        }
    }

    /* ===== NEW: Logout confirmation ===== */
    .logout-overlay {
        position: fixed;
        inset: 0;
        z-index: 1000;
        display: grid;
        place-items: center;
        padding: 20px;
        background: rgba(47, 79, 55, .35);
        backdrop-filter: blur(3px);
        animation: logout-fade .2s ease;
    }

    .logout-overlay[hidden] { display: none; }

    .logout-dialog {
        width: 100%;
        max-width: 400px;
        padding: 30px 28px 26px;
        text-align: center;
        background: var(--white, #FFFFFF);
        border: 1px solid var(--border, #E8E6DC);
        border-radius: 28px;
        box-shadow: 0 24px 60px rgba(47, 79, 55, .22);
        animation: logout-pop .25s cubic-bezier(.4, 0, .2, 1);
        font-family: var(--font, "Nunito", system-ui, sans-serif);
    }

    .logout-dialog-icon {
        width: 56px;
        height: 56px;
        margin: 0 auto 16px;
        display: grid;
        place-items: center;
        background: var(--peach, #FBE0CA);
        border-radius: 18px;
        color: var(--orange-dark, #E08B45);
    }

    .logout-dialog-icon svg {
        width: 26px;
        height: 26px;
        display: block;
        fill: none;
        stroke: currentColor;
        stroke-width: 1.8;
        stroke-linecap: round;
        stroke-linejoin: round;
    }

    .logout-dialog h2 {
        margin: 0 0 6px;
        color: var(--dark-green, #2F4F37);
        font-size: 1.25rem;
        font-weight: 800;
        letter-spacing: -.2px;
    }

    .logout-dialog p {
        margin: 0 0 24px;
        color: var(--muted, #6B7369);
        font-size: .85rem;
        font-weight: 600;
        line-height: 1.5;
    }

    .logout-dialog-actions {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 12px;
    }

    .logout-btn {
        height: 44px;
        box-sizing: border-box;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 0 16px;
        border: 1px solid transparent;
        border-radius: 999px;
        font-family: inherit;
        font-size: .82rem;
        font-weight: 800;
        text-decoration: none;
        cursor: pointer;
        transition: background .25s ease, color .25s ease, transform .25s ease, box-shadow .25s ease;
    }

    .logout-cancel {
        background: var(--sage-soft, #EEF4EA);
        color: var(--dark-green, #2F4F37);
    }

    .logout-cancel:hover { background: var(--sage, #DCE9D8); }

    .logout-confirm {
        background: var(--grad-green, linear-gradient(135deg, #5E8F69, #4F7C59 55%, #3F6A49));
        color: #fff;
        box-shadow: 0 6px 18px rgba(79, 124, 89, .25);
    }

    .logout-confirm:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 22px rgba(79, 124, 89, .35);
    }

    .logout-btn:focus-visible {
        outline: 3px solid var(--orange, #F4A261);
        outline-offset: 2px;
    }

    @keyframes logout-fade { from { opacity: 0; } to { opacity: 1; } }
    @keyframes logout-pop  { from { opacity: 0; transform: translateY(10px) scale(.97); } to { opacity: 1; transform: none; } }

    @media (max-width: 420px) {
        .logout-dialog-actions { grid-template-columns: 1fr; }
    }

    @media (prefers-reduced-motion: reduce) {
        .logout-overlay, .logout-dialog { animation: none; }
        .logout-btn { transition: none; }
    }
</style>

<aside class="sidebar">

    <a href="admin_dashboard.php" class="logo" aria-label="PetAdopt admin home">
        <span class="logo-mark"><svg viewBox="0 0 24 24" aria-hidden="true"><?php echo $logo_icon; ?></svg></span>
        <span class="logo-text">Pet<span>Adopt</span></span>
    </a>

    <p class="nav-label">Menu</p>

    <nav aria-label="Admin menu">
        <?php foreach ($links as $key => $link): ?>
            <a href="<?php echo $link[0]; ?>" title="<?php echo $link[2]; ?>"<?php echo ($key === $active) ? ' class="active" aria-current="page"' : ''; ?>>
                <svg viewBox="0 0 24 24" aria-hidden="true"><?php echo $link[1]; ?></svg>
                <span><?php echo $link[2]; ?></span>
            </a>
        <?php endforeach; ?>
    </nav>

    <div class="sidebar-footer">
        <!-- CHANGED: added id="logoutLink" so the confirmation can open -->
        <a href="../logout.php" class="logout" id="logoutLink" title="Logout">
            <svg viewBox="0 0 24 24" aria-hidden="true"><?php echo $logout_icon; ?></svg>
            <span>Logout</span>
        </a>
    </div>

</aside>

<!-- NEW: Logout confirmation -->
<div class="logout-overlay" id="logoutModal" hidden>
    <div class="logout-dialog" role="dialog" aria-modal="true" aria-labelledby="logoutTitle" aria-describedby="logoutText">

        <div class="logout-dialog-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><?php echo $logout_icon; ?></svg></div>

        <h2 id="logoutTitle">Log out of PetAdopt?</h2>
        <p id="logoutText">Are you sure you want to log out? You will need to sign in again to manage pets, requests and users.</p>

        <div class="logout-dialog-actions">
            <button type="button" class="logout-btn logout-cancel" id="logoutCancel">Stay logged in</button>
            <a href="../logout.php" class="logout-btn logout-confirm">Yes, log out</a>
        </div>

    </div>
</div>

<script>
(function () {
    var link    = document.getElementById("logoutLink");
    var modal   = document.getElementById("logoutModal");
    var cancel  = document.getElementById("logoutCancel");
    var confirm = modal ? modal.querySelector(".logout-confirm") : null;

    if (!link || !modal) { return; }

    function open() {
        modal.hidden = false;
        document.body.style.overflow = "hidden";
        cancel.focus();
    }

    function close() {
        modal.hidden = true;
        document.body.style.overflow = "";
        link.focus();
    }

    link.addEventListener("click", function (e) { e.preventDefault(); open(); });
    cancel.addEventListener("click", close);

    // Click on the dark background closes it too
    modal.addEventListener("click", function (e) { if (e.target === modal) { close(); } });

    document.addEventListener("keydown", function (e) {
        if (modal.hidden) { return; }
        if (e.key === "Escape") { close(); }

        // Keep the Tab key inside the dialog
        if (e.key === "Tab") {
            var first = cancel, last = confirm;
            if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
            else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
        }
    });
})();
</script>