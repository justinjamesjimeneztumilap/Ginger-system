<?php
session_start();

include("../connection.php");
include("../functions.php");
include("../icons.php");

$user_data = require_role($con, "Admin");
$user_name = htmlspecialchars($user_data['user_name']);

$species_list = ["Dog", "Cat", "Other"];
$gender_list  = ["Male", "Female"];
$status_list  = ["Available", "Pending", "Adopted"];

$error = "";

// Pet photos (stored in ../uploads/pets/, only the file name goes in the database)
$upload_dir_fs  = __DIR__ . "/../uploads/pets/";
$max_photo_size = 2 * 1024 * 1024; // 2 MB

function delete_pet_photo($file)
{
    global $upload_dir_fs;

    if ($file && preg_match('/^[a-f0-9]{16}\.(jpg|png|webp)$/', $file))
    {
        $path = $upload_dir_fs . $file;
        if (is_file($path)) { unlink($path); }
    }
}

// Empty form (used for "Add a pet")
$form = [
    "id"            => 0,
    "name"          => "",
    "species"       => "Dog",
    "breed"         => "",
    "age"           => "",
    "gender"        => "Male",
    "description"   => "",
    "health_status" => "Healthy",
    "status"        => "Available",
    "photo"         => "",
];

if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    $action = $_POST['action'] ?? "";

    // Delete a pet
    if ($action == "delete")
    {
        $pet_id = (int)($_POST['id'] ?? 0);

        $stmt = mysqli_prepare($con, "SELECT photo FROM pets WHERE id = ? LIMIT 1");
        mysqli_stmt_bind_param($stmt, "i", $pet_id);
        mysqli_stmt_execute($stmt);
        $old = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

        $stmt = mysqli_prepare($con, "DELETE FROM pets WHERE id = ?");
        mysqli_stmt_bind_param($stmt, "i", $pet_id);
        mysqli_stmt_execute($stmt);

        delete_pet_photo($old['photo'] ?? "");

        header("Location: manage_pets.php?deleted=1");
        die;
    }

    // Add or update a pet
    if ($action == "save")
    {
        $form = [
            "id"            => (int)($_POST['id'] ?? 0),
            "name"          => trim($_POST['name'] ?? ""),
            "species"       => $_POST['species'] ?? "",
            "breed"         => trim($_POST['breed'] ?? ""),
            "age"           => trim($_POST['age'] ?? ""),
            "gender"        => $_POST['gender'] ?? "",
            "description"   => trim($_POST['description'] ?? ""),
            "health_status" => trim($_POST['health_status'] ?? ""),
            "status"        => $_POST['status'] ?? "",
            "photo"         => "",
        ];

        if ($form['health_status'] === "") { $form['health_status'] = "Healthy"; }

        // Current photo of the pet being edited (if any)
        if ($form['id'] > 0)
        {
            $stmt = mysqli_prepare($con, "SELECT photo FROM pets WHERE id = ? LIMIT 1");
            mysqli_stmt_bind_param($stmt, "i", $form['id']);
            mysqli_stmt_execute($stmt);
            $cur = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
            $form['photo'] = $cur['photo'] ?? "";
        }

        if ($form['name'] === "" || $form['breed'] === "" || $form['age'] === "")
        {
            $error = "Please fill in the pet's name, breed and age.";
        }
        elseif (strlen($form['name']) > 100 || strlen($form['breed']) > 100 || strlen($form['age']) > 30 || strlen($form['health_status']) > 50)
        {
            $error = "One of the fields is too long. Please shorten it.";
        }
        elseif (!in_array($form['species'], $species_list, true) || !in_array($form['gender'], $gender_list, true) || !in_array($form['status'], $status_list, true))
        {
            $error = "Please choose valid options for species, gender and status.";
        }
        else
        {
            $old_photo = $form['photo'];
            $new_photo = $old_photo;

            // "Remove photo" goes back to the emoji
            if (!empty($_POST['remove_photo'])) { $new_photo = ""; }

            // New photo uploaded
            if (isset($_FILES['photo']) && $_FILES['photo']['error'] !== UPLOAD_ERR_NO_FILE)
            {
                $f = $_FILES['photo'];
                $allowed = ["image/jpeg" => "jpg", "image/png" => "png", "image/webp" => "webp"];

                if ($f['error'] !== UPLOAD_ERR_OK)
                {
                    $error = "The photo could not be uploaded. Please try again.";
                }
                elseif ($f['size'] > $max_photo_size)
                {
                    $error = "The photo is too big. Maximum size is 2 MB.";
                }
                else
                {
                    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);

                    if (!isset($allowed[$mime]) || !getimagesize($f['tmp_name']))
                    {
                        $error = "Please upload a JPG, PNG or WEBP image.";
                    }
                    else
                    {
                        if (!is_dir($upload_dir_fs)) { mkdir($upload_dir_fs, 0755, true); }

                        $file_name = bin2hex(random_bytes(8)) . "." . $allowed[$mime];

                        if (move_uploaded_file($f['tmp_name'], $upload_dir_fs . $file_name))
                        {
                            $new_photo = $file_name;
                        }
                        else
                        {
                            $error = "The photo could not be saved. Check the uploads folder.";
                        }
                    }
                }
            }

            if ($error === "")
            {
                $photo_db = ($new_photo === "") ? null : $new_photo;

                if ($form['id'] > 0)
                {
                    $stmt = mysqli_prepare($con, "UPDATE pets SET name = ?, species = ?, breed = ?, age = ?, gender = ?, description = ?, health_status = ?, status = ?, photo = ? WHERE id = ?");
                    mysqli_stmt_bind_param($stmt, "sssssssssi", $form['name'], $form['species'], $form['breed'], $form['age'], $form['gender'], $form['description'], $form['health_status'], $form['status'], $photo_db, $form['id']);
                    mysqli_stmt_execute($stmt);

                    // Delete the old file only when it was replaced or removed
                    if ($old_photo !== "" && $old_photo !== $new_photo) { delete_pet_photo($old_photo); }

                    header("Location: manage_pets.php?saved=updated");
                }
                else
                {
                    $stmt = mysqli_prepare($con, "INSERT INTO pets (name, species, breed, age, gender, description, health_status, status, photo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    mysqli_stmt_bind_param($stmt, "sssssssss", $form['name'], $form['species'], $form['breed'], $form['age'], $form['gender'], $form['description'], $form['health_status'], $form['status'], $photo_db);
                    mysqli_stmt_execute($stmt);

                    header("Location: manage_pets.php?saved=added");
                }

                die;
            }
        }
    }
}
elseif (isset($_GET['edit']))
{
    // Load a pet into the form for editing
    $edit_id = (int)$_GET['edit'];

    $stmt = mysqli_prepare($con, "SELECT * FROM pets WHERE id = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, "i", $edit_id);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if ($row)
    {
        $form = $row;
        $form['description'] = $row['description'] ?? "";
        $form['photo']       = $row['photo'] ?? "";
    }
}

$editing = $form['id'] > 0;

// Pet list view: profile cards (default) or the original table (?view=table)
$view = (($_GET['view'] ?? "") === "table") ? "table" : "cards";

// Search (name, breed or species) and status filter tabs
$q = trim($_GET['q'] ?? "");
if (strlen($q) > 100) { $q = substr($q, 0, 100); }

$filter = $_GET['status'] ?? "";
if (!in_array($filter, $status_list, true)) { $filter = ""; }

$tabs = ["" => "All"];
foreach ($status_list as $st) { $tabs[$st] = $st; }

$sql    = "SELECT id, name, species, breed, age, gender, status, photo FROM pets";
$where  = [];
$types  = "";
$params = [];

if ($q !== "")
{
    $where[]  = "(name LIKE ? OR breed LIKE ? OR species LIKE ?)";
    $like     = "%" . $q . "%";
    $types   .= "sss";
    array_push($params, $like, $like, $like);
}

if ($filter !== "")
{
    $where[]  = "status = ?";
    $types   .= "s";
    $params[] = $filter;
}

if ($where) { $sql .= " WHERE " . implode(" AND ", $where); }

$sql .= " ORDER BY id DESC";

$stmt = mysqli_prepare($con, $sql);
if ($params) { mysqli_stmt_bind_param($stmt, $types, ...$params); }
mysqli_stmt_execute($stmt);
$pets = mysqli_stmt_get_result($stmt);

// Keeps the search / filter / view in the links (toggle, tabs, pagination)
$list_qs = function ($extra = []) use ($q, $filter, $view) {
    $p = [];
    if ($q !== "")      { $p["q"]      = $q; }
    if ($filter !== "") { $p["status"] = $filter; }
    if ($view == "table") { $p["view"] = "table"; }
    $p = array_merge($p, $extra);
    foreach ($p as $k => $v) { if ($v === null) { unset($p[$k]); } }
    return "manage_pets.php" . ($p ? "?" . http_build_query($p) : "");
};

// Group the pets by species for the cards view: Dogs first, then Cats, then Other
// (the list inside each group is A-Z by name). The result pointer is rewound afterwards,
// so the table view and the "no pets yet" check keep working exactly as before.
$group_labels = ["Dog" => "Dogs", "Cat" => "Cats", "Other" => "Other pets"];
$pet_groups   = [];

if ($pets)
{
    while ($row = mysqli_fetch_assoc($pets))
    {
        $pet_groups[$row['species']][] = $row;
    }

    mysqli_data_seek($pets, 0);
}

$group_order = array_merge($species_list, array_diff(array_keys($pet_groups), $species_list));

foreach ($pet_groups as $sp => $list)
{
    usort($pet_groups[$sp], function ($a, $b) {
        return strcasecmp($a['name'], $b['name']);
    });
}

// One continuous list in order: all Dogs, then all Cats, then Other (A-Z inside each species)
$sorted_pets = [];

foreach ($group_order as $sp)
{
    foreach ($pet_groups[$sp] ?? [] as $row)
    {
        $sorted_pets[] = $row;
    }
}

// Pagination: 10 pets per page
$per_page    = 10;
$total_pets  = count($sorted_pets);
$total_pages = max(1, (int)ceil($total_pets / $per_page));

$page = (int)($_GET['page'] ?? 1);
if ($page < 1)            { $page = 1; }
if ($page > $total_pages) { $page = $total_pages; }

$offset    = ($page - 1) * $per_page;
$page_pets = array_slice($sorted_pets, $offset, $per_page);

$page_kicker = "MANAGE PETS";
$page_title  = "Pets at the shelter";
$page_text   = "Add new pets and keep their details up to date.";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>PetAdopt | Manage Pets</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@600;700;800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="../style/admin_base.css">
    <link rel="stylesheet" href="../style/manage_pets.css">
    <style>
        /* No name / role pill at the top right of admin pages */
        .topbar .profile { display: none; }
    </style>

    <style>
        /* Photo upload field */
        .photo-field .photo-row {
            display: flex;
            align-items: center;
            gap: 18px;
            padding: 14px 16px;
            background: var(--cream, #FFF8F0);
            border: 1px dashed var(--border, #E8E6DC);
            border-radius: 14px;
        }

        .photo-field .photo-preview {
            flex: 0 0 96px;
            width: 96px;
            height: 96px;
            display: grid;
            place-items: center;
            overflow: hidden;
            border-radius: 50%;
            border: 3px solid #fff;
            box-shadow: 0 6px 16px rgba(47, 79, 55, .15);
            background: linear-gradient(145deg, #F2F7EF, #EEF4EA);
            font-size: 2.8rem;
        }

        .photo-field .photo-preview.cat   { background: linear-gradient(145deg, #FCF4ED, #F7EBDF); }
        .photo-field .photo-preview.puppy { background: linear-gradient(145deg, #FEF6EC, #FCEBD6); }

        .photo-field .photo-preview img {
            display: block;
            width: 100%;
            height: 100%;
            object-fit: cover;
            object-position: center 30%;
        }

        .photo-field .photo-controls {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            gap: 6px;
            min-width: 0;
        }

        .photo-field .photo-input {
            position: absolute;
            width: 1px;
            height: 1px;
            opacity: 0;
            overflow: hidden;
        }

        .photo-field .photo-btn {
            display: inline-flex;
            align-items: center;
            margin: 0;
            padding: 8px 18px;
            border-radius: 999px;
            background: var(--sage, #DCE9D8);
            color: var(--dark-green, #2F4F37);
            font-size: .82rem;
            font-weight: 800;
            letter-spacing: 0;
            text-transform: none;
            cursor: pointer;
            transition: background .25s;
        }

        .photo-field .photo-btn:hover { background: #CFE0CA; }

        .photo-field .photo-input:focus-visible + .photo-btn {
            outline: 3px solid #F4A261;
            outline-offset: 2px;
        }

        .photo-field .photo-name {
            max-width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            color: var(--text, #3A423A);
            font-size: .8rem;
            font-weight: 700;
        }

        .photo-field .photo-controls small {
            color: var(--muted, #6B7369);
            font-size: .74rem;
            font-weight: 600;
            letter-spacing: 0;
            text-transform: none;
        }

        .photo-field .check {
            display: flex;
            align-items: center;
            gap: 6px;
            margin: 0;
            font-size: .8rem;
            font-weight: 700;
            letter-spacing: 0;
            text-transform: none;
            cursor: pointer;
        }

        .photo-field .check input {
            width: auto;
            padding: 0;
        }

        /* Photos in the list */
        .cell-photo {
            flex-shrink: 0;
            width: 38px;
            height: 38px;
            border-radius: 50%;
            object-fit: cover;
        }

        .pet-avatar-container .pet-photo-img {
            position: relative;
            z-index: 2;
            width: 90px;
            height: 90px;
            border-radius: 50%;
            object-fit: cover;
            object-position: center 30%;
            border: 3px solid #fff;
            box-shadow: 0 6px 16px rgba(47, 79, 55, .18);
        }

        /* Search + filter tabs + view toggle: one row, same 44px height (matches Requests page) */
        .pt-bar { display: flex; flex-wrap: wrap; align-items: center; justify-content: flex-start; gap: 12px; margin-bottom: 24px; }

        .pt-search {
            flex: 0 1 350px; max-width: 350px; height: 44px; box-sizing: border-box; margin: 0;
            display: flex; align-items: center; gap: 16px; padding: 0 24px 0 24px;
            background: var(--white, #FFFFFF); border: 1px solid var(--border, #E8E6DC); border-radius: 999px;
            color: var(--muted, #6B7369); box-shadow: 0 6px 18px rgba(79, 124, 89, .06);
            transition: border-color .25s ease, box-shadow .25s ease;
        }
        .pt-search:focus-within { border-color: var(--green, #4F7C59); box-shadow: 0 0 0 3px rgba(79, 124, 89, .15); }
        .pt-search svg { width: 18px; height: 18px; flex-shrink: 0; }
        .pt-search input,
        .pt-search input:hover,
        .pt-search input:focus {
            width: 100%; height: 100%; margin: 0; padding: 0 0 0 4px; border: none !important; border-radius: 0 !important;
            outline: none !important; box-shadow: none !important; background: transparent !important;
            -webkit-appearance: none; appearance: none;
            color: var(--text, #2F3A33); font-family: inherit; font-size: .85rem; font-weight: 600;
        }
        .pt-search input::-webkit-search-cancel-button { -webkit-appearance: none; }

        .pt-tabs { display: flex; flex-wrap: wrap; align-items: center; gap: 8px; flex-shrink: 0; }
        .pt-toggle { flex-shrink: 0; margin-left: auto; }
        .pt-tab {
            height: 44px; box-sizing: border-box; display: inline-flex; align-items: center; padding: 0 18px;
            background: var(--white, #FFFFFF); border: 1px solid var(--border, #E8E6DC); border-radius: 999px;
            box-shadow: 0 6px 18px rgba(79, 124, 89, .06);
            color: var(--muted, #6B7369); font-size: .82rem; font-weight: 800; text-decoration: none;
            transition: background .25s, color .25s, border-color .25s;
        }
        .pt-tab:hover { color: var(--dark-green, #2F4F37); }
        .pt-tab.active { background: var(--sage, #DCE9D8); border-color: var(--green, #4F7C59); color: var(--dark-green, #2F4F37); }
        /* Active filter looks like the Requests page: white pill with a green outline, no green fill */
        .pt-tab.active { background: var(--white, #FFFFFF); border-color: var(--green, #4F7C59); color: var(--dark-green, #2F4F37); }

        .pt-toggle {
            display: inline-flex; align-items: stretch; height: 44px; box-sizing: border-box; padding: 4px;
            background: var(--white, #FFFFFF); border: 1px solid var(--border, #E8E6DC); border-radius: 999px;
            box-shadow: 0 6px 18px rgba(79, 124, 89, .06);
        }
        .pt-toggle a {
            display: inline-flex; align-items: center; padding: 0 18px; border-radius: 999px;
            color: var(--muted, #6B7369); font-size: .78rem; font-weight: 800; text-decoration: none; transition: background .25s, color .25s;
        }
        .pt-toggle a.active { background: var(--sage, #DCE9D8); color: var(--dark-green, #2F4F37); }

        @media (max-width: 700px) {
            .pt-search { max-width: none; flex-basis: 100%; }
            .pt-toggle { margin-left: 0; }
        }

        @media (max-width: 600px) {
            .photo-field .photo-row { flex-direction: column; align-items: flex-start; }
        }
    </style>

    <!-- Old stylesheets (kept for reference, replaced by admin_base.css + manage_pets.css):
    <link rel="stylesheet" href="../style/adopter_dashboard.css">
    <link rel="stylesheet" href="../style/admin_dashboard.css">
    -->
</head>

<body>

<div class="dashboard">

    <?php $active = "pets"; include("sidebar.php"); ?>

    <main class="main-content">

        <?php include("topbar.php"); ?>

        <?php if (isset($_GET['saved'])): ?>
            <p class="alert alert-success" role="status">Pet <?php echo $_GET['saved'] == "added" ? "added" : "updated"; ?>.</p>
        <?php elseif (isset($_GET['deleted'])): ?>
            <p class="alert alert-success" role="status">Pet deleted.</p>
        <?php endif; ?>

        <?php if ($error !== ""): ?>
            <p class="alert alert-error" role="alert"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <!-- ADD / EDIT FORM -->
        <form method="post" enctype="multipart/form-data" class="form-card pet-form" id="pet-form">

            <h2><?php echo $editing ? "Edit " . htmlspecialchars($form['name']) : "Add a new pet"; ?></h2>

            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?php echo (int)$form['id']; ?>">

            <div class="form-grid">

                <div>
                    <label for="name">Name</label>
                    <input type="text" id="name" name="name" maxlength="100" placeholder="e.g. Buddy" value="<?php echo htmlspecialchars($form['name']); ?>" required>
                </div>

                <div>
                    <label for="species">Species</label>
                    <select id="species" name="species">
                        <?php foreach ($species_list as $s): ?>
                            <option value="<?php echo $s; ?>" <?php echo $form['species'] == $s ? "selected" : ""; ?>><?php echo $s; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label for="breed">Breed</label>
                    <input type="text" id="breed" name="breed" maxlength="100" placeholder="e.g. Golden Retriever" value="<?php echo htmlspecialchars($form['breed']); ?>" required>
                </div>

                <div>
                    <label for="age">Age</label>
                    <input type="text" id="age" name="age" maxlength="30" placeholder="e.g. 2 years" value="<?php echo htmlspecialchars($form['age']); ?>" required>
                </div>

                <div>
                    <label for="gender">Gender</label>
                    <select id="gender" name="gender">
                        <?php foreach ($gender_list as $g): ?>
                            <option value="<?php echo $g; ?>" <?php echo $form['gender'] == $g ? "selected" : ""; ?>><?php echo $g; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label for="status">Status</label>
                    <select id="status" name="status">
                        <?php foreach ($status_list as $st): ?>
                            <option value="<?php echo $st; ?>" <?php echo $form['status'] == $st ? "selected" : ""; ?>><?php echo $st; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="full photo-field">
                    <label for="photo">Photo</label>

                    <?php list($f_cls, $f_emoji) = pet_look($form['species']); ?>

                    <div class="photo-row">

                        <div class="photo-preview <?php echo $f_cls; ?>" id="photo-preview">
                            <?php if ($form['photo'] !== ""): ?>
                                <img src="../uploads/pets/<?php echo htmlspecialchars($form['photo']); ?>" alt="">
                            <?php else: ?>
                                <?php echo pet_icon($f_cls); ?>
                            <?php endif; ?>
                        </div>

                        <div class="photo-controls">
                            <input type="file" id="photo" name="photo" class="photo-input" accept="image/jpeg,image/png,image/webp">
                            <label for="photo" class="photo-btn"><?php echo $form['photo'] !== "" ? "Change photo" : "Choose photo"; ?></label>

                            <span class="photo-name" id="photo-name">No new photo selected</span>
                            <small>JPG, PNG or WEBP, up to 2 MB. Leave it empty to keep the current picture.</small>

                            <?php if ($form['photo'] !== ""): ?>
                                <label class="check"><input type="checkbox" name="remove_photo" value="1"> Remove photo (use the emoji again)</label>
                            <?php endif; ?>
                        </div>

                    </div>
                </div>

                <div class="full">
                    <label for="health_status">Health</label>
                    <input type="text" id="health_status" name="health_status" maxlength="50" value="<?php echo htmlspecialchars($form['health_status']); ?>">
                </div>

                <div class="full">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" rows="3" placeholder="Temperament, habits, anything adopters should know"><?php echo htmlspecialchars($form['description']); ?></textarea>
                </div>

            </div>

            <div class="actions">
                <button type="submit" class="btn"><?php echo $editing ? "Save changes" : "Add pet"; ?></button>

                <?php if ($editing): ?>
                    <a href="manage_pets.php" class="btn btn-soft">Cancel</a>
                <?php endif; ?>

                <p class="form-hint">Fields marked <b>*</b> are required.</p>
            </div>

        </form>


        <!-- PET LIST -->
        <section class="pets-section" id="pet-list">

            <div class="section-heading">
                <div>
                    <span><?php echo icon("paw", 14, "vertical-align:-2px;margin-right:6px"); ?>ALL PETS</span>
                    <h2>Pet list</h2>
                </div>

            </div>

            <div class="pt-bar">

                <form method="get" class="pt-search" role="search">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>
                    <input type="search" name="q" value="<?php echo htmlspecialchars($q); ?>" placeholder="Search name, breed or species" autocomplete="off" aria-label="Search pets">
                    <?php if ($filter !== ""): ?><input type="hidden" name="status" value="<?php echo htmlspecialchars($filter); ?>"><?php endif; ?>
                    <?php if ($view == "table"): ?><input type="hidden" name="view" value="table"><?php endif; ?>
                </form>

                <nav class="pt-tabs" aria-label="Filter pets">
                    <?php foreach ($tabs as $value => $label): ?>
                        <a href="<?php echo htmlspecialchars($list_qs(["status" => $value === "" ? null : $value]) . "#pet-list"); ?>"
                           class="pt-tab<?php echo $filter === $value ? " active" : ""; ?>"><?php echo $label; ?></a>
                    <?php endforeach; ?>
                </nav>

                <div class="pt-toggle" role="group" aria-label="Pet list view">
                    <a href="<?php echo htmlspecialchars($list_qs(["view" => null]) . "#pet-list"); ?>"<?php echo $view == "cards" ? ' class="active" aria-current="true"' : ''; ?>>Cards</a>
                    <a href="<?php echo htmlspecialchars($list_qs(["view" => "table"]) . "#pet-list"); ?>"<?php echo $view == "table" ? ' class="active" aria-current="true"' : ''; ?>>Table</a>
                </div>

            </div>

            <div id="pet-results">

            <?php if ($pets && mysqli_num_rows($pets) > 0): ?>

                <?php if ($view == "table"): ?>

                <?php mysqli_data_seek($pets, $offset); $shown = 0; ?>

                <div class="table-wrap">
                    <table>
                        <thead>
                            <tr>
                                <th>Pet</th>
                                <th>Breed</th>
                                <th>Age</th>
                                <th>Gender</th>
                                <th>Status</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($p = mysqli_fetch_assoc($pets)): ?>
                                <?php if ($shown++ >= $per_page) { break; } ?>
                                <?php list($cls, $emoji) = pet_look($p['species']); ?>
                                <tr>
                                    <td>
                                        <div class="cell-pet">
                                            <?php if (!empty($p['photo'])): ?>
                                                <img class="cell-photo" src="../uploads/pets/<?php echo htmlspecialchars($p['photo']); ?>" alt="">
                                            <?php else: ?>
                                                <span class="cell-emoji <?php echo $cls; ?>"><?php echo pet_icon($cls, 22); ?></span>
                                            <?php endif; ?>
                                            <?php echo htmlspecialchars($p['name']); ?>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($p['breed']); ?></td>
                                    <td><?php echo htmlspecialchars($p['age']); ?></td>
                                    <td><?php echo htmlspecialchars($p['gender']); ?></td>
                                    <td><span class="badge <?php echo strtolower($p['status']); ?>"><?php echo htmlspecialchars($p['status']); ?></span></td>
                                    <td>
                                        <div class="actions">
                                            <a href="manage_pets.php?edit=<?php echo (int)$p['id']; ?>#pet-form" class="btn btn-soft btn-sm">Edit</a>

                                            <form method="post" onsubmit="return confirm('Delete <?php echo htmlspecialchars(addslashes($p['name']), ENT_QUOTES); ?>? Their adoption requests will be deleted too.');">
                                                <input type="hidden" name="action" value="delete">
                                                <input type="hidden" name="id" value="<?php echo (int)$p['id']; ?>">
                                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>

                <?php else: ?>

                <!-- PROFILE CARDS: one grid, in order (Dogs, then Cats, then Other). Same card size and look as Browse Pets -->
                <div class="pet-profile-list">
                    <?php foreach ($page_pets as $p): ?>
                        <?php list($cls, $emoji) = pet_look($p['species']); ?>
                        <article class="pet-profile-card<?php echo ($editing && (int)$form['id'] === (int)$p['id']) ? ' is-editing' : ''; ?>">

                            <div class="pet-avatar-container <?php echo $cls; ?>">
                                <?php if (!empty($p['photo'])): ?>
                                    <img class="pet-photo-img" src="../uploads/pets/<?php echo htmlspecialchars($p['photo']); ?>" alt="<?php echo htmlspecialchars($p['name']); ?>" loading="lazy">
                                <?php else: ?>
                                    <span class="pet-avatar"><?php echo pet_icon($cls); ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="pet-profile-details">

                                <div class="profile-header">
                                    <h3><?php echo htmlspecialchars($p['name']); ?></h3>
                                    <span class="badge <?php echo strtolower($p['status']); ?>"><?php echo htmlspecialchars($p['status']); ?></span>
                                </div>

                                <div class="profile-meta-split">
                                    <div class="meta-item">
                                        <small>Breed</small>
                                        <strong title="<?php echo htmlspecialchars($p['breed']); ?>"><?php echo htmlspecialchars($p['breed']); ?></strong>
                                    </div>
                                    <div class="meta-item">
                                        <small>Age</small>
                                        <strong><?php echo htmlspecialchars($p['age']); ?></strong>
                                    </div>
                                    <div class="meta-item">
                                        <small>Gender</small>
                                        <strong><?php echo htmlspecialchars($p['gender']); ?></strong>
                                    </div>
                                    <div class="meta-item">
                                        <small>Species</small>
                                        <strong><?php echo htmlspecialchars($p['species']); ?></strong>
                                    </div>
                                </div>

                                <div class="card-actions">
                                    <a href="manage_pets.php?edit=<?php echo (int)$p['id']; ?>#pet-form" class="btn btn-soft btn-sm">Edit</a>

                                    <form method="post" onsubmit="return confirm('Delete <?php echo htmlspecialchars(addslashes($p['name']), ENT_QUOTES); ?>? Their adoption requests will be deleted too.');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?php echo (int)$p['id']; ?>">
                                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                    </form>
                                </div>

                            </div>

                        </article>
                    <?php endforeach; ?>
                </div>

                <?php endif; ?>

                <?php if ($total_pages > 1): ?>
                    <?php
                        // links keep the current view (cards / table) and land back on the list
                        $page_url = function ($n) use ($list_qs) {
                            return htmlspecialchars($list_qs(["page" => $n]) . "#pet-list");
                        };

                        // page numbers: first, last, and the ones next to the current page
                        $page_nums = [];
                        for ($i = 1; $i <= $total_pages; $i++)
                        {
                            if ($i == 1 || $i == $total_pages || abs($i - $page) <= 1) { $page_nums[] = $i; }
                        }

                        $shown_from = $offset + 1;
                        $shown_to   = min($offset + $per_page, $total_pets);
                    ?>

                    <nav class="pagination" aria-label="Pet list pages">

                        <p class="page-info">Showing <?php echo $shown_from; ?>&ndash;<?php echo $shown_to; ?> of <?php echo $total_pets; ?> pets</p>

                        <div class="page-links">

                            <?php if ($page > 1): ?>
                                <a href="<?php echo $page_url($page - 1); ?>" class="page-link page-step" rel="prev">&larr; Previous</a>
                            <?php else: ?>
                                <span class="page-link page-step disabled" aria-disabled="true">&larr; Previous</span>
                            <?php endif; ?>

                            <?php $prev_num = 0; ?>
                            <?php foreach ($page_nums as $n): ?>
                                <?php if ($n - $prev_num > 1): ?>
                                    <span class="page-gap">&hellip;</span>
                                <?php endif; ?>

                                <?php if ($n == $page): ?>
                                    <span class="page-link current" aria-current="page"><?php echo $n; ?></span>
                                <?php else: ?>
                                    <a href="<?php echo $page_url($n); ?>" class="page-link"><?php echo $n; ?></a>
                                <?php endif; ?>

                                <?php $prev_num = $n; ?>
                            <?php endforeach; ?>

                            <?php if ($page < $total_pages): ?>
                                <a href="<?php echo $page_url($page + 1); ?>" class="page-link page-step" rel="next">Next &rarr;</a>
                            <?php else: ?>
                                <span class="page-link page-step disabled" aria-disabled="true">Next &rarr;</span>
                            <?php endif; ?>

                        </div>

                    </nav>
                <?php endif; ?>

            <?php else: ?>

                <div class="empty-state">
                    <div><?php echo icon("paw", 44, "color:var(--green,#4F7C59)"); ?></div>
                    <?php if ($q !== "" || $filter !== ""): ?>
                        <h3>No matches</h3>
                        <p>Try a different name, breed or status.</p>
                    <?php else: ?>
                        <h3>No pets yet</h3>
                        <p>Use the form above to add your first pet.</p>
                    <?php endif; ?>
                </div>

            <?php endif; ?>

            </div><!-- /#pet-results -->

        </section>

    </main>

</div>

<script>
// Live preview of the chosen photo (with a 2 MB check)
(function () {
    var input = document.getElementById("photo");
    var box   = document.getElementById("photo-preview");
    var name  = document.getElementById("photo-name");

    input.addEventListener("change", function () {
        var file = this.files[0];

        if (!file) { name.textContent = "No new photo selected"; return; }

        if (file.size > 2 * 1024 * 1024) {
            alert("That photo is too big. Please choose one under 2 MB.");
            this.value = "";
            name.textContent = "No new photo selected";
            return;
        }

        var img = document.createElement("img");
        img.src = URL.createObjectURL(file);
        img.alt = "";

        box.innerHTML = "";
        box.appendChild(img);

        name.textContent = file.name;
    });
})();
</script>

<script>
// Filter tabs, search, Cards/Table and pagination update the pet list in place:
// no full page reload, so the page stays exactly where it is.
(function () {
    var section = document.getElementById("pet-list");
    if (!section || !window.fetch || !window.DOMParser) { return; }

    var form    = section.querySelector(".pt-search");
    var input   = form.querySelector("input[type=search]");
    var results = document.getElementById("pet-results");
    var latest  = 0;
    var timer;

    function clean(url) { return url.split("#")[0]; }

    function load(url, push) {
        var id = ++latest;

        fetch(clean(url), { credentials: "same-origin" })
            .then(function (r) { return r.text(); })
            .then(function (html) {
                if (id !== latest) { return; }

                var doc = new DOMParser().parseFromString(html, "text/html");

                // keep the page height while the list is swapped so nothing jumps
                results.style.minHeight = results.offsetHeight + "px";

                ["#pet-results", ".pt-tabs", ".pt-toggle"].forEach(function (sel) {
                    var now  = section.querySelector(sel);
                    var next = doc.querySelector(sel);
                    if (now && next) { now.innerHTML = next.innerHTML; }
                });

                // hidden status / view fields of the search form follow the new state
                form.querySelectorAll("input[type=hidden]").forEach(function (h) { h.remove(); });
                doc.querySelectorAll(".pt-search input[type=hidden]").forEach(function (h) {
                    form.appendChild(document.importNode(h, true));
                });

                if (push) { history.pushState({}, "", clean(url)); }

                requestAnimationFrame(function () { results.style.minHeight = ""; });
            })
            .catch(function () { window.location.href = url; });
    }

    function search_url() {
        var params = new URLSearchParams(new FormData(form));
        if (!params.get("q")) { params.delete("q"); }
        var qs = params.toString();
        return "manage_pets.php" + (qs ? "?" + qs : "");
    }

    // tabs, Cards/Table and page links
    section.addEventListener("click", function (e) {
        var a = e.target.closest(".pt-tab, .pt-toggle a, .pagination a.page-link");

        if (!a || !section.contains(a) || e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) { return; }

        e.preventDefault();
        load(a.getAttribute("href"), true);
    });

    // Enter in the search bar, and live search while typing
    form.addEventListener("submit", function (e) {
        e.preventDefault();
        clearTimeout(timer);
        load(search_url(), true);
    });

    input.addEventListener("input", function () {
        clearTimeout(timer);
        timer = setTimeout(function () { load(search_url(), true); }, 350);
    });

    // browser back / forward
    window.addEventListener("popstate", function () {
        var q = new URLSearchParams(window.location.search).get("q") || "";
        input.value = q;
        load(window.location.href, false);
    });
})();
</script>

</body>
</html>