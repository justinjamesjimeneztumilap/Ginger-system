<?php
session_start();

include("../connection.php");
include("../functions.php");
include("../icons.php");

$user_data = require_role($con, "Admin");
$user_name = htmlspecialchars($user_data['user_name']);

// Approve or reject a request
if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    $action     = $_POST['action'] ?? "";
    $request_id = (int)($_POST['request_id'] ?? 0);

    if (in_array($action, ["approve", "reject"], true))
    {
        $new_status = ($action == "approve") ? "Approved" : "Rejected";
        $pet_status = ($action == "approve") ? "Adopted"  : "Available";

        mysqli_begin_transaction($con);

        $stmt = mysqli_prepare($con, "SELECT pet_id FROM adoption_requests WHERE id = ? AND status = 'Pending' LIMIT 1");
        mysqli_stmt_bind_param($stmt, "i", $request_id);
        mysqli_stmt_execute($stmt);
        $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

        if ($row)
        {
            $stmt = mysqli_prepare($con, "UPDATE adoption_requests SET status = ? WHERE id = ?");
            mysqli_stmt_bind_param($stmt, "si", $new_status, $request_id);
            mysqli_stmt_execute($stmt);

            $stmt = mysqli_prepare($con, "UPDATE pets SET status = ? WHERE id = ?");
            mysqli_stmt_bind_param($stmt, "si", $pet_status, $row['pet_id']);
            mysqli_stmt_execute($stmt);

            mysqli_commit($con);
            header("Location: manage_requests.php?done=" . $action);
            die;
        }

        mysqli_rollback($con);
    }

    header("Location: manage_requests.php");
    die;
}

// Cards (default) or the original table (?view=table)
$view = (($_GET['view'] ?? "") === "table") ? "table" : "cards";

// Filter tabs
$filter = $_GET['status'] ?? "";
if (!in_array($filter, ["Pending", "Approved", "Rejected"], true)) { $filter = ""; }

$sql = "SELECT r.id, r.message, r.status, r.created_at,
               u.user_name, p.name AS pet_name, p.species, p.breed, p.age, p.photo
        FROM adoption_requests r
        JOIN pets p ON p.id = r.pet_id
        LEFT JOIN users u ON u.user_id = r.user_id";

if ($filter !== "") { $sql .= " WHERE r.status = ?"; }

$sql .= " ORDER BY (r.status = 'Pending') DESC, r.created_at DESC";

$stmt = mysqli_prepare($con, $sql);
if ($filter !== "") { mysqli_stmt_bind_param($stmt, "s", $filter); }
mysqli_stmt_execute($stmt);
$requests = mysqli_stmt_get_result($stmt);

$page_kicker = "ADOPTION REQUESTS";
$page_title  = "Review requests";
$page_text   = "Approve or reject adoption requests from adopters.";

$tabs = ["" => "All", "Pending" => "Pending", "Approved" => "Approved", "Rejected" => "Rejected"];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>PetAdopt | Requests</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@600;700;800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="../style/admin_base.css">
    <link rel="stylesheet" href="../style/manage_requests.css">
    <style>
        /* No name / role pill at the top right of admin pages */
        .topbar .profile { display: none; }

        /* Tabs + view toggle on one row */
        /* Search + filter tabs sit together on the left, the Cards/Table toggle goes to the right */
        .rq-bar { display: flex; flex-wrap: wrap; align-items: center; justify-content: flex-start; gap: 12px; margin-bottom: 24px; }
        .rq-bar .tabs { margin-bottom: 0; align-items: center; gap: 8px; flex-shrink: 0; }
        .rq-bar .rq-toggle { margin-left: auto; flex-shrink: 0; }

        /* Search, tabs and toggle all share the same 44px height */
        .rq-search {
            flex: 0 1 350px; max-width: 350px; height: 44px; box-sizing: border-box;
            display: flex; align-items: center; gap: 16px; padding: 0 24px 0 24px;
            background: var(--white, #FFFFFF); border: 1px solid var(--border, #E8E6DC); border-radius: 999px;
            color: var(--muted, #6B7369); box-shadow: 0 6px 18px rgba(79, 124, 89, .06);
            transition: border-color .25s ease, box-shadow .25s ease;
        }
        .rq-search:focus-within { border-color: var(--green, #4F7C59); box-shadow: 0 0 0 3px rgba(79, 124, 89, .15); }
        .rq-search svg { width: 18px; height: 18px; flex-shrink: 0; }
        .rq-search input,
        .rq-search input:hover,
        .rq-search input:focus {
            width: 100%; height: 100%; margin: 0; padding: 0 0 0 4px; border: none !important; border-radius: 0 !important;
            outline: none !important; box-shadow: none !important; background: transparent !important;
            -webkit-appearance: none; appearance: none;
            color: var(--text, #2F3A33); font-family: inherit; font-size: .85rem; font-weight: 600;
        }
        .rq-search input::-webkit-search-cancel-button { -webkit-appearance: none; }

        .rq-bar .tab {
            height: 44px; box-sizing: border-box; display: inline-flex; align-items: center; padding: 0 18px;
            border: 1px solid var(--border, #E8E6DC); border-radius: 999px; box-shadow: 0 6px 18px rgba(79, 124, 89, .06);
            text-decoration: none;
        }
        .rq-bar .tab.active { border-color: var(--green, #4F7C59); }

        .rq-toggle {
            display: inline-flex; align-items: stretch; height: 44px; box-sizing: border-box; padding: 4px;
            background: var(--white, #FFFFFF); border: 1px solid var(--border, #E8E6DC); border-radius: 999px;
            box-shadow: 0 6px 18px rgba(79, 124, 89, .06);
        }
        .rq-toggle a {
            display: inline-flex; align-items: center; padding: 0 18px; border-radius: 999px;
            color: var(--muted, #6B7369); font-size: .78rem; font-weight: 800; text-decoration: none; transition: background .25s, color .25s;
        }
        .rq-toggle a.active { background: var(--sage, #DCE9D8); color: var(--dark-green, #2F4F37); }

        .rq-card[hidden], .rq-table-wrap tbody tr[hidden] { display: none; }
        .rq-nomatch { margin-top: 8px; }
        .rq-nomatch[hidden] { display: none; }

        @media (max-width: 700px) {
            .rq-search { max-width: none; flex-basis: 100%; }
            .rq-bar .rq-toggle { margin-left: 0; }
        }

        /* Request cards: same look as the customer pet cards */
        .rq-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(210px, 1fr)); gap: 16px; align-items: stretch; }

        .rq-card {
            display: flex; flex-direction: column; overflow: hidden; text-align: center;
            background: var(--white, #FFFFFF); border: 1px solid var(--border, #E8E6DC); border-radius: 20px;
            box-shadow: 0 2px 8px rgba(47, 79, 55, .05);
            transition: transform .25s cubic-bezier(.4, 0, .2, 1), box-shadow .25s cubic-bezier(.4, 0, .2, 1);
        }
        .rq-card:hover { transform: translateY(-4px); box-shadow: 0 8px 24px rgba(47, 79, 55, .08); }

        .rq-photo {
            position: relative; height: 120px; display: grid; place-items: center; isolation: isolate; overflow: hidden;
            font-size: 3.2rem; background: linear-gradient(145deg, #F2F7EF, #EEF4EA);
        }
        .rq-photo.cat   { background: linear-gradient(145deg, #FCF4ED, #F7EBDF); }
        .rq-photo.puppy { background: linear-gradient(145deg, #FEF6EC, #FCEBD6); }
        .rq-photo::before {
            content: ""; position: absolute; z-index: -1; width: 90px; height: 90px; top: 50%; left: 50%;
            transform: translate(-50%, -50%); border-radius: 50%; background: rgba(220, 233, 216, .65);
        }
        .rq-photo img {
            position: relative; z-index: 2; width: 90px; height: 90px; border-radius: 50%;
            object-fit: cover; object-position: center 30%; border: 3px solid #fff; background: #fff;
            box-shadow: 0 6px 16px rgba(47, 79, 55, .18);
        }

        .rq-body { display: flex; flex-direction: column; align-items: center; gap: 4px; padding: 14px 14px 12px; }
        .rq-body h3 { color: var(--dark-green, #2F4F37); font-size: 1rem; font-weight: 800; letter-spacing: -.2px; line-height: 1.3; }
        .rq-meta { color: var(--muted, #6B7369); font-size: .78rem; font-weight: 600; }

        .rq-details {
            display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin: 0 14px 12px; padding: 8px 10px; text-align: left;
            background: var(--cream, #FFF8F0); border: 1px solid var(--border, #E8E6DC); border-radius: 12px;
        }
        .rq-details div { min-width: 0; }
        .rq-details small, .rq-note-label { display: block; color: var(--muted, #6B7369); font-size: .6rem; font-weight: 800; letter-spacing: .4px; text-transform: uppercase; }
        .rq-details strong { display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: var(--dark-green, #2F4F37); font-size: .76rem; font-weight: 800; }

        .rq-note { display: flex; flex-direction: column; gap: 5px; padding: 0 14px 12px; text-align: left; }
        .rq-message {
            padding: 8px 12px; background: var(--cream, #FFF8F0); border: 1px solid var(--border, #E8E6DC); border-radius: 12px;
            color: var(--text, #3A423A); font-size: .8rem; font-weight: 600; line-height: 1.5;
            min-height: calc(3em + 16px); box-sizing: border-box;
            display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;
        }
        .rq-message.rq-empty { color: var(--muted, #6B7369); }

        .rq-footer { display: flex; gap: 8px; margin: auto 14px 14px; padding-top: 12px; border-top: 1px solid var(--border, #E8E6DC); }
        .rq-footer form { flex: 1; }
        .rq-footer .btn { width: 100%; }
    </style>
    <style>
        /* Real pet photo in the table */
        .cell-photo {
            flex-shrink: 0;
            width: 38px;
            height: 38px;
            border-radius: 50%;
            object-fit: cover;
            object-position: center 30%;
        }
    </style>

    <!-- Old stylesheets (kept for reference, replaced by admin_base.css + manage_requests.css):
    <link rel="stylesheet" href="../style/adopter_dashboard.css">
    <link rel="stylesheet" href="../style/admin_dashboard.css">
    -->
</head>

<body>

<div class="dashboard">

    <?php $active = "requests"; include("sidebar.php"); ?>

    <main class="main-content">

        <?php include("topbar.php"); ?>

        <?php if (isset($_GET['done'])): ?>
            <p class="alert alert-success" role="status">Request <?php echo $_GET['done'] == "approve" ? "approved" : "rejected"; ?>.</p>
        <?php endif; ?>

        <div class="rq-bar">

            <label class="rq-search">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>
                <input type="search" id="rqSearch" placeholder="Search pet, breed or adopter" autocomplete="off">
            </label>

            <nav class="tabs" aria-label="Filter requests">
                <?php foreach ($tabs as $value => $label): ?>
                    <?php
                        $qs = [];
                        if ($value !== "")       { $qs[] = "status=" . $value; }
                        if ($view == "table")    { $qs[] = "view=table"; }
                    ?>
                    <a href="manage_requests.php<?php echo $qs ? "?" . implode("&", $qs) : ""; ?>"
                       class="tab<?php echo $filter === $value ? " active" : ""; ?>"><?php echo $label; ?></a>
                <?php endforeach; ?>
            </nav>

            <?php $status_qs = $filter !== "" ? "status=" . $filter . "&" : ""; ?>
            <div class="rq-toggle" role="group" aria-label="Request list view">
                <a href="manage_requests.php<?php echo $filter !== "" ? "?status=" . $filter : ""; ?>"<?php echo $view == "cards" ? ' class="active" aria-current="true"' : ''; ?>>Cards</a>
                <a href="manage_requests.php?<?php echo $status_qs; ?>view=table"<?php echo $view == "table" ? ' class="active" aria-current="true"' : ''; ?>>Table</a>
            </div>

        </div>

        <?php if ($requests && mysqli_num_rows($requests) > 0): ?>

            <?php if ($view == "cards"): ?>

            <div class="rq-grid">
                <?php while ($r = mysqli_fetch_assoc($requests)): ?>
                    <?php list($cls, $emoji) = pet_look($r['species']); ?>

                    <article class="rq-card" data-search="<?php echo htmlspecialchars(strtolower($r['pet_name'] . " " . $r['breed'] . " " . ($r['user_name'] ?? ""))); ?>">

                        <div class="rq-photo <?php echo $cls; ?>">
                            <?php if (!empty($r['photo'])): ?>
                                <img src="../uploads/pets/<?php echo htmlspecialchars($r['photo']); ?>" alt="<?php echo htmlspecialchars($r['pet_name']); ?>" loading="lazy">
                            <?php else: ?>
                                <?php echo pet_icon($cls); ?>
                            <?php endif; ?>
                        </div>

                        <div class="rq-body">
                            <h3><?php echo htmlspecialchars($r['pet_name']); ?></h3>
                            <p class="rq-meta"><?php echo htmlspecialchars($r['breed']); ?> &middot; <?php echo htmlspecialchars($r['age']); ?></p>
                            <span class="badge <?php echo strtolower($r['status']); ?>"><?php echo htmlspecialchars($r['status']); ?></span>
                        </div>

                        <div class="rq-details">
                            <div>
                                <small>Adopter</small>
                                <strong title="<?php echo htmlspecialchars($r['user_name'] ?? "Unknown user"); ?>"><?php echo htmlspecialchars($r['user_name'] ?? "Unknown user"); ?></strong>
                            </div>
                            <div>
                                <small>Sent</small>
                                <strong><?php echo date("M j, Y", strtotime($r['created_at'])); ?></strong>
                            </div>
                        </div>

                        <div class="rq-note">
                            <span class="rq-note-label">Message</span>
                            <?php if ($r['message'] !== null && $r['message'] !== ""): ?>
                                <p class="rq-message"><?php echo htmlspecialchars($r['message']); ?></p>
                            <?php else: ?>
                                <p class="rq-message rq-empty">No message</p>
                            <?php endif; ?>
                        </div>

                        <?php if ($r['status'] == "Pending"): ?>
                            <div class="rq-footer">
                                <form method="post">
                                    <input type="hidden" name="action" value="approve">
                                    <input type="hidden" name="request_id" value="<?php echo (int)$r['id']; ?>">
                                    <button type="submit" class="btn btn-sm">Approve</button>
                                </form>

                                <form method="post" onsubmit="return confirm('Reject this request?');">
                                    <input type="hidden" name="action" value="reject">
                                    <input type="hidden" name="request_id" value="<?php echo (int)$r['id']; ?>">
                                    <button type="submit" class="btn btn-danger btn-sm">Reject</button>
                                </form>
                            </div>
                        <?php endif; ?>

                    </article>

                <?php endwhile; ?>
            </div>

            <?php else: ?>


            <div class="table-wrap rq-table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Pet</th>
                            <th>Adopter</th>
                            <th>Message</th>
                            <th>Sent</th>
                            <th>Status</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($r = mysqli_fetch_assoc($requests)): ?>
                            <?php list($cls, $emoji) = pet_look($r['species']); ?>
                            <tr data-search="<?php echo htmlspecialchars(strtolower($r['pet_name'] . " " . $r['breed'] . " " . ($r['user_name'] ?? ""))); ?>">
                                <td>
                                    <div class="cell-pet">
                                        <?php if (!empty($r['photo'])): ?>
                                                <img class="cell-photo" src="../uploads/pets/<?php echo htmlspecialchars($r['photo']); ?>" alt="">
                                            <?php else: ?>
                                                <span class="cell-emoji <?php echo $cls; ?>"><?php echo pet_icon($cls, 22); ?></span>
                                            <?php endif; ?>
                                        <?php echo htmlspecialchars($r['pet_name']); ?>
                                    </div>
                                </td>
                                <td><?php echo htmlspecialchars($r['user_name'] ?? "Unknown user"); ?></td>
                                <td class="cell-message"><?php echo $r['message'] !== null && $r['message'] !== "" ? htmlspecialchars($r['message']) : "<span class='muted'>No message</span>"; ?></td>
                                <td><?php echo date("M j, Y", strtotime($r['created_at'])); ?></td>
                                <td><span class="badge <?php echo strtolower($r['status']); ?>"><?php echo htmlspecialchars($r['status']); ?></span></td>
                                <td>
                                    <?php if ($r['status'] == "Pending"): ?>
                                        <div class="actions">
                                            <form method="post">
                                                <input type="hidden" name="action" value="approve">
                                                <input type="hidden" name="request_id" value="<?php echo (int)$r['id']; ?>">
                                                <button type="submit" class="btn btn-sm">Approve</button>
                                            </form>

                                            <form method="post" onsubmit="return confirm('Reject this request?');">
                                                <input type="hidden" name="action" value="reject">
                                                <input type="hidden" name="request_id" value="<?php echo (int)$r['id']; ?>">
                                                <button type="submit" class="btn btn-danger btn-sm">Reject</button>
                                            </form>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

            <?php endif; ?>

            <div class="empty-state rq-nomatch" id="rqNoMatch" hidden>
                <div><?php echo icon("mail", 44, "color:var(--green,#4F7C59)"); ?></div>
                <h3>No matches</h3>
                <p>Try a different pet, breed or adopter name.</p>
            </div>

        <?php else: ?>

            <div class="empty-state">
                <div><?php echo icon("mail", 44, "color:var(--green,#4F7C59)"); ?></div>
                <h3>No requests here</h3>
                <p>Requests from adopters will show up in this list.</p>
            </div>

        <?php endif; ?>

    </main>

</div>

<script>
(function () {
    var input   = document.getElementById("rqSearch");
    var items   = document.querySelectorAll(".rq-card, .rq-table-wrap tbody tr");
    var noMatch = document.getElementById("rqNoMatch");

    if (!input || !items.length) { return; }

    input.addEventListener("input", function () {
        var q = input.value.trim().toLowerCase();
        var shown = 0;

        items.forEach(function (item) {
            var show = !q || item.getAttribute("data-search").indexOf(q) !== -1;
            item.hidden = !show;
            if (show) { shown++; }
        });

        noMatch.hidden = shown !== 0;
    });
})();
</script>

</body>
</html>